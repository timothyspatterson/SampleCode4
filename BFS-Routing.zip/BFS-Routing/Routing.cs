﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.Text.RegularExpressions;
using System.Collections;

namespace BFS_Routing
{
    public partial class frmMain : Form
    {
        ProductionValidationEntities DB = new ProductionValidationEntities();
        public DataGridViewAutoSizeColumnsMode AutoSizeColumnsMode { get; set; }
        public int iChildRowCount { get; set; }
        data data = new data();

        public frmMain()
        {
            InitializeComponent();
            getLocations();
            lblCreateDate.Text = dtpMain.Value.Date.ToString("MM/dd/yyyy");
            cbxLocation.SelectedIndex = 804;
            cbxLocPrefix.SelectedIndex = 1;
            getRoutes();
            populateDrivers();
            populateTruckTrailers();
            populateBayIDs();
            populateSearchCBXs();
            startTimer();
            getAssetLocations();
        }

        //Populate Data

        public void getRoutes()
        {
            data data = new data();

            string theDate = dtpMain.Value.ToShortDateString();
            DateTime SelectedDateTime = DateTime.Parse(theDate);
            var routes = DB.DelRoutes.Where(y => y.rRouteID.Contains(cbxLocation.Text) && y.rDate == SelectedDateTime).Select(x => x.rRouteID).ToList();
            cbxRoute.DataSource = routes;
            cbxChangeRoute.DataSource = routes;
            cbxDeliveryRoutes.DataSource = routes;
        }

        public void getLocations()
        {
            data data = new data();
            data.populateLocationList();
            cbxLocation.DataSource = data.listLocations;
            cbxLocation.DisplayMember = "LocationCode";
            cbxLocation.ValueMember = "LocationCode";

            data.populateLocationPrefixList();
            cbxLocPrefix.DataSource = data.ListPrefixes;
            cbxLocPrefix.DisplayMember = "prefix";
            cbxLocPrefix.ValueMember = "prefix";
        }

        public void getAssetLocations()
        {
            data data = new data();
            data.populateLocationList();
            List<Locations> AssetLocations = new List<Locations>();
            AssetLocations = data.listLocations;

            cbxTruckLocation.DataSource = AssetLocations;
            //cbxTruckLocation.DataSource = data.listLocations;
            cbxTruckLocation.DisplayMember = "LocationCode";
            cbxTruckLocation.ValueMember = "LocationCode";

            cbxDriverLocation.DataSource = AssetLocations;
            //cbxDriverLocation.DataSource = data.listLocations;
            cbxDriverLocation.DisplayMember = "LocationCode";
            cbxDriverLocation.ValueMember = "LocationCode";

            cbxADriverLocation.DataSource = AssetLocations;
            //cbxADriverLocation.DataSource = data.listLocations;
            cbxADriverLocation.DisplayMember = "LocationCode";
            cbxADriverLocation.ValueMember = "LocationCode";

            cbxTrailerLocation.DataSource = AssetLocations;
            //cbxTrailerLocation.DataSource = data.listLocations;
            cbxTrailerLocation.DisplayMember = "LocationCode";
            cbxTrailerLocation.ValueMember = "LocationCode";
        }

        public void populateDTs()
        {
            DataTable MasterTBL = new DataTable();
            DataTable SlaveTBL = new DataTable();

            MasterTBL.Columns.Add("Stop", typeof(int));
            MasterTBL.Columns.Add("StopID", typeof(string));
            MasterTBL.Columns.Add("PickTicket", typeof(string));

            SlaveTBL.Columns.Add("PickTicket", typeof(string));
            SlaveTBL.Columns.Add("Stop", typeof(string));
            SlaveTBL.Columns.Add("ID", typeof(string));
            SlaveTBL.Columns.Add("SKU", typeof(string));
            SlaveTBL.Columns.Add("QTY", typeof(string));
            SlaveTBL.Columns.Add("Job ID", typeof(string));
            SlaveTBL.Columns.Add("PO", typeof(string));
            SlaveTBL.Columns.Add("Ship Date", typeof(string));

            var StopsList = data.routeDetails.Select(o => new { PickTicket = o.PickTicket, Stop = o.Stop, StopID = o.StopID });
            
            var DTData1 = StopsList.AsEnumerable().GroupBy(dgv => new
            {
                Stop = dgv.Stop,
                StopID = dgv.StopID,
                PickTicket = dgv.PickTicket
            }).Select(x => new
            {
                Stop = x.Key.Stop,
                StopID = x.Key.StopID,
                PickTicket = x.Key.PickTicket
            }).ToList();

            foreach(var row in DTData1)
            {
                DataRow newRow = MasterTBL.Rows.Add();
                newRow.SetField("PickTicket", row.PickTicket);
                newRow.SetField("Stop", row.Stop);
                newRow.SetField("StopID", row.StopID);
            }

            var StopDetails = data.routeDetails.Select(o => new { PickTicket = o.PickTicket, Stop = o.Stop, ID = o.ItemID, SKU = o.SKU, QTY = o.QTY, JobID = o.JobID, PO = o.CustPO, ShipDate = o.ShipDate });

            foreach (var row in StopDetails)
            {
                DataRow newRow = SlaveTBL.Rows.Add();
                newRow.SetField("PickTicket", row.PickTicket);
                newRow.SetField("Stop", row.Stop);
                newRow.SetField("ID", row.ID);
                newRow.SetField("SKU", row.SKU);
                newRow.SetField("QTY", row.QTY);
                newRow.SetField("Job ID", row.JobID);
                newRow.SetField("PO", row.PO);
                newRow.SetField("Ship Date", row.ShipDate);
            }

            DataSet dsDataSet = new DataSet();
            dsDataSet.Tables.Add(MasterTBL);
            dsDataSet.Tables.Add(SlaveTBL);

            DataRelation DataTableRelation = new DataRelation("Stop Details", dsDataSet.Tables[0].Columns[2], dsDataSet.Tables[1].Columns[0], true);

            dsDataSet.Relations.Add(DataTableRelation);
            dgRouteInfo.DataSource = dsDataSet.Tables[0];
        }

        public void populateDeliveryDTs()
        {
            DataTable DeliveryTableStops = new DataTable();

            DeliveryTableStops.Columns.Add("Stop", typeof(int));
            DeliveryTableStops.Columns.Add("Stop ID", typeof(string));
            DeliveryTableStops.Columns.Add("Pick Ticket", typeof(string));

            var DELStopsList = data.routeDetails.Select(o => new { PickTicket = o.PickTicket, Stop = o.Stop, StopID = o.StopID });

            var DELDTData1 = DELStopsList.AsEnumerable().GroupBy(dgv => new
            {
                //Route = dgv.Route,
                Stop = dgv.Stop,
                StopID = dgv.StopID,
                PickTicket = dgv.PickTicket
            }).Select(x => new
            {
                //Route = x.Key.Route,
                Stop = x.Key.Stop,
                StopID = x.Key.StopID,
                PickTicket = x.Key.PickTicket
            }).ToList();

            foreach (var row in DELDTData1)
            {
                DataRow newRow = DeliveryTableStops.Rows.Add();
                newRow.SetField("Pick Ticket", row.PickTicket);
                newRow.SetField("Stop", row.Stop);
                newRow.SetField("Stop ID", row.StopID);
            }

            DataSet DeliveryStopsDS = new DataSet();
            DeliveryStopsDS.Tables.Add(DeliveryTableStops);

            dgvDeliveryStatusStops.DataSource = DeliveryStopsDS.Tables[0];

            foreach (DataGridViewRow row in dgvDeliveryStatusStops.Rows)
            {
                int qtyOrd = 0;
                int qtyDel = 0;
                //Get PT, get total iQtyOrd and compare to total iQtyDel for the given pick Ticket.
                //Case each comparison --- equals = Green Delivered, < = Yellow Partial Delivery, iQtyDel = 0 = Red None Delivered
                string PT = row.Cells[2].Value.ToString();
                var itemList = data.routeDetails.Where(y => y.PickTicket == PT).Select(x => new { ItemID = x.ItemID }).ToList();
                foreach(var item in itemList)
                {
                    var qtyDelivered = DB.DelItems.Where(y => y.iItemID == item.ItemID).Select(x => new { ordered = x.iQtyOrd, delivered = x.iQtyDel }).FirstOrDefault();
                    if(qtyDelivered != null)
                    {
                        qtyOrd = qtyOrd + Convert.ToInt32(qtyDelivered.ordered);
                        qtyDel = qtyDel + Convert.ToInt32(qtyDelivered.delivered);
                    }
                }
                if(qtyOrd == 0 || qtyDel == 0)
                {
                    row.Cells[2].Style.BackColor = Color.Red;
                }
                if (qtyOrd > qtyDel)
                {
                    row.Cells[2].Style.BackColor = Color.Yellow;
                    MessageBox.Show("Check pick ticket " + row.Cells[2].Value.ToString() + " for backorders.");
                }
                if (qtyOrd == qtyDel)
                {
                    if (qtyOrd > 0 && qtyDel > 0)
                    row.Cells[2].Style.BackColor = Color.Green;
                }
            }
        }

        public void populateDeliveryDetailsDT(string searchValue, int mode)
        {
            DataTable DeliveryTableStopsDetail = new DataTable();

            string pickTicket = "";

            DeliveryTableStopsDetail.Columns.Add("PickTicket", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("Item ID", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("SKU", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("QTY", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("Ship Date", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("Delivery Date", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("Delivery Status", typeof(string));
            DeliveryTableStopsDetail.Columns.Add("Comments", typeof(string));


            IEnumerable<RouteDetails> query = Enumerable.Empty<RouteDetails>();

            if(mode == 1)
            {
                query = data.routeDetails.Where(y => y.PickTicket == searchValue).Select(o => new RouteDetails { ItemID = o.ItemID, SKU = o.SKU, QTY = o.QTY, ShipDate = o.ShipDate });
            }
            if(mode == 2)
            {
                query = DB.barinvs.Where(y => y.partno == searchValue).Select(o => new RouteDetails { ItemID = o.id, SKU = o.sku, QTY = o.qty, ShipDate = o.loaddate, PickTicket = o.partno });
                
            }
            if(mode == 3)
            {
                query = DB.barinvs.Where(y => y.desc1 == searchValue).Select(o => new RouteDetails { ItemID = o.id, SKU = o.sku, QTY = o.qty, ShipDate = o.loaddate, PickTicket = o.partno });
            }

            var DELStopDetails = query;
            foreach (var row in DELStopDetails)
            {
                pickTicket = row.PickTicket;
                DataRow newRow = DeliveryTableStopsDetail.Rows.Add();
                newRow.SetField("PickTicket", row.PickTicket);
                newRow.SetField("Item ID", row.ItemID);
                newRow.SetField("SKU", row.SKU);
                newRow.SetField("QTY", row.QTY);

                string LDate = row.ShipDate.ToString();
                DateTime dt = Convert.ToDateTime(LDate);

                newRow.SetField("Ship Date", dt);

                int ID = Convert.ToInt32(row.ItemID);
                var DELStatus = DB.DelItems.Where(y => y.iItemID == ID).Select(x => new { QtyOrdered = x.iQtyOrd, QtyDelivered = x.iQtyDel, comments = x.iComments }).FirstOrDefault();

                if (DELStatus != null)
                {
                    int iOrdered = Convert.ToInt32(DELStatus.QtyOrdered);
                    int iDelivered = Convert.ToInt32(DELStatus.QtyDelivered);

                    newRow.SetField("Comments", DELStatus.comments);

                    if (iOrdered == iDelivered)
                    {
                        newRow.SetField("Delivery Status", "Delivered");
                    }

                    if(iDelivered > 0 && iDelivered < iOrdered)
                    {
                        newRow.SetField("Delivery Status", "Back Ordered");
                    }

                    if (iDelivered == 0)
                    {
                        newRow.SetField("Delivery Status", "Yet to be Delivered");
                    }
                }
                else
                {
                    newRow.SetField("Delivery Status", "Yet to be Delivered");
                    newRow.SetField("Comments", "");
                }

                int PT = Convert.ToInt32(pickTicket);

                var deliveryDate = DB.DelStops.Where(y => y.sPTNum == PT).Select(x => x.sDate).FirstOrDefault();

                if (deliveryDate != null)
                {
                    string DeliveryDate = deliveryDate.Value.ToString();
                    DeliveryDate = DateTime.Parse(DeliveryDate).ToShortDateString();
                    newRow.SetField("Delivery Date", DeliveryDate);
                }
            }

            DataSet DeliveryDetailsDS = new DataSet();
            DeliveryDetailsDS.Tables.Add(DeliveryTableStopsDetail);

            dgvDeliveryStatusDetails.DataSource = DeliveryDetailsDS.Tables[0];

            foreach (DataGridViewRow row in dgvDeliveryStatusDetails.Rows)
            {
                string caseSwitch = row.Cells[6].Value.ToString();
                switch (caseSwitch)
                {
                    case "Delivered":
                        row.Cells[6].Style.BackColor = Color.Green;
                        break;
                    case "Back Ordered":
                        row.Cells[6].Style.BackColor = Color.Yellow;
                        break;
                    case "Yet to be Delivered":
                        row.Cells[6].Style.BackColor = Color.Red;
                        break;
                    default:
                        row.Cells[6].Style.BackColor = Color.Red;
                        break;
                }
            }
        }

        public void populateDrivers()
        {
            data data = new data();
            data.populateDriversList(cbxLocation.Text);
            //var driverQuery = data.ListDrivers.Select(x => x.fullName).ToList();
            var driverQuery = data.ListDrivers.Select(x => new {id = x.empID, fullName = x.fullName }).OrderBy(y => y.fullName).ToList();
            var AdriverQuery = data.ListDrivers.Select(x => new { aid = x.empID, afullName = x.fullName }).OrderBy(y => y.afullName).ToList();
            cbxCreateDriver.DisplayMember = "fullName";
            cbxCreateDriver.ValueMember = "id";
            cbxChangeDriverTo.DisplayMember = "fullName";
            cbxChangeDriverTo.ValueMember = "id";
            cbxCreateDriver.DataSource = driverQuery;
            cbxChangeDriverTo.DataSource = driverQuery;

            cbxCreateADriver.DisplayMember = "afullName";
            cbxCreateADriver.ValueMember = "aid";
            cbxChangeAsstDriverTo.DisplayMember = "afullName";
            cbxChangeAsstDriverTo.ValueMember = "aid";
            cbxCreateADriver.DataSource = AdriverQuery;
            cbxChangeAsstDriverTo.DataSource = AdriverQuery;

            cbxDelDriver.DisplayMember = "fullName";
            cbxDelDriver.ValueMember = "id";
            cbxDelDriver.DataSource = driverQuery;

            cbxDelADriver.DisplayMember = "afullName";
            cbxDelADriver.ValueMember = "aid";
            cbxDelADriver.DataSource = AdriverQuery;

            cbxCreateDriver.SelectedIndex = cbxCreateDriver.FindString(lblCurrentDriver.Text);
            cbxCreateADriver.SelectedIndex = cbxChangeAsstDriverTo.FindString(lblCurrentASstDriver.Text);

            cbxChangeDriverTo.SelectedIndex = cbxChangeDriverTo.FindString(lblCurrentDriver.Text);
            cbxChangeAsstDriverTo.SelectedIndex = cbxChangeAsstDriverTo.FindString(lblCurrentASstDriver.Text);
        }

        public void populateTruckTrailers()
        {
            data data = new data();
            data.populateTruckTrialerList(cbxLocation.Text, "TK");
            var TruckQuery = data.ListTrucksTrailers.Select(x => new { id = x.tAID, truck = x.tAID }).ToList();
            cbxCreateTruck.DisplayMember = "truck";
            cbxCreateTruck.ValueMember = "id";
            cbxChangeTruckTo.DisplayMember = "truck";
            cbxChangeTruckTo.ValueMember = "id";

            cbxCreateTruck.DataSource = TruckQuery;
            cbxChangeTruckTo.DataSource = TruckQuery;

            cbxCreateTruck.SelectedIndex = cbxChangeTruckTo.FindString(lblCurrentTruck.Text);
            cbxChangeTruckTo.SelectedIndex = cbxChangeTruckTo.FindString(lblCurrentTruck.Text);

            data.populateTruckTrialerList(cbxLocation.Text, "TL");
            var TrailerQuery = data.ListTrucksTrailers.Select(x => new { id = x.tAID, trailer = x.tAID }).ToList();

            cbxCreateTrailer.DisplayMember = "trailer";
            cbxCreateTrailer.ValueMember = "id";
            cbxChangeTrailerTo.DisplayMember = "trailer";
            cbxChangeTrailerTo.ValueMember = "id";

            cbxCreateTrailer.DataSource = TrailerQuery;
            cbxChangeTrailerTo.DataSource = TrailerQuery;

            cbxDelTruck.DisplayMember = "truck";
            cbxDelTruck.ValueMember = "id";
            cbxDelTruck.DataSource = TruckQuery;

            cbxDelTrailer.DisplayMember = "trailer";
            cbxDelTrailer.ValueMember = "id";
            cbxDelTrailer.DataSource = TrailerQuery;

            cbxCreateTrailer.SelectedIndex = cbxChangeTrailerTo.FindString(lblCurrentTrailer.Text);
            cbxChangeTrailerTo.SelectedIndex = cbxChangeTrailerTo.FindString(lblCurrentTrailer.Text);
        }

        public void populateBayIDs()
        {
            data data = new data();
            string Location = cbxLocation.Text;
            data.populateBayID(Location);
            cbxBayIDs.DataSource = data.ListBayIDs.Select(x => x.bayID).ToList();
            cbxChangeBayID.DataSource = data.ListBayIDs.Select(x => x.bayID).ToList();
        }

        public void populateChangeDTs()
        {
            DataTable MasterChangeTBL = new DataTable();

            MasterChangeTBL.Columns.Add("Stop", typeof(int));
            MasterChangeTBL.Columns.Add("StopID", typeof(string));
            MasterChangeTBL.Columns.Add("PickTicket", typeof(string));

            var StopsList = data.routeDetails.Select(o => new { PickTicket = o.PickTicket, Stop = o.Stop, StopID = o.StopID });

            var DTData1 = StopsList.AsEnumerable().GroupBy(dgv => new
            {
                Stop = dgv.Stop,
                StopID = dgv.StopID,
                PickTicket = dgv.PickTicket
            }).Select(x => new
            {
                Stop = x.Key.Stop,
                StopID = x.Key.StopID,
                PickTicket = x.Key.PickTicket
            }).ToList();

            foreach (var row in DTData1)
            {
                DataRow newRow = MasterChangeTBL.Rows.Add();
                newRow.SetField("PickTicket", row.PickTicket);
                newRow.SetField("Stop", row.Stop);
                newRow.SetField("StopID", row.StopID);
            }

            DataSet dsDataSet = new DataSet();
            dsDataSet.Tables.Add(MasterChangeTBL);

            dgvChangeAddStops.DataSource = dsDataSet.Tables[0];
            dgvChangeAddStops.AutoResizeColumns();
        }

        public void initializeAddStopDT()
        {
            DataTable MasterAddTBL = new DataTable();

            MasterAddTBL.Columns.Add("Stop", typeof(int));
            MasterAddTBL.Columns.Add("StopID", typeof(string));
            MasterAddTBL.Columns.Add("PickTicket", typeof(string));

            DataSet dsDataSet = new DataSet();
            dsDataSet.Tables.Add(MasterAddTBL);

            dgvAddStops.DataSource = dsDataSet.Tables[0];
            dgvAddStops.AutoResizeColumns();
        }

        public void populateSearchCBXs()
        {
            AutoCompleteStringCollection list = new AutoCompleteStringCollection();
            txtPickTicketSearch.AutoCompleteMode = AutoCompleteMode.Append;
            txtJobIDSearch.AutoCompleteMode = AutoCompleteMode.Append;
            txtPickTicketSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtJobIDSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;

            var pickTicketList = DB.barinvs.GroupBy(c => c.partno, (key, c) => c.FirstOrDefault());
            foreach(var pick in pickTicketList)
            {
                list.Add(pick.partno);
            }
            txtPickTicketSearch.AutoCompleteCustomSource = list;

            //list.Clear();

            //var jobIDList = DB.barinvs.GroupBy(x => x.desc1, (key, x) => x.FirstOrDefault());
            //foreach (var job in jobIDList)
            //{
            //    list.Add(job.desc1);
            //}
            //txtJobIDSearch.AutoCompleteCustomSource = list;
        }

        //Button Events

        private void btnClearCreateForm_Click(object sender, EventArgs e)
        {
            cbxCreateDriver.Text = "";
            cbxCreateADriver.Text = "";
            cbxCreateTruck.Text = "";
            cbxCreateTrailer.Text = "";
            cbxCreateDriver.Focus();
            lblRouteCodeCreated.Text = "";
            cbxBayIDs.Text = "";
            dgvAddStops.DataSource = null;
            dgvAddStops.Visible = false;
            pnlCreateStops.Visible = false;
        }

        private void btnCreateRoute_Click(object sender, EventArgs e)
        {
            int nextAvailableNUM = 0;
            lblRouteCodeCreated.Text = "";
            List<int> usedRouteNumbers = new List<int>();

            if(cbxCreateDriver.Text != "")
            {
                if(cbxCreateADriver.Text != "")
                {
                    if(cbxCreateTruck.Text != "")
                    {
                        if(cbxCreateTrailer.Text != "")
                        {
                            //All Fields have values, now lets create a route number...

                            string LocAndSelectedDate = cbxLocation.Text + dtpMain.Value.ToString("MMddyy");
                            var lastRouteForToday = DB.DelRoutes.Where(y => y.rRouteID.Contains(LocAndSelectedDate)).OrderBy(y => y.rRouteID.Length).Select(z => z.rRouteID).ToList();
                            if(lastRouteForToday.Any())
                            {

                                string lastElement = lastRouteForToday[lastRouteForToday.Count - 1];
                                string[] lNum = lastElement.Split('-');
                                int lastRouteint = Convert.ToInt32(lNum[1]);
                                var numberList = Enumerable.Range(1, lastRouteint).ToList();

                                foreach(var value in lastRouteForToday)
                                {
                                    string[] currentRoute = value.Split('-');
                                    int currentRouteNum = Convert.ToInt32(currentRoute[1]);
                                    usedRouteNumbers.Add(currentRouteNum);
                                }

                                var missingNumber = numberList.Where(n => !usedRouteNumbers.Contains(n));
                                if(missingNumber.Count() > 0)
                                {
                                    nextAvailableNUM = Convert.ToInt32(missingNumber);
                                }
                                else
                                {
                                    nextAvailableNUM = lastRouteint + 1;
                                }
                            }
                            else
                            {
                                nextAvailableNUM = 1;
                                //First Route for this date.
                            }

                            string DriverFullName = cbxCreateDriver.Text;
                            string ADriverFullName = cbxCreateADriver.Text;
                            string rTruckID = cbxCreateTruck.Text;
                            string rTrailerID = cbxCreateTrailer.Text;

                            var driverID = data.ListDrivers.Where(y => y.fullName == DriverFullName).Select(x => x.empID).FirstOrDefault();
                            int rDriverID = driverID;

                            var AdriverID = data.ListDrivers.Where(y => y.fullName == ADriverFullName).Select(x => x.empID).FirstOrDefault();
                            int rDriverAID = driverID;

                            string rRouteID = LocAndSelectedDate + "-" + nextAvailableNUM.ToString();

                            DateTime rDate = dtpMain.Value;

                            DelRoute NewRoute = new DelRoute();
                            NewRoute.rDate = rDate;
                            NewRoute.rRouteID = rRouteID;
                            NewRoute.rDriverID = rDriverID;
                            NewRoute.rDriverAID = rDriverAID;
                            NewRoute.rTruckID = rTruckID;
                            NewRoute.rTrailerID = rTrailerID;
                            NewRoute.rStatus = 1;
                            NewRoute.rTextFile = null;
                            NewRoute.rReleased = null;
                            //DB.DelRoutes.Add(NewRoute);
                            //DB.SaveChanges();

                            lblRouteCodeCreated.Text = "Created Route: " + rRouteID;

                            initializeAddStopDT();

                            pnlCreateStops.Visible = true;
                            dgvAddStops.Visible = true;
                            
                        }
                        else
                        {
                            MessageBox.Show("Please select a trailer for this route.");
                            cbxCreateTrailer.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a truck for this route.");
                        cbxCreateTruck.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please select an assistant driver for this route.");
                    cbxCreateADriver.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please select a driver for this route.");
                cbxCreateDriver.Focus();
            }
        }

        private void btnDeleteRoute_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete Route: " + cbxChangeRoute.Text + "?", "Delete Selected Route", MessageBoxButtons.YesNo);
            string routeToDelete = cbxChangeRoute.Text;
            if (dialogResult == DialogResult.Yes)
            {
                //var deleteRecord = DB.DelRoutes.RemoveRange(DB.DelRoutes.Where(y => y.rRouteID == routeToDelete));
                //DB.SaveChanges();
                MessageBox.Show("Route Deleted!");
            }
            else if (dialogResult == DialogResult.No)
            { 
                MessageBox.Show("Disaster averted.");
            }
        }

        private void btnSaveChangeDetails_Click(object sender, EventArgs e)
        {
            string routeToDelete = cbxChangeRoute.Text;

            int driverID = Convert.ToInt32(cbxChangeDriverTo.SelectedValue);
            int driverAID = Convert.ToInt32(cbxChangeAsstDriverTo.SelectedValue);

            string truck = cbxChangeTruckTo.SelectedValue.ToString();
            truck = truck.Replace(" ", "");
            string trailer = cbxChangeTrailerTo.SelectedValue.ToString();
            trailer = trailer.Replace(" ", "");
            string bayID = cbxChangeBayID.SelectedText;

            var routeToUpdate = DB.DelRoutes.Where(y => y.rRouteID == routeToDelete);
            foreach(var details in routeToUpdate)
            {
                details.rDriverID = driverID;
                details.rDriverAID = driverAID;
                details.rTruckID = truck;
                details.rTrailerID = trailer;
                //details.rBayID = bayID;
                //DB.SaveChanges();
            }

            MessageBox.Show("Route " + routeToDelete + " has been updated!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool rowSelected = false;
            foreach (DataGridViewRow row in dgvChangeAddStops.Rows)
            {
                if (dgvChangeAddStops.SelectedRows.Count == 1)
                {
                    rowSelected = true;
                    break;
                }
            }
            if(rowSelected == false)
            {
                MessageBox.Show("Please select a row in the grid to delete the stop.");
            }
            else
            {
                //Returns PT from selected row
                //string selectedUser = dgvChangeAddStops.SelectedRows[0].Cells[2].Value.ToString();
                //MessageBox.Show(selectedUser);

                string routeToEdit = cbxChangeRoute.Text;
                var SelectedStop = Convert.ToInt32(dgvChangeAddStops.CurrentRow.Cells[0].Value);
                int? Stop = SelectedStop;

                var StopID = dgvChangeAddStops.CurrentRow.Cells[1].Value;
                string stopID = StopID.ToString();
                var PickTicket = dgvChangeAddStops.CurrentRow.Cells[2].Value;
                long PickTicketNum = Convert.ToInt32(PickTicket);
                int rowNumToDelete = dgvChangeAddStops.Rows.IndexOf(dgvChangeAddStops.CurrentRow);
                int startingRow = 0;
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete Stop: " + Stop + "?", "Delete Selected Stop", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    //Reorder the grid to make the deleted stop dissappear
                    int DTRowCount = dgvChangeAddStops.Rows.Count - 1;
                    startingRow = rowNumToDelete + 1;
                    for (int i = startingRow; i < DTRowCount; i++)
                    {
                        dgvChangeAddStops.Rows[i].Cells[0].Value = i;
                    }

                    //Getting all stop data in selected route for use a little later...
                    var selectedRouteStopData = DB.DelStops.Where(y => y.rRouteID == routeToEdit);

                    //DELTING STOP
                    var deleteRecord = DB.DelStops.Where(y => y.rRouteID == routeToEdit && y.sPTNum == PickTicketNum && y.sStopID == stopID && y.sStopNum == Stop).FirstOrDefault();
                    //DB.DelStops.Remove(deleteRecord);
                    //DB.SaveChanges();


                    //Changing all stop numbers below the deleted stop so the order stays contigeous.
                    foreach (var stop in selectedRouteStopData)
                    {
                        if (stop.sStopNum > Stop)
                        {
                            var updateStops = DB.DelStops.Where(y => y.rRouteID == routeToEdit && y.sPTNum == stop.sPTNum && y.sStopID == stop.sStopID).FirstOrDefault();
                            updateStops.sStopNum = updateStops.sStopNum - 1;
                            //DB.SaveChanges();
                        }
                    }

                    //int selectedRow = dgvChangeAddStops.CurrentRow.Index;
                    dgvChangeAddStops.Rows.RemoveAt(rowNumToDelete);
                    dgvChangeAddStops.Refresh();

                    MessageBox.Show("Stop deleted.");
                }
                else if (dialogResult == DialogResult.No)
                {
                    MessageBox.Show("Disaster averted.");
                }
            }
        }

        private void btnAddStopsFromChange_Click(object sender, EventArgs e)
        {
            dgvChangeAddStops.FirstDisplayedScrollingRowIndex = dgvChangeAddStops.Rows.Count - 1;
            dgvChangeAddStops.Rows[dgvChangeAddStops.Rows.Count - 1].Cells[2].Selected = true;
            dgvChangeAddStops.BeginEdit(true);
        }

        private void btnAddNewStops_Click(object sender, EventArgs e)
        {
            dgvAddStops.FirstDisplayedScrollingRowIndex = dgvAddStops.Rows.Count - 1;
            dgvAddStops.Rows[dgvAddStops.Rows.Count - 1].Cells[2].Selected = true;
            dgvAddStops.BeginEdit(true);
        }

        private void btnDoneAddingStops_Click(object sender, EventArgs e)
        {
            //dgvAddStops.Rows.Clear();
            dgvAddStops.DataSource = null;
            dgvAddStops.Visible = false;
            pnlCreateStops.Visible = false;
            cbxCreateDriver.Text = "";
            cbxCreateADriver.Text = "";
            cbxCreateTruck.Text = "";
            cbxCreateTrailer.Text = "";
            cbxCreateDriver.Focus();
            lblRouteCodeCreated.Text = "";
            cbxBayIDs.Text = "";
        }

        private void btnDeleteAsset_Click(object sender, EventArgs e)
        {
            DialogResult delAsset = MessageBox.Show("Are you sure you want to delete " + cbxDelDriver.Text + " " + cbxDelADriver.Text + " " + cbxDelTruck.Text + " " + cbxDelTrailer.Text + "?",
                      "Delete Asset", MessageBoxButtons.YesNo);
            switch (delAsset)
            {
                case DialogResult.Yes:
                    int driver = Convert.ToInt32(cbxDelDriver.SelectedValue);
                    int Adriver = Convert.ToInt32(cbxDelADriver.SelectedValue);
                    string truck = cbxDelTruck.SelectedValue.ToString();
                    string trailer = cbxDelTrailer.SelectedValue.ToString();

                    //data.deleteAsset(driver, Adriver, truck, trailer);
                    MessageBox.Show("DELETED");
                    break;
                case DialogResult.No:
                    MessageBox.Show("Ok NOT deleted");
                    break;
            }
        }

        private void btnAddADriver_Click(object sender, EventArgs e)
        {
            if(txtbxADriverEmpID.Text != "")
            {
                if(txtbxADriverFirstName.Text != "")
                {
                    if(txtbxADriverLastName.Text != "")
                    {
                        if(cbxADriverLocation.Text != "")
                        {
                            DialogResult addDriver = MessageBox.Show("Are you sure you want to add " + txtbxADriverFirstName.Text + " " + txtbxADriverLastName.Text + " " + txtbxADriverEmpID.Text + " " + cbxADriverLocation.Text + "?",
                      "Add Assistant Driver", MessageBoxButtons.YesNo);
                            switch (addDriver)
                            {
                                case DialogResult.Yes:
                                    int aDriverEmpID = Convert.ToInt32(txtbxADriverEmpID.Text);
                                    //data.addADriver(txtbxADriverFirstName.Text, txtbxADriverLastName.Text, aDriverEmpID, "AD", cbxADriverLocation.Text);
                                    clearAllAssetFormFields();
                                    MessageBox.Show("ADDED");
                                    break;
                                case DialogResult.No:
                                    MessageBox.Show("Ok NOT added");
                                    break;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select the assistant driver's location.");
                            cbxADriverLocation.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please input the assistant driver's last name.");
                        txtbxADriverLastName.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please input the assistant driver's first name.");
                    txtbxADriverFirstName.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please input the assistant driver's employee ID.");
                txtbxADriverEmpID.Focus();
            }
        }

        private void btnAddDriver_Click(object sender, EventArgs e)
        {
            if(txtbxDriverFirstName.Text != "")
            {
                if(txtbxDriverLastName.Text != "")
                {
                    if(txtbxEmpID.Text != "")
                    {
                        if(cbxDriverLocation.Text != "")
                        {
                            DialogResult addDriver = MessageBox.Show("Are you sure you want to add " + txtbxDriverFirstName.Text + " " + txtbxDriverLastName.Text + " " + txtbxEmpID.Text + " " + cbxDriverLocation.Text + "?",
                      "Add Driver", MessageBoxButtons.YesNo);
                            switch (addDriver)
                            {
                                case DialogResult.Yes:
                                    int DriverEmpID = Convert.ToInt32(txtbxEmpID.Text);
                                    //data.addDriver(txtbxDriverFirstName.Text, txtbxDriverLastName.Text, DriverEmpID, "DR", cbxDriverLocation.Text);
                                    MessageBox.Show("ADDED");
                                    clearAllAssetFormFields();
                                    break;
                                case DialogResult.No:
                                    MessageBox.Show("Ok NOT added");
                                    break;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select the driver's location.");
                            cbxDriverLocation.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please input the driver's employee ID.");
                        txtbxEmpID.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please input the driver's Last name.");
                    txtbxDriverLastName.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please input the driver's first name.");
                txtbxDriverFirstName.Focus();
            }
        }

        private void btnAddTruck_Click(object sender, EventArgs e)
        {
            if(txtbxTruckAssetID.Text != "")
            {
                if(txtbxTruckAssetNumber.Text != "")
                {
                    if(txtbxTruckModel.Text != "")
                    {
                        if(cbxTruckLocation.Text != "")
                        {
                            if(cbxTruckMaintType.Text != "")
                            {
                                if (cbxTruckOther.Text != "")
                                {
                                    if (cbxTruckYear.Text != "")
                                    {
                                        int AssetNumber = Convert.ToInt32(txtbxTruckAssetNumber.Text);
                                        int Year = Convert.ToInt32(cbxTruckYear.Text);
                                        DialogResult addTruck = MessageBox.Show("Are you sure you want to add " + txtbxTruckAssetID.Text + " " + AssetNumber + " " + Year + " " + txtbxTruckModel.Text + " " + cbxTruckMaintType.Text + " " + cbxTruckLocation.Text + " " + cbxTruckOther.Text + " TK?",
                                                  "Add Truck", MessageBoxButtons.YesNo);
                                        switch (addTruck)
                                        {
                                            case DialogResult.Yes:
                                                data.addTruck(txtbxTruckAssetID.Text, AssetNumber, Year, txtbxTruckModel.Text, cbxTruckMaintType.Text, cbxTruckLocation.Text, cbxTruckOther.Text, "TK");
                                                MessageBox.Show("ADDED");
                                                clearAllAssetFormFields();
                                                break;
                                            case DialogResult.No:
                                                MessageBox.Show("Ok NOT added");
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please select the truck's year.");
                                        cbxTruckYear.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please select the truck's resource type (OTHER).");
                                    cbxTruckOther.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please select the truck's maintenance type.");
                                cbxTruckMaintType.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select the truck's location.");
                            cbxTruckLocation.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please input the truck's model.");
                        txtbxTruckModel.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please input the truck's asset number.");
                    txtbxTruckAssetNumber.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please input the truck's asset ID.");
                txtbxTruckAssetID.Focus();
            }
        }

        private void btnAddTrailer_Click(object sender, EventArgs e)
        {
            if (txtbxTrailerAssetID.Text != "")
            {
                if (txtbxTrailerAssetNumber.Text != "")
                {
                    if (txtbxTrailerModel.Text != "")
                    {
                        if (cbxTrailerLocation.Text != "")
                        {
                            if (cbxTrailerMaintType.Text != "")
                            {
                                if (cbxTrailerType.Text != "")
                                {
                                    if (cbxTrailerYear.Text != "")
                                    {
                                        int AssetNumber = Convert.ToInt32(txtbxTrailerAssetNumber.Text);
                                        int Year = Convert.ToInt32(cbxTrailerYear.Text);
                                        DialogResult addTrailer = MessageBox.Show("Are you sure you want to add " + txtbxTrailerAssetID.Text + " " + AssetNumber + " " + Year + " " + txtbxTrailerModel.Text + " " + cbxTrailerMaintType.Text + " " + cbxTrailerLocation.Text + " " + cbxTrailerType.Text + " TL?",
                                                  "Add Trailer", MessageBoxButtons.YesNo);
                                        switch (addTrailer)
                                        {
                                            case DialogResult.Yes:
                                                data.addTrailer(txtbxTruckAssetID.Text, AssetNumber, Year, txtbxTruckModel.Text, cbxTruckMaintType.Text, cbxTruckLocation.Text, cbxTruckOther.Text, "TK");
                                                MessageBox.Show("ADDED");
                                                clearAllAssetFormFields();
                                                break;
                                            case DialogResult.No:
                                                MessageBox.Show("Ok NOT added");
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please select the trailer's year.");
                                        cbxTrailerYear.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please select the trailer's resource type (OTHER).");
                                    cbxTrailerType.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please select the trailer's maintenance type.");
                                cbxTrailerMaintType.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select the trailer's location.");
                            cbxTrailerLocation.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please input the trailer's model.");
                        txtbxTrailerModel.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please input the trailer's asset number.");
                    txtbxTrailerAssetNumber.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please input the truck's asset ID.");
                txtbxTrailerAssetID.Focus();
            }
            
        }

        //Change Events

        private void cbxLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            getRoutes();
        }

        private void cbxRoute_SelectedIndexChanged(object sender, EventArgs e)
        {
            string route = cbxRoute.Text;
            getRouteDetails(route);

            var routeInfo = DB.DelRoutes.Where(y => y.rRouteID == cbxRoute.Text).FirstOrDefault();
            var driverDetails = DB.DelDrivers.Where(y => y.dEmpID == routeInfo.rDriverID).Select(x => new { x.dFirstName, x.dLastName }).FirstOrDefault();
            var assistantDetails = DB.DelDrivers.Where(y => y.dEmpID == routeInfo.rDriverAID).Select(x => new { x.dFirstName, x.dLastName }).FirstOrDefault();
            string dFirst = driverDetails.dFirstName.Replace(" ", "");
            string dLast = driverDetails.dLastName.Replace(" ", "");
            lblDriver.Text = dFirst + " " + dLast;
            lblCurrentDriver.Text = dFirst + " " + dLast;
            cbxChangeDriverTo.SelectedIndex = cbxChangeDriverTo.FindString(lblCurrentDriver.Text);

            string aFirst = assistantDetails.dFirstName.Replace(" ", "");
            string aLast = assistantDetails.dLastName.Replace(" ", "");
            lblAsstDriver.Text = aFirst + " " + aLast;
            lblCurrentASstDriver.Text = aFirst + " " + aLast;
            cbxChangeAsstDriverTo.SelectedIndex = cbxChangeAsstDriverTo.FindString(lblCurrentASstDriver.Text);

            lblTruck.Text = DB.DelAssets.Where(y => y.tAID == routeInfo.rTruckID).Select(x => x.tModel).FirstOrDefault();
            lblCurrentTruck.Text = DB.DelAssets.Where(y => y.tAID == routeInfo.rTruckID).Select(x => x.tAID).FirstOrDefault();
            cbxChangeTruckTo.SelectedIndex = cbxChangeTruckTo.FindString(lblCurrentTruck.Text);

            lblTrailer.Text = DB.DelAssets.Where(y => y.tAID == routeInfo.rTrailerID).Select(x => x.tModel).FirstOrDefault();
            lblCurrentTrailer.Text = DB.DelAssets.Where(y => y.tAID == routeInfo.rTrailerID).Select(x => x.tAID).FirstOrDefault();
            cbxChangeTrailerTo.SelectedIndex = cbxChangeTrailerTo.FindString(lblCurrentTrailer.Text);

            this.dgRouteInfo.DataSource = null;

            populateDTs();

            lblNumofStops.Text = data.NumberOFStops.ToString();
        }

        private void cbxChangeRoute_SelectedIndexChanged(object sender, EventArgs e)
        {
            string route = cbxChangeRoute.Text;
            getRouteDetails(route);

            dgvChangeAddStops.DataSource = null;
            dgvChangeAddStops.Rows.Clear();
            dgvChangeAddStops.Refresh();

            populateChangeDTs();
        }

        private void cbxDeliveryRoutes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string route = cbxDeliveryRoutes.Text;
            getRouteDetails(route);

            this.dgvDeliveryStatusStops.DataSource = null;
            this.dgvDeliveryStatusDetails.DataSource = null;
            populateDeliveryDTs();
        }

        private void cbxAddAsset_SelectedIndexChanged(object sender, EventArgs e)
        {
            hideVisibleAddAssetPanels();
            switch (cbxAddAsset.Text)
            {
                case "Driver":
                    pnlAddDriver.Visible = true;
                    break;
                case "Assistant Driver":
                    pnlAddADriver.Visible = true;
                    break;
                case "Truck":
                    pnlAddTruck.Visible = true;
                    break;
                case "Trailer":
                    pnlAddTrailer.Visible = true;
                    break;
            }
        }



        private void dgRouteInfo_Navigate(object sender, NavigateEventArgs ne)
        {
            int rowCount = iChildRowCount;

            //lblUnitCount.Text = " There are " + rowCount.ToString() + " units in this stop.";
            rowCount = 0;
        }

        private void dgvChangeAddStops_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            string checkVal = dgvChangeAddStops.Rows[dgvChangeAddStops.CurrentCell.RowIndex].Cells[0].Value.ToString();

            if (checkVal != "")
            {
                string routeToEdit = cbxChangeRoute.Text;
                var SelectedStop = Convert.ToInt32(dgvChangeAddStops.CurrentRow.Cells[0].Value);
                int? Stop = SelectedStop;

                var StopID = dgvChangeAddStops.CurrentRow.Cells[1].Value;
                string stopID = StopID.ToString();
                var PickTicket = dgvChangeAddStops.CurrentRow.Cells[2].Value;
                long PickTicketNum = Convert.ToInt32(PickTicket);
                int rowNumToDelete = dgvChangeAddStops.Rows.IndexOf(dgvChangeAddStops.CurrentRow);
                int startingRow = 0;
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete Stop: " + Stop + "?", "Delete Selected Stop", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    //Reorder the grid to make the deleted stop dissappear
                    int DTRowCount = dgvChangeAddStops.Rows.Count - 1;
                    startingRow = rowNumToDelete + 1;
                    for (int i = startingRow; i < DTRowCount; i++)
                    {
                        dgvChangeAddStops.Rows[i].Cells[0].Value = i;
                    }

                    //Getting all stop data in selected route for use a little later...
                    var selectedRouteStopData = DB.DelStops.Where(y => y.rRouteID == routeToEdit);

                    //DELTING STOP
                    var deleteRecord = DB.DelStops.Where(y => y.rRouteID == routeToEdit && y.sPTNum == PickTicketNum && y.sStopID == stopID && y.sStopNum == Stop).FirstOrDefault();
                    //DB.DelStops.Remove(deleteRecord);
                    //DB.SaveChanges();


                    //Changing all stop numbers below the deleted stop so the order stays contigeous.
                    foreach (var stop in selectedRouteStopData)
                    {
                        if (stop.sStopNum > Stop)
                        {
                            var updateStops = DB.DelStops.Where(y => y.rRouteID == routeToEdit && y.sPTNum == stop.sPTNum && y.sStopID == stop.sStopID).FirstOrDefault();
                            updateStops.sStopNum = updateStops.sStopNum - 1;
                            //DB.SaveChanges();
                        }
                    }

                    MessageBox.Show("Stop deleted.");
                }
                else if (dialogResult == DialogResult.No)
                {
                    e.Cancel = true;
                    MessageBox.Show("Disaster averted.");
                }
                else
                {
                    dgvChangeAddStops.Rows.RemoveAt(dgvChangeAddStops.CurrentCell.RowIndex);
                }
            }
            
        }

        private void dgvChangeAddStops_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string justDate = dtpMain.Value.ToString("yyyy-MM-dd");
                DateTime dt = Convert.ToDateTime(justDate);            
                var stopIDs = DB.DelStops.Where(y => y.sDate == dt && y.sStopID.Contains("HOU")).Select(x => x.sStopID).ToList();
                var lastStop = stopIDs[stopIDs.Count - 1];
                string sStopID = Regex.Replace(lastStop, "[A-Za-z ]", "");
                int stopIDnum = Convert.ToInt32(sStopID);
                stopIDnum = stopIDnum++;

                string route = cbxChangeRoute.Text;
                string stopID = cbxLocPrefix.Text + stopIDnum;
                
                dgvChangeAddStops.Rows[dgvChangeAddStops.CurrentRow.Index - 1].Cells[0].Value = Convert.ToInt32(dgvChangeAddStops.Rows[dgvChangeAddStops.CurrentRow.Index - 2].Cells[0].Value) + 1;
                dgvChangeAddStops.Rows[dgvChangeAddStops.CurrentRow.Index - 1].Cells[1].Value = stopID;

                DelStop DS = new DelStop();

                DS.rRouteID = route;
                DS.sStopID = stopID;
                DS.sPTNum = Convert.ToInt32(dgvChangeAddStops.Rows[dgvChangeAddStops.CurrentRow.Index - 1].Cells[2].Value);
                DS.sStatus = 1;
                DS.sAddress = null;
                DS.sSubdivision = null;
                DS.sDate = dt;
                DS.sStopNum = Convert.ToInt32(dgvChangeAddStops.Rows[dgvChangeAddStops.CurrentRow.Index - 1].Cells[0].Value);
                DS.sLatt = null;
                DS.sLong = null;
                DS.sDelTStamp = null;
                //DB.DelStops.Add(DS);
                //DB.SaveChanges();

                dgvChangeAddStops.FirstDisplayedScrollingRowIndex = dgvChangeAddStops.Rows.Count - 1;
                dgvChangeAddStops.Rows[dgvChangeAddStops.Rows.Count - 1].Cells[2].Selected = true;
                dgvChangeAddStops.BeginEdit(true);
            }
        }

        private void dgvAddStops_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string justDate = dtpMain.Value.ToString("yyyy-MM-dd");
                DateTime dt = Convert.ToDateTime(justDate);
                var stopIDs = DB.DelStops.Where(y => y.sDate == dt && y.sStopID.Contains("HOU")).Select(x => x.sStopID).ToList();
                var lastStop = stopIDs[stopIDs.Count - 1];
                string sStopID = Regex.Replace(lastStop, "[A-Za-z ]", "");
                int stopIDnum = Convert.ToInt32(sStopID);
                stopIDnum = stopIDnum++;

                string route = cbxChangeRoute.Text;
                string stopID = cbxLocPrefix.Text + stopIDnum;

                if(dgvAddStops.Rows.Count <= 2)
                {
                    dgvAddStops.Rows[dgvAddStops.CurrentRow.Index - 1].Cells[0].Value = 1;
                }
                else
                {
                    dgvAddStops.Rows[dgvAddStops.CurrentRow.Index - 1].Cells[0].Value = Convert.ToInt32(dgvAddStops.Rows[dgvAddStops.CurrentRow.Index - 2].Cells[0].Value) + 1;
                }
                
                dgvAddStops.Rows[dgvAddStops.CurrentRow.Index - 1].Cells[1].Value = stopID;

                DelStop DS = new DelStop();

                DS.rRouteID = route;
                DS.sStopID = stopID;
                DS.sPTNum = Convert.ToInt32(dgvAddStops.Rows[dgvAddStops.CurrentRow.Index - 1].Cells[2].Value);
                DS.sStatus = 1;
                DS.sAddress = null;
                DS.sSubdivision = null;
                DS.sDate = dt;
                DS.sStopNum = Convert.ToInt32(dgvAddStops.Rows[dgvAddStops.CurrentRow.Index - 1].Cells[0].Value);
                DS.sLatt = null;
                DS.sLong = null;
                DS.sDelTStamp = null;
                //DB.DelStops.Add(DS);
                //DB.SaveChanges();

                dgvAddStops.FirstDisplayedScrollingRowIndex = dgvAddStops.Rows.Count - 1;
                dgvAddStops.Rows[dgvAddStops.Rows.Count - 1].Cells[2].Selected = true;
                dgvAddStops.BeginEdit(true);
            }
        }

        private void dgvDeliveryStatusStops_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string PT = "";
            if (e.RowIndex > -1 && dgvDeliveryStatusStops.Rows[e.RowIndex].Cells[2].Value != null)
            {
                PT = dgvDeliveryStatusStops.Rows[e.RowIndex].Cells[2].Value.ToString();
            }

            populateDeliveryDetailsDT(PT, 1);
        }

        

        private void txtPickTicketSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                string PTSearch = txtPickTicketSearch.Text;
                cbxDeliveryRoutes.DataSource = null;
                populateDeliveryDetailsDT(PTSearch, 2);
            }
        }

        private void txtJobIDSearch_KeyUp(object sender, KeyEventArgs e)
        {
            string JobIDSearch = txtJobIDSearch.Text;
            cbxDeliveryRoutes.DataSource = null;
            populateDeliveryDetailsDT(JobIDSearch, 3);
        }

        

        private void getDeliveryChanges_Tick(object sender, EventArgs e)
        {
            data data = new data();
            string theDate = dtpMain.Value.ToShortDateString();
            
            DateTime SelectedDateTime = DateTime.Parse(theDate);
            
            var routes = DB.DelRoutes.Where(y => y.rRouteID.Contains(cbxLocation.Text) && y.rDate == SelectedDateTime).Select(x => x.rRouteID).ToList();
            List<Routes> tempList = new List<Routes>();
            List<Routes> addList = new List<Routes>();

            if (data.ListCurrentDeliveryRoutes != null)
            {
                foreach (var R in routes)
                {
                    Routes addRoute = new Routes();
                    addRoute.routeNumber = R.ToString();
                    tempList.Add(addRoute);
                }
                List<Routes> getRouteDiff = data.ListCurrentDeliveryRoutes.Except(tempList).ToList();
                data.ListCurrentDeliveryRoutes.AddRange(getRouteDiff);
                getBackorderItems(data.ListCurrentDeliveryRoutes);
            }
            else
            {
                foreach (var R in routes)
                {
                    Routes addRoute = new Routes();
                    addRoute.routeNumber = R.ToString();
                    tempList.Add(addRoute);
                }
                data.ListCurrentDeliveryRoutes = tempList;
                getBackorderItems(data.ListCurrentDeliveryRoutes);
            }
        }

        private void tcMain_Selected(object sender, TabControlEventArgs e)
        {
            string pageName = tcMain.SelectedTab.Text;
            if (pageName == "Status")
            {
                //populateDeliveryDTs();
                //MessageBox.Show("You have selected the Status Tab");

            }
        }

        private void tcMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = tcMain.SelectedTab.Name;
            if (name == "tabAddDelAssets")
            {
                cbxDelDriver.Text = "";
                cbxDelADriver.Text = "";
                cbxDelTruck.Text = "";
                cbxDelTrailer.Text = "";
            }
        }

        private void dtpMain_ValueChanged(object sender, EventArgs e)
        {
            //Get DateTime String.
            string theDate = dtpMain.Value.ToShortDateString();
            DateTime SelectedDateTime = DateTime.Parse(theDate);
            //Get list of routes for date selected.
            var routes = DB.DelRoutes.Where(y => y.rRouteID.Contains(cbxLocation.Text) && y.rDate == SelectedDateTime).Select(x => x.rRouteID).ToList();
            //Populate the various route dropdowns with the route list for the selected date.
            cbxRoute.DataSource = routes;
            cbxChangeRoute.DataSource = routes;
            cbxDeliveryRoutes.DataSource = routes;
            txtPickTicketSearch.Text = "";
            txtJobIDSearch.Text = "";

            lblCreateDate.Text = dtpMain.Value.Date.ToString("MM/dd/yyyy");
        }



        public void startTimer()
        {
            Timer getDeliveryChanges = new Timer();
            getDeliveryChanges.Interval = (2 * 60 * 1000); // 45 mins
            getDeliveryChanges.Tick += new EventHandler(getDeliveryChanges_Tick);
            getDeliveryChanges.Start();
        }

        public void getRouteDetails(string route)
        {
            data data = new data();
            data.getRouteDetails(route);
        }

        private void clearAllAssetFormFields()
        {
            //Driver
            txtbxDriverFirstName.Text = "";
            txtbxDriverLastName.Text = "";
            txtbxEmpID.Text = "";

            //Assistant Driver
            txtbxADriverEmpID.Text = "";
            txtbxADriverFirstName.Text = "";
            txtbxADriverLastName.Text = "";

            //Truck
            txtbxTrailerAssetID.Text = "";
            txtbxTruckAssetNumber.Text = "";
            txtbxTruckModel.Text = "";
            cbxTruckMaintType.Text = "";
            cbxTruckOther.Text = "";
            cbxTruckYear.Text = "";

            txtbxTrailerAssetID.Text = "";
            txtbxTrailerAssetNumber.Text = "";
            txtbxTrailerModel.Text = "";
            cbxTrailerMaintType.Text = "";
            cbxTrailerType.Text = "";
            cbxTrailerYear.Text = "";
        }

        public void hideVisibleAddAssetPanels()
        {
            pnlAddDriver.Visible = false;
            pnlAddADriver.Visible = false;
            pnlAddTruck.Visible = false;
            pnlAddTrailer.Visible = false;
        }

        public void getBackorderItems(List<Routes> diffRoutes)
        {
            foreach (var RT in diffRoutes)
            {
                string routeNum = RT.ToString();

                bool checkDelivery = DB.DelStops.Any(y => y.rRouteID == routeNum);

                if (checkDelivery == true)
                {
                    int iOrdered = 0;
                    int iDelivered = 0;
                    var routeDetails = DB.DelItems.Where(y => y.rRouteID == routeNum);
                    foreach (var deliveryItem in routeDetails)
                    {
                        iOrdered = iOrdered + Convert.ToInt32(deliveryItem.iQtyOrd);
                        iDelivered = iDelivered + Convert.ToInt32(deliveryItem.iQtyDel);
                    }
                    if (iOrdered > iDelivered)
                    {
                        MessageBox.Show("Check route " + routeNum + " for backordered units.");
                    }
                }
            }
        }


        //Handles numeric entries only for these fields.
        private void txtbxEmpID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtbxADriverEmpID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtbxTruckAssetNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtbxTrailerAssetNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
