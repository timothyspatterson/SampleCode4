﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.SqlServer;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BFS_Routing
{
    class data
    {
        ProductionValidationEntities DB = new ProductionValidationEntities();
        
        public static DataTable routeTable { get; set; }
        public static DataTable pickTicketTable { get; set; }
        public static List<RouteDetails> routeDetails { get; set; }
        public static int NumberOFStops { get; set; }
        public static List<Locations> listLocations { get; set; }
        public static List<Drivers> ListDrivers { get; set; }
        public static List<TrucksAndTrailers> ListTrucksTrailers { get; set; }
        public static List<LocPrefix> ListPrefixes { get; set; }
        public static List<BayID> ListBayIDs { get; set; }
        public static List<Routes> ListCurrentDeliveryRoutes { get; set; }

        public void getRouteDetails(string routeID)
        {
            DB.Database.CommandTimeout = 180;
            List<RouteDetails> tempList = new List<RouteDetails>();

            var queryA = DB.DelStops.Where(x => x.rRouteID == routeID).Select(y => new{ Stop = y.sStopNum, StopID = y.sStopID, PT = y.sPTNum}).ToList();

            foreach (var routeDetail in queryA)
            {
                string PTNUmber = routeDetail.PT.ToString();
                var queryB = DB.barinvs.Where(x => x.partno == PTNUmber).ToList();
                foreach (var ptDetails in queryB)
                {
                    RouteDetails rd = new RouteDetails();
                    rd.Route = routeID;
                    rd.Stop = routeDetail.Stop;
                    rd.StopID = routeDetail.StopID;

                    rd.PickTicket = ptDetails.partno;
                    rd.ItemID = ptDetails.id;
                    rd.SKU = ptDetails.sku;
                    rd.QTY = ptDetails.qty;
                    rd.JobID = ptDetails.desc1;
                    rd.CustPO = ptDetails.custPO;

                    string LDate = ptDetails.loaddate.ToString();
                    DateTime dt = Convert.ToDateTime(LDate);
                    //DateTime date = DateTime.ParseExact(LDate, "mm/dd/yyyy", null);
                    rd.ShipDate = dt;

                    //rd.ShipDate = ptDetails.loaddate;

                    tempList.Add(rd);
                }
            }
            routeDetails = tempList;
            NumberOFStops = queryA.Count;
            //NumberOFStops = Convert.ToInt32(routeDetails[routeDetails.Count - 1].Stop);
        }

        public void populateLocationList()
        {
            List<Locations> tempList = new List<Locations>();
            tempList.Add(new Locations() { LocationCode = ""});
            tempList.Add(new Locations() { LocationCode = "ABERSDYD" });
            tempList.Add(new Locations() { LocationCode = "ALBAGAYD" });
            tempList.Add(new Locations() { LocationCode = "ALBENCMF" });
            tempList.Add(new Locations() { LocationCode = "ALBENCWP" });
            tempList.Add(new Locations() { LocationCode = "ALBUNMAD" });
            tempList.Add(new Locations() { LocationCode = "ALBUNMMF" });
            tempList.Add(new Locations() { LocationCode = "ALBUNMMW" });
            tempList.Add(new Locations() { LocationCode = "ALBUNMRL" });
            tempList.Add(new Locations() { LocationCode = "ALBUNMSA" });
            tempList.Add(new Locations() { LocationCode = "ALBUNMYD" });
            tempList.Add(new Locations() { LocationCode = "ALEXMNYD" });
            tempList.Add(new Locations() { LocationCode = "ALGOIAYD" });
            tempList.Add(new Locations() { LocationCode = "ALMAMIYD" });
            tempList.Add(new Locations() { LocationCode = "ALPEMIYD" });
            tempList.Add(new Locations() { LocationCode = "ALTOPAYD" });
            tempList.Add(new Locations() { LocationCode = "ANCCAKYD" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKAD" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKCR" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKDC" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKHQ" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKLA" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKMF" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKMW" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKPA" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKSB" });
            tempList.Add(new Locations() { LocationCode = "ANCHAKYD" });
            tempList.Add(new Locations() { LocationCode = "ANCHALDC" });
            tempList.Add(new Locations() { LocationCode = "ANCPAKYD" });
            tempList.Add(new Locations() { LocationCode = "ARLIWACR" });
            tempList.Add(new Locations() { LocationCode = "ARLIWAMF" });
            tempList.Add(new Locations() { LocationCode = "ARLIWAYD" });
            tempList.Add(new Locations() { LocationCode = "ASPNCOYD" });
            tempList.Add(new Locations() { LocationCode = "ATLAGAAD" });
            tempList.Add(new Locations() { LocationCode = "ATLAGAMW" });
            tempList.Add(new Locations() { LocationCode = "ATLAGASA" });
            tempList.Add(new Locations() { LocationCode = "AUBUMIMW" });
            tempList.Add(new Locations() { LocationCode = "BAINWAYD" });
            tempList.Add(new Locations() { LocationCode = "BAKEORYD" });
            tempList.Add(new Locations() { LocationCode = "BAYPNYYD" });
            tempList.Add(new Locations() { LocationCode = "BDAXMIYD" });
            tempList.Add(new Locations() { LocationCode = "BEAVORCR" });
            tempList.Add(new Locations() { LocationCode = "BEAVORMF" });
            tempList.Add(new Locations() { LocationCode = "BELLPAGP" });
            tempList.Add(new Locations() { LocationCode = "BEMIMNYD" });
            tempList.Add(new Locations() { LocationCode = "BENDORYD" });
            tempList.Add(new Locations() { LocationCode = "BERLNJAD" });
            tempList.Add(new Locations() { LocationCode = "BERLNJMF" });
            tempList.Add(new Locations() { LocationCode = "BERLNJWP" });
            tempList.Add(new Locations() { LocationCode = "BFSCAT" });
            tempList.Add(new Locations() { LocationCode = "BFSCSE" });
            tempList.Add(new Locations() { LocationCode = "BFSDAT" });
            tempList.Add(new Locations() { LocationCode = "BFSDTXRE" });
            tempList.Add(new Locations() { LocationCode = "BFSFRM" });
            tempList.Add(new Locations() { LocationCode = "BFSINCRE" });
            tempList.Add(new Locations() { LocationCode = "BFSSTXRE" });
            tempList.Add(new Locations() { LocationCode = "BFSTEXRE" });
            tempList.Add(new Locations() { LocationCode = "BIGLAKAD" });
            tempList.Add(new Locations() { LocationCode = "BIGLAKMF" });
            tempList.Add(new Locations() { LocationCode = "BIGLAKYD" });
            tempList.Add(new Locations() { LocationCode = "BILLMTYD" });
            tempList.Add(new Locations() { LocationCode = "BONDMARL" });
            tempList.Add(new Locations() { LocationCode = "BOONIAYD" });
            tempList.Add(new Locations() { LocationCode = "BOWLKYMF" });
            tempList.Add(new Locations() { LocationCode = "BRADFLSA" });
            tempList.Add(new Locations() { LocationCode = "BRADFLYD" });
            tempList.Add(new Locations() { LocationCode = "BRAIMNYD" });
            tempList.Add(new Locations() { LocationCode = "BRAROKAD" });
            tempList.Add(new Locations() { LocationCode = "BRAROKDC" });
            tempList.Add(new Locations() { LocationCode = "BRAROKGP" });
            tempList.Add(new Locations() { LocationCode = "BRAROKMW" });
            tempList.Add(new Locations() { LocationCode = "BRAROKWN" });
            tempList.Add(new Locations() { LocationCode = "BRAROKYD" });
            tempList.Add(new Locations() { LocationCode = "BREEILYD" });
            tempList.Add(new Locations() { LocationCode = "BROONYMA" });
            tempList.Add(new Locations() { LocationCode = "BROONYYD" });
            tempList.Add(new Locations() { LocationCode = "BROOSDYD" });
            tempList.Add(new Locations() { LocationCode = "BROWWIMF" });
            tempList.Add(new Locations() { LocationCode = "BRVLFLYD" });
            tempList.Add(new Locations() { LocationCode = "BRWDAKAD" });
            tempList.Add(new Locations() { LocationCode = "BRWDAKMF" });
            tempList.Add(new Locations() { LocationCode = "BUDATXMF" });
            tempList.Add(new Locations() { LocationCode = "BUDATXWP" });
            tempList.Add(new Locations() { LocationCode = "BUDATXYD" });
            tempList.Add(new Locations() { LocationCode = "BUTEMTDC" });
            tempList.Add(new Locations() { LocationCode = "BUTEMTYD" });
            tempList.Add(new Locations() { LocationCode = "CADIMIYD" });
            tempList.Add(new Locations() { LocationCode = "CAMDNJGP" });
            tempList.Add(new Locations() { LocationCode = "CAMDNJRL" });
            tempList.Add(new Locations() { LocationCode = "CAROMIYD" });
            tempList.Add(new Locations() { LocationCode = "CARRTXMF" });
            tempList.Add(new Locations() { LocationCode = "CARRTXWP" });
            tempList.Add(new Locations() { LocationCode = "CARRTXYD" });
            tempList.Add(new Locations() { LocationCode = "CASPWYYD" });
            tempList.Add(new Locations() { LocationCode = "CCASYD" });
            tempList.Add(new Locations() { LocationCode = "CDENDT" });
            tempList.Add(new Locations() { LocationCode = "CDENYD" });
            tempList.Add(new Locations() { LocationCode = "CEDAIAAD" });
            tempList.Add(new Locations() { LocationCode = "CFOUMF" });
            tempList.Add(new Locations() { LocationCode = "CFOUYD" });
            tempList.Add(new Locations() { LocationCode = "CHAMPARL" });
            tempList.Add(new Locations() { LocationCode = "CHANVAGP" });
            tempList.Add(new Locations() { LocationCode = "CHARNCAD" });
            tempList.Add(new Locations() { LocationCode = "CHARNCGP" });
            tempList.Add(new Locations() { LocationCode = "CHARNCSA" });
            tempList.Add(new Locations() { LocationCode = "CHARNCYD" });
            tempList.Add(new Locations() { LocationCode = "CHARVAGP" });
            tempList.Add(new Locations() { LocationCode = "CHARVAYD" });
            tempList.Add(new Locations() { LocationCode = "CHARWVYD" });
            tempList.Add(new Locations() { LocationCode = "CHATTNYD" });
            tempList.Add(new Locations() { LocationCode = "CHESVAAD" });
            tempList.Add(new Locations() { LocationCode = "CHESVAGP" });
            tempList.Add(new Locations() { LocationCode = "CHESVAMW" });
            tempList.Add(new Locations() { LocationCode = "CHESVARL" });
            tempList.Add(new Locations() { LocationCode = "CHESVAYD" });
            tempList.Add(new Locations() { LocationCode = "CHIPWIAD" });
            tempList.Add(new Locations() { LocationCode = "CHSTVAAD" });
            tempList.Add(new Locations() { LocationCode = "CHSTVAMW" });
            tempList.Add(new Locations() { LocationCode = "CHSTVASA" });
            tempList.Add(new Locations() { LocationCode = "CHSTVAYD" });
            tempList.Add(new Locations() { LocationCode = "CINCOHAD" });
            tempList.Add(new Locations() { LocationCode = "CINCOHSA" });
            tempList.Add(new Locations() { LocationCode = "CINCOHYD" });
            tempList.Add(new Locations() { LocationCode = "CLACORAD" });
            tempList.Add(new Locations() { LocationCode = "CLACORMW" });
            tempList.Add(new Locations() { LocationCode = "CLACORYD" });
            tempList.Add(new Locations() { LocationCode = "CLAYNCYD" });
            tempList.Add(new Locations() { LocationCode = "CLWAFLSA" });
            tempList.Add(new Locations() { LocationCode = "CLWAFLYD" });
            tempList.Add(new Locations() { LocationCode = "COASNCAD" });
            tempList.Add(new Locations() { LocationCode = "CODYWYYD" });
            tempList.Add(new Locations() { LocationCode = "COKAMNYD" });
            tempList.Add(new Locations() { LocationCode = "COLCOR" });
            tempList.Add(new Locations() { LocationCode = "COLLTXYD" });
            tempList.Add(new Locations() { LocationCode = "COLUGAYD" });
            tempList.Add(new Locations() { LocationCode = "CONGNYYD" });
            tempList.Add(new Locations() { LocationCode = "CONRTXYD" });
            tempList.Add(new Locations() { LocationCode = "CONWSCYD" });
            tempList.Add(new Locations() { LocationCode = "COOKTNAD" });
            tempList.Add(new Locations() { LocationCode = "COOKTNYD" });
            tempList.Add(new Locations() { LocationCode = "COOSORSA" });
            tempList.Add(new Locations() { LocationCode = "COOSORYD" });
            tempList.Add(new Locations() { LocationCode = "CORTCOYD" });
            tempList.Add(new Locations() { LocationCode = "COSPCOMF" });
            tempList.Add(new Locations() { LocationCode = "COSPCOMW" });
            tempList.Add(new Locations() { LocationCode = "COSPCOYD" });
            tempList.Add(new Locations() { LocationCode = "CZZCOR" });
            tempList.Add(new Locations() { LocationCode = "CZZEEN" });
            tempList.Add(new Locations() { LocationCode = "DALLTXDC" });
            tempList.Add(new Locations() { LocationCode = "DAVEIAYD" });
            tempList.Add(new Locations() { LocationCode = "DAYTOHYD" });
            tempList.Add(new Locations() { LocationCode = "DELAMNDC" });
            tempList.Add(new Locations() { LocationCode = "DELAMNYD" });
            tempList.Add(new Locations() { LocationCode = "DELANDYD" });
            tempList.Add(new Locations() { LocationCode = "DELANJRL" });
            tempList.Add(new Locations() { LocationCode = "DELAOHMF" });
            tempList.Add(new Locations() { LocationCode = "DELAOHYD" });
            tempList.Add(new Locations() { LocationCode = "DENVCOAD" });
            tempList.Add(new Locations() { LocationCode = "DENVCOHQ" });
            tempList.Add(new Locations() { LocationCode = "DENVCOLN" });
            tempList.Add(new Locations() { LocationCode = "DENVCOOP" });
            tempList.Add(new Locations() { LocationCode = "DENVCORE" });
            tempList.Add(new Locations() { LocationCode = "DENVCOTA" });
            tempList.Add(new Locations() { LocationCode = "DENVCOWP" });
            tempList.Add(new Locations() { LocationCode = "DEPRWIMF" });
            tempList.Add(new Locations() { LocationCode = "DEPRWIMW" });
            tempList.Add(new Locations() { LocationCode = "DEPRWISA" });
            tempList.Add(new Locations() { LocationCode = "DICKNDYD" });
            tempList.Add(new Locations() { LocationCode = "DOLOCOMF" });
            tempList.Add(new Locations() { LocationCode = "DOVEMNMW" });
            tempList.Add(new Locations() { LocationCode = "DUBUIAYD" });
            tempList.Add(new Locations() { LocationCode = "DULUGADC" });
            tempList.Add(new Locations() { LocationCode = "DULUGAYD" });
            tempList.Add(new Locations() { LocationCode = "DURACOYD" });
            tempList.Add(new Locations() { LocationCode = "DURHNCIS" });
            tempList.Add(new Locations() { LocationCode = "DURHNCMW" });
            tempList.Add(new Locations() { LocationCode = "EAGAMNDC" });
            tempList.Add(new Locations() { LocationCode = "EAGLAKYD" });
            tempList.Add(new Locations() { LocationCode = "EASTMDYD" });
            tempList.Add(new Locations() { LocationCode = "EASTPAYD" });
            tempList.Add(new Locations() { LocationCode = "EAUCWIYD" });
            tempList.Add(new Locations() { LocationCode = "EHARCTAD" });
            tempList.Add(new Locations() { LocationCode = "EHARCTGP" });
            tempList.Add(new Locations() { LocationCode = "EHARCTYD" });
            tempList.Add(new Locations() { LocationCode = "ELCACAHC" });
            tempList.Add(new Locations() { LocationCode = "ELIZNJGP" });
            tempList.Add(new Locations() { LocationCode = "ELIZNJYD" });
            tempList.Add(new Locations() { LocationCode = "ELKAIAYD" });
            tempList.Add(new Locations() { LocationCode = "ELLEINYD" });
            tempList.Add(new Locations() { LocationCode = "ESCOCAHC" });
            tempList.Add(new Locations() { LocationCode = "FAIPAKYD" });
            tempList.Add(new Locations() { LocationCode = "FAIRAKYD" });
            tempList.Add(new Locations() { LocationCode = "FARMNMYD" });
            tempList.Add(new Locations() { LocationCode = "FARMNYAD" });
            tempList.Add(new Locations() { LocationCode = "FARMNYSA" });
            tempList.Add(new Locations() { LocationCode = "FARMNYYD" });
            tempList.Add(new Locations() { LocationCode = "FAYENCGP" });
            tempList.Add(new Locations() { LocationCode = "FAYENCYD" });
            tempList.Add(new Locations() { LocationCode = "FELTCAHC" });
            tempList.Add(new Locations() { LocationCode = "FERGMNYD" });
            tempList.Add(new Locations() { LocationCode = "FERNWAYD" });
            tempList.Add(new Locations() { LocationCode = "FIFEWAYD" });
            tempList.Add(new Locations() { LocationCode = "FLAGAZAD" });
            tempList.Add(new Locations() { LocationCode = "FLAGAZCR" });
            tempList.Add(new Locations() { LocationCode = "FLAGAZDC" });
            tempList.Add(new Locations() { LocationCode = "FLAGAZYD" });
            tempList.Add(new Locations() { LocationCode = "FOGRORYD" });
            tempList.Add(new Locations() { LocationCode = "FRANTNMF" });
            tempList.Add(new Locations() { LocationCode = "FREDMDGP" });
            tempList.Add(new Locations() { LocationCode = "FREDMDSA" });
            tempList.Add(new Locations() { LocationCode = "FREDMDYD" });
            tempList.Add(new Locations() { LocationCode = "FREDTXYD" });
            tempList.Add(new Locations() { LocationCode = "FREDVAGP" });
            tempList.Add(new Locations() { LocationCode = "FREMMIYD" });
            tempList.Add(new Locations() { LocationCode = "FRIDMNRL" });
            tempList.Add(new Locations() { LocationCode = "FTATWIYD" });
            tempList.Add(new Locations() { LocationCode = "FTWOTXYD" });
            tempList.Add(new Locations() { LocationCode = "GARDKSYD" });
            tempList.Add(new Locations() { LocationCode = "GARNNCGP" });
            tempList.Add(new Locations() { LocationCode = "GAYLMIYD" });
            tempList.Add(new Locations() { LocationCode = "GEORTXAD" });
            tempList.Add(new Locations() { LocationCode = "GEORTXSA" });
            tempList.Add(new Locations() { LocationCode = "GEORTXYD" });
            tempList.Add(new Locations() { LocationCode = "GIGHWAYD" });
            tempList.Add(new Locations() { LocationCode = "GLENCOYD" });
            tempList.Add(new Locations() { LocationCode = "GLENMTRL" });
            tempList.Add(new Locations() { LocationCode = "GLENMTYD" });
            tempList.Add(new Locations() { LocationCode = "GLOUNJDC" });
            tempList.Add(new Locations() { LocationCode = "GLOUNJMW" });
            tempList.Add(new Locations() { LocationCode = "GRAHWAYD" });
            tempList.Add(new Locations() { LocationCode = "GRAYMIYD" });
            tempList.Add(new Locations() { LocationCode = "GRAYTNYD" });
            tempList.Add(new Locations() { LocationCode = "GRBONCGP" });
            tempList.Add(new Locations() { LocationCode = "GRFAMTYD" });
            tempList.Add(new Locations() { LocationCode = "GRJUCOAD" });
            tempList.Add(new Locations() { LocationCode = "GRJUCORL" });
            tempList.Add(new Locations() { LocationCode = "GRJUCOYD" });
            tempList.Add(new Locations() { LocationCode = "GRVLWIYD" });
            tempList.Add(new Locations() { LocationCode = "GRVWMOAD" });
            tempList.Add(new Locations() { LocationCode = "GRVWMOMW" });
            tempList.Add(new Locations() { LocationCode = "GRVWMOSA" });
            tempList.Add(new Locations() { LocationCode = "GRWDWIYD" });
            tempList.Add(new Locations() { LocationCode = "HAGEMDAD" });
            tempList.Add(new Locations() { LocationCode = "HARRPAGP" });
            tempList.Add(new Locations() { LocationCode = "HASTMNYD" });
            tempList.Add(new Locations() { LocationCode = "HATTMSYD" });
            tempList.Add(new Locations() { LocationCode = "HAVRMTYD" });
            tempList.Add(new Locations() { LocationCode = "HAWAIAMF" });
            tempList.Add(new Locations() { LocationCode = "HAWAIARL" });
            tempList.Add(new Locations() { LocationCode = "HAWLMNYD" });
            tempList.Add(new Locations() { LocationCode = "HBUNMF" });
            tempList.Add(new Locations() { LocationCode = "HBUNWN" });
            tempList.Add(new Locations() { LocationCode = "HBUNYD" });
            tempList.Add(new Locations() { LocationCode = "HCHSDC" });
            tempList.Add(new Locations() { LocationCode = "HEBRUTYD" });
            tempList.Add(new Locations() { LocationCode = "HELEMTAD" });
            tempList.Add(new Locations() { LocationCode = "HELEMTYD" });
            tempList.Add(new Locations() { LocationCode = "HENDNCGP" });
            tempList.Add(new Locations() { LocationCode = "HENDNCYD" });
            tempList.Add(new Locations() { LocationCode = "HERMORYD" });
            tempList.Add(new Locations() { LocationCode = "HFPFMF" });
            tempList.Add(new Locations() { LocationCode = "HFPFYD" });
            tempList.Add(new Locations() { LocationCode = "HGLFMF" });
            tempList.Add(new Locations() { LocationCode = "HGLFYD" });
            tempList.Add(new Locations() { LocationCode = "HJAXDC" });
            tempList.Add(new Locations() { LocationCode = "HJAXFP" });
            tempList.Add(new Locations() { LocationCode = "HJAXIN" });
            tempList.Add(new Locations() { LocationCode = "HJAXLM" });
            tempList.Add(new Locations() { LocationCode = "HJAXMF" });
            tempList.Add(new Locations() { LocationCode = "HJAXNT" });
            tempList.Add(new Locations() { LocationCode = "HJAXST" });
            tempList.Add(new Locations() { LocationCode = "HJAXVN" });
            tempList.Add(new Locations() { LocationCode = "HJAXWN" });
            tempList.Add(new Locations() { LocationCode = "HJAXWP" });
            tempList.Add(new Locations() { LocationCode = "HJAXWT" });
            tempList.Add(new Locations() { LocationCode = "HJAXYD" });
            tempList.Add(new Locations() { LocationCode = "HLAKMF" });
            tempList.Add(new Locations() { LocationCode = "HLAKYD" });
            tempList.Add(new Locations() { LocationCode = "HOISGR" });
            tempList.Add(new Locations() { LocationCode = "HOLCOR" });
            tempList.Add(new Locations() { LocationCode = "HOLTNYRL" });
            tempList.Add(new Locations() { LocationCode = "HOMRAKYD" });
            tempList.Add(new Locations() { LocationCode = "HOODWAYD" });
            tempList.Add(new Locations() { LocationCode = "HOPKKYYD" });
            tempList.Add(new Locations() { LocationCode = "HOTSSDYD" });
            tempList.Add(new Locations() { LocationCode = "HOUSTXAD" });
            tempList.Add(new Locations() { LocationCode = "HOUSTXMF" });
            tempList.Add(new Locations() { LocationCode = "HOUSTXMW" });
            tempList.Add(new Locations() { LocationCode = "HOUSTXRL" });
            tempList.Add(new Locations() { LocationCode = "HOUSTXSA" });
            tempList.Add(new Locations() { LocationCode = "HSANMF" });
            tempList.Add(new Locations() { LocationCode = "HTAFWP" });
            tempList.Add(new Locations() { LocationCode = "HTCFMF" });
            tempList.Add(new Locations() { LocationCode = "HTCFYD" });
            tempList.Add(new Locations() { LocationCode = "HUDVNYDC" });
            tempList.Add(new Locations() { LocationCode = "HUNTINYD" });
            tempList.Add(new Locations() { LocationCode = "HUROSDDC" });
            tempList.Add(new Locations() { LocationCode = "HUROSDMW" });
            tempList.Add(new Locations() { LocationCode = "HUROSDYD" });
            tempList.Add(new Locations() { LocationCode = "HWPFYD" });
            tempList.Add(new Locations() { LocationCode = "IAFAIAYD" });
            tempList.Add(new Locations() { LocationCode = "INDYINAD" });
            tempList.Add(new Locations() { LocationCode = "INDYINMW" });
            tempList.Add(new Locations() { LocationCode = "INDYINYD" });
            tempList.Add(new Locations() { LocationCode = "IRVGTXAD" });
            tempList.Add(new Locations() { LocationCode = "IRVGTXMW" });
            tempList.Add(new Locations() { LocationCode = "IRVGTXSA" });
            tempList.Add(new Locations() { LocationCode = "JACKFLYD" });
            tempList.Add(new Locations() { LocationCode = "JACKNCYD" });
            tempList.Add(new Locations() { LocationCode = "JAMENDYD" });
            tempList.Add(new Locations() { LocationCode = "JESSMDAD" });
            tempList.Add(new Locations() { LocationCode = "JESSMDGP" });
            tempList.Add(new Locations() { LocationCode = "JESSMDSA" });
            tempList.Add(new Locations() { LocationCode = "JOHNNYYD" });
            tempList.Add(new Locations() { LocationCode = "KALAMIYD" });
            tempList.Add(new Locations() { LocationCode = "KALIMTYD" });
            tempList.Add(new Locations() { LocationCode = "KATYTXYD" });
            tempList.Add(new Locations() { LocationCode = "KEARCAHC" });
            tempList.Add(new Locations() { LocationCode = "KENAAKMF" });
            tempList.Add(new Locations() { LocationCode = "KENAAKMW" });
            tempList.Add(new Locations() { LocationCode = "KENAAKYD" });
            tempList.Add(new Locations() { LocationCode = "KENNGAGP" });
            tempList.Add(new Locations() { LocationCode = "KENNGAHQ" });
            tempList.Add(new Locations() { LocationCode = "KENNGAMW" });
            tempList.Add(new Locations() { LocationCode = "KENNGAYD" });
            tempList.Add(new Locations() { LocationCode = "KENNORAD" });
            tempList.Add(new Locations() { LocationCode = "KENNWACR" });
            tempList.Add(new Locations() { LocationCode = "KENNWAMW" });
            tempList.Add(new Locations() { LocationCode = "KENNWAYD" });
            tempList.Add(new Locations() { LocationCode = "KINGPAGP" });
            tempList.Add(new Locations() { LocationCode = "KISSFLSA" });
            tempList.Add(new Locations() { LocationCode = "KNOXTNYD" });
            tempList.Add(new Locations() { LocationCode = "KODIAKAD" });
            tempList.Add(new Locations() { LocationCode = "KODIAKYD" });
            tempList.Add(new Locations() { LocationCode = "LACEWACR" });
            tempList.Add(new Locations() { LocationCode = "LACEWAHQ" });
            tempList.Add(new Locations() { LocationCode = "LACRVAMF" });
            tempList.Add(new Locations() { LocationCode = "LADSSCGP" });
            tempList.Add(new Locations() { LocationCode = "LADYFLMF" });
            tempList.Add(new Locations() { LocationCode = "LADYFLYD" });
            tempList.Add(new Locations() { LocationCode = "LAKENJGP" });
            tempList.Add(new Locations() { LocationCode = "LAKENJMW" });
            tempList.Add(new Locations() { LocationCode = "LAKENJYD" });
            tempList.Add(new Locations() { LocationCode = "LAKEORMF" });
            tempList.Add(new Locations() { LocationCode = "LAKETXMW" });
            tempList.Add(new Locations() { LocationCode = "LAKEWARL" });
            tempList.Add(new Locations() { LocationCode = "LANCPAGP" });
            tempList.Add(new Locations() { LocationCode = "LAPEMIYD" });
            tempList.Add(new Locations() { LocationCode = "LARAWYYD" });
            tempList.Add(new Locations() { LocationCode = "LASVNVGP" });
            tempList.Add(new Locations() { LocationCode = "LEESMOIS" });
            tempList.Add(new Locations() { LocationCode = "LEESMOYD" });
            tempList.Add(new Locations() { LocationCode = "LEWEDEGP" });
            tempList.Add(new Locations() { LocationCode = "LEXIKYAD" });
            tempList.Add(new Locations() { LocationCode = "LEXIKYYD" });
            tempList.Add(new Locations() { LocationCode = "LGHCOQAD" });
            tempList.Add(new Locations() { LocationCode = "LGOPCOAD" });
            tempList.Add(new Locations() { LocationCode = "LGOPCOAK" });
            tempList.Add(new Locations() { LocationCode = "LGOPCOAS" });
            tempList.Add(new Locations() { LocationCode = "LGOPCODM" });
            tempList.Add(new Locations() { LocationCode = "LGOPCOGN" });
            tempList.Add(new Locations() { LocationCode = "LGOPCOGW" });
            tempList.Add(new Locations() { LocationCode = "LIBENYYD" });
            tempList.Add(new Locations() { LocationCode = "LINCORYD" });
            tempList.Add(new Locations() { LocationCode = "LITTCOAD" });
            tempList.Add(new Locations() { LocationCode = "LITTCOMW" });
            tempList.Add(new Locations() { LocationCode = "LITTCOSA" });
            tempList.Add(new Locations() { LocationCode = "LITTCOYD" });
            tempList.Add(new Locations() { LocationCode = "LITTMNYD" });
            tempList.Add(new Locations() { LocationCode = "LKHAAZYD" });
            tempList.Add(new Locations() { LocationCode = "LKOTAKYD" });
            tempList.Add(new Locations() { LocationCode = "LKVLMNAD" });
            tempList.Add(new Locations() { LocationCode = "LKVLMNMW" });
            tempList.Add(new Locations() { LocationCode = "LKVLMNSA" });
            tempList.Add(new Locations() { LocationCode = "LKVLMNYD" });
            tempList.Add(new Locations() { LocationCode = "LKVWORYD" });
            tempList.Add(new Locations() { LocationCode = "LMESCAHC" });
            tempList.Add(new Locations() { LocationCode = "LMESCAMW" });
            tempList.Add(new Locations() { LocationCode = "LNPBKI" });
            tempList.Add(new Locations() { LocationCode = "LNPBMW" });
            tempList.Add(new Locations() { LocationCode = "LNPBST" });
            tempList.Add(new Locations() { LocationCode = "LNPBYD" });
            tempList.Add(new Locations() { LocationCode = "LNPNOM" });
            tempList.Add(new Locations() { LocationCode = "LNWCAM" });
            tempList.Add(new Locations() { LocationCode = "LNWCUV" });
            tempList.Add(new Locations() { LocationCode = "LNWESM" });
            tempList.Add(new Locations() { LocationCode = "LNWFRM" });
            tempList.Add(new Locations() { LocationCode = "LNWHAM" });
            tempList.Add(new Locations() { LocationCode = "LNWISM" });
            tempList.Add(new Locations() { LocationCode = "LNWLAM" });
            tempList.Add(new Locations() { LocationCode = "LNWMAV" });
            tempList.Add(new Locations() { LocationCode = "LOMIWIYD" });
            tempList.Add(new Locations() { LocationCode = "LONGCOMF" });
            tempList.Add(new Locations() { LocationCode = "LONGCOMW" });
            tempList.Add(new Locations() { LocationCode = "LONGCORL" });
            tempList.Add(new Locations() { LocationCode = "LONGCOYD" });
            tempList.Add(new Locations() { LocationCode = "LONGWAYD" });
            tempList.Add(new Locations() { LocationCode = "LOVECOYD" });
            tempList.Add(new Locations() { LocationCode = "LSANOG" });
            tempList.Add(new Locations() { LocationCode = "LSASFG" });
            tempList.Add(new Locations() { LocationCode = "LSCAPN" });
            tempList.Add(new Locations() { LocationCode = "LSCHAN" });
            tempList.Add(new Locations() { LocationCode = "LSCRAN" });
            tempList.Add(new Locations() { LocationCode = "LSCRLD" });
            tempList.Add(new Locations() { LocationCode = "LSCTAN" });
            tempList.Add(new Locations() { LocationCode = "LSCWFN" });
            tempList.Add(new Locations() { LocationCode = "LSOORF" });
            tempList.Add(new Locations() { LocationCode = "LSTCLT" });
            tempList.Add(new Locations() { LocationCode = "LSTFRT" });
            tempList.Add(new Locations() { LocationCode = "LSTGAT" });
            tempList.Add(new Locations() { LocationCode = "LSTMET" });
            tempList.Add(new Locations() { LocationCode = "LSTNAT" });
            tempList.Add(new Locations() { LocationCode = "LSTNIN" });
            tempList.Add(new Locations() { LocationCode = "LSTTAF" });
            tempList.Add(new Locations() { LocationCode = "LYNCVAYD" });
            tempList.Add(new Locations() { LocationCode = "MACKWIDC" });
            tempList.Add(new Locations() { LocationCode = "MACNGAYD" });
            tempList.Add(new Locations() { LocationCode = "MADIMNYD" });
            tempList.Add(new Locations() { LocationCode = "MADISDYD" });
            tempList.Add(new Locations() { LocationCode = "MADIWIDC" });
            tempList.Add(new Locations() { LocationCode = "MADIWIMW" });
            tempList.Add(new Locations() { LocationCode = "MAHONYYD" });
            tempList.Add(new Locations() { LocationCode = "MANCIAYD" });
            tempList.Add(new Locations() { LocationCode = "MANDNDYD" });
            tempList.Add(new Locations() { LocationCode = "MANKMNYD" });
            tempList.Add(new Locations() { LocationCode = "MANSOHYD" });
            tempList.Add(new Locations() { LocationCode = "MANVTXYD" });
            tempList.Add(new Locations() { LocationCode = "MARQMIYD" });
            tempList.Add(new Locations() { LocationCode = "MASNIAYD" });
            tempList.Add(new Locations() { LocationCode = "MCALTXCO" });
            tempList.Add(new Locations() { LocationCode = "MCALTXDC" });
            tempList.Add(new Locations() { LocationCode = "MCALTXRL" });
            tempList.Add(new Locations() { LocationCode = "MCALTXYD" });
            tempList.Add(new Locations() { LocationCode = "MCCAIDYD" });
            tempList.Add(new Locations() { LocationCode = "MCMNORYD" });
            tempList.Add(new Locations() { LocationCode = "MENOWIYD" });
            tempList.Add(new Locations() { LocationCode = "MERCTXAD" });
            tempList.Add(new Locations() { LocationCode = "MERCTXMF" });
            tempList.Add(new Locations() { LocationCode = "MERCTXMW" });
            tempList.Add(new Locations() { LocationCode = "MERCTXSA" });
            tempList.Add(new Locations() { LocationCode = "MERCTXYD" });
            tempList.Add(new Locations() { LocationCode = "MERIIDAD" });
            tempList.Add(new Locations() { LocationCode = "MERIIDGP" });
            tempList.Add(new Locations() { LocationCode = "MERIIDMW" });
            tempList.Add(new Locations() { LocationCode = "MERIIDSA" });
            tempList.Add(new Locations() { LocationCode = "MERIIDYD" });
            tempList.Add(new Locations() { LocationCode = "MEXINYAD" });
            tempList.Add(new Locations() { LocationCode = "MEXINYYD" });
            tempList.Add(new Locations() { LocationCode = "MFTRTXAD" });
            tempList.Add(new Locations() { LocationCode = "MIDDNYAD" });
            tempList.Add(new Locations() { LocationCode = "MIDDNYDC" });
            tempList.Add(new Locations() { LocationCode = "MIDDNYKI" });
            tempList.Add(new Locations() { LocationCode = "MIDDNYMW" });
            tempList.Add(new Locations() { LocationCode = "MIDDNYSA" });
            tempList.Add(new Locations() { LocationCode = "MIDDNYYD" });
            tempList.Add(new Locations() { LocationCode = "MIDDWISA" });
            tempList.Add(new Locations() { LocationCode = "MIDDWIYD" });
            tempList.Add(new Locations() { LocationCode = "MIDVUTAD" });
            tempList.Add(new Locations() { LocationCode = "MIDVUTCR" });
            tempList.Add(new Locations() { LocationCode = "MIDVUTSA" });
            tempList.Add(new Locations() { LocationCode = "MIDVUTYD" });
            tempList.Add(new Locations() { LocationCode = "MILEMTYD" });
            tempList.Add(new Locations() { LocationCode = "MILTFLMF" });
            tempList.Add(new Locations() { LocationCode = "MINOWIYD" });
            tempList.Add(new Locations() { LocationCode = "MIRACAHC" });
            tempList.Add(new Locations() { LocationCode = "MOBIALRL" });
            tempList.Add(new Locations() { LocationCode = "MONRWIYD" });
            tempList.Add(new Locations() { LocationCode = "MONTCOYD" });
            tempList.Add(new Locations() { LocationCode = "MONTMNYD" });
            tempList.Add(new Locations() { LocationCode = "MOORINMF" });
            tempList.Add(new Locations() { LocationCode = "MOORINSA" });
            tempList.Add(new Locations() { LocationCode = "MOORNJAD" });
            tempList.Add(new Locations() { LocationCode = "MOORNJHP" });
            tempList.Add(new Locations() { LocationCode = "MORRGAIS" });
            tempList.Add(new Locations() { LocationCode = "MORRGAYD" });
            tempList.Add(new Locations() { LocationCode = "MTCHSDMF" });
            tempList.Add(new Locations() { LocationCode = "MTCHSDYD" });
            tempList.Add(new Locations() { LocationCode = "MTHONJYD" });
            tempList.Add(new Locations() { LocationCode = "MTLANJCR" });
            tempList.Add(new Locations() { LocationCode = "MTLANJCS" });
            tempList.Add(new Locations() { LocationCode = "MTLANJGA" });
            tempList.Add(new Locations() { LocationCode = "MTLANJMA" });
            tempList.Add(new Locations() { LocationCode = "MTLANJSA" });
            tempList.Add(new Locations() { LocationCode = "MTPLMIDC" });
            tempList.Add(new Locations() { LocationCode = "MYRTSCAD" });
            tempList.Add(new Locations() { LocationCode = "MYRTSCSA" });
            tempList.Add(new Locations() { LocationCode = "NATBCADC" });
            tempList.Add(new Locations() { LocationCode = "NATCCAGA" });
            tempList.Add(new Locations() { LocationCode = "NATCCAPA" });
            tempList.Add(new Locations() { LocationCode = "NATCCAYD" });
            tempList.Add(new Locations() { LocationCode = "NEGCOR" });
            tempList.Add(new Locations() { LocationCode = "NEWADEGP" });
            tempList.Add(new Locations() { LocationCode = "NEWHIAMF" });
            tempList.Add(new Locations() { LocationCode = "NEWHIAYD" });
            tempList.Add(new Locations() { LocationCode = "NEWNGARL" });
            tempList.Add(new Locations() { LocationCode = "NEWPORYD" });
            tempList.Add(new Locations() { LocationCode = "NHYDNYYD" });
            tempList.Add(new Locations() { LocationCode = "NORCGAMF" });
            tempList.Add(new Locations() { LocationCode = "NORCGARL" });
            tempList.Add(new Locations() { LocationCode = "NORTCAAD" });
            tempList.Add(new Locations() { LocationCode = "NORTCACR" });
            tempList.Add(new Locations() { LocationCode = "NORTMDAD" });
            tempList.Add(new Locations() { LocationCode = "NRICWIYD" });
            tempList.Add(new Locations() { LocationCode = "OAKGMNMF" });
            tempList.Add(new Locations() { LocationCode = "OBROMF" });
            tempList.Add(new Locations() { LocationCode = "OCENIN" });
            tempList.Add(new Locations() { LocationCode = "OCENYD" });
            tempList.Add(new Locations() { LocationCode = "OCOLKI" });
            tempList.Add(new Locations() { LocationCode = "OCOLYD" });
            tempList.Add(new Locations() { LocationCode = "ODEMMF" });
            tempList.Add(new Locations() { LocationCode = "ODEMYD" });
            tempList.Add(new Locations() { LocationCode = "OERLIS" });
            tempList.Add(new Locations() { LocationCode = "OERLMF" });
            tempList.Add(new Locations() { LocationCode = "OERLYD" });
            tempList.Add(new Locations() { LocationCode = "OINDYD" });
            tempList.Add(new Locations() { LocationCode = "OKCNOKYD" });
            tempList.Add(new Locations() { LocationCode = "OKCSOKYD" });
            tempList.Add(new Locations() { LocationCode = "OKCTOKAD" });
            tempList.Add(new Locations() { LocationCode = "OKCTOKGP" });
            tempList.Add(new Locations() { LocationCode = "OKCTOKMW" });
            tempList.Add(new Locations() { LocationCode = "OKCTOKSA" });
            tempList.Add(new Locations() { LocationCode = "OKCTOKWN" });
            tempList.Add(new Locations() { LocationCode = "OLYMWAYD" });
            tempList.Add(new Locations() { LocationCode = "OMASMF" });
            tempList.Add(new Locations() { LocationCode = "OMASWP" });
            tempList.Add(new Locations() { LocationCode = "OMASYD" });
            tempList.Add(new Locations() { LocationCode = "OSAKMNYD" });
            tempList.Add(new Locations() { LocationCode = "OTHEWAYD" });
            tempList.Add(new Locations() { LocationCode = "OVGCOR" });
            tempList.Add(new Locations() { LocationCode = "OXNDCAYD" });
            tempList.Add(new Locations() { LocationCode = "PADUKYRL" });
            tempList.Add(new Locations() { LocationCode = "PALMAKYD" });
            tempList.Add(new Locations() { LocationCode = "PALMFLYD" });
            tempList.Add(new Locations() { LocationCode = "PANAFLYD" });
            tempList.Add(new Locations() { LocationCode = "PANHGAAD" });
            tempList.Add(new Locations() { LocationCode = "PASCWARL" });
            tempList.Add(new Locations() { LocationCode = "PELMALSA" });
            tempList.Add(new Locations() { LocationCode = "PELMALYD" });
            tempList.Add(new Locations() { LocationCode = "PENNNJRL" });
            tempList.Add(new Locations() { LocationCode = "PENSFLMW" });
            tempList.Add(new Locations() { LocationCode = "PENSFLSA" });
            tempList.Add(new Locations() { LocationCode = "PENSFLYD" });
            tempList.Add(new Locations() { LocationCode = "PEQUMNYD" });
            tempList.Add(new Locations() { LocationCode = "PETEVAGP" });
            tempList.Add(new Locations() { LocationCode = "PETEVAYD" });
            tempList.Add(new Locations() { LocationCode = "PETOMIYD" });
            tempList.Add(new Locations() { LocationCode = "PHILNJGP" });
            tempList.Add(new Locations() { LocationCode = "PHILNJMF" });
            tempList.Add(new Locations() { LocationCode = "PHILNJYD" });
            tempList.Add(new Locations() { LocationCode = "PIERSDYD" });
            tempList.Add(new Locations() { LocationCode = "PLANFLMF" });
            tempList.Add(new Locations() { LocationCode = "PLANFLYD" });
            tempList.Add(new Locations() { LocationCode = "PLATWIYD" });
            tempList.Add(new Locations() { LocationCode = "PLEANJYD" });
            tempList.Add(new Locations() { LocationCode = "PNPBMF" });
            tempList.Add(new Locations() { LocationCode = "PNPNOM" });
            tempList.Add(new Locations() { LocationCode = "PNPNPM" });
            tempList.Add(new Locations() { LocationCode = "PNWCPV" });
            tempList.Add(new Locations() { LocationCode = "PNWCUV" });
            tempList.Add(new Locations() { LocationCode = "PNWFRM" });
            tempList.Add(new Locations() { LocationCode = "PNWHAM" });
            tempList.Add(new Locations() { LocationCode = "PNWHPM" });
            tempList.Add(new Locations() { LocationCode = "PNWPRM" });
            tempList.Add(new Locations() { LocationCode = "POOLGAMF" });
            tempList.Add(new Locations() { LocationCode = "POOLGAYD" });
            tempList.Add(new Locations() { LocationCode = "POSTIDYD" });
            tempList.Add(new Locations() { LocationCode = "PRESAZYD" });
            tempList.Add(new Locations() { LocationCode = "PROSTXYD" });
            tempList.Add(new Locations() { LocationCode = "PSANOG" });
            tempList.Add(new Locations() { LocationCode = "PSANPG" });
            tempList.Add(new Locations() { LocationCode = "PSCAPN" });
            tempList.Add(new Locations() { LocationCode = "PSCBEN" });
            tempList.Add(new Locations() { LocationCode = "PSCHAN" });
            tempList.Add(new Locations() { LocationCode = "PSCHPN" });
            tempList.Add(new Locations() { LocationCode = "PSCNCM" });
            tempList.Add(new Locations() { LocationCode = "PSCWFN" });
            tempList.Add(new Locations() { LocationCode = "PSMAPN" });
            tempList.Add(new Locations() { LocationCode = "PSMATN" });
            tempList.Add(new Locations() { LocationCode = "PSOSAF" });
            tempList.Add(new Locations() { LocationCode = "PSTNAT" });
            tempList.Add(new Locations() { LocationCode = "PSTNPT" });
            tempList.Add(new Locations() { LocationCode = "PSTTAF" });
            tempList.Add(new Locations() { LocationCode = "PUNTFLMF" });
            tempList.Add(new Locations() { LocationCode = "PUNTFLYD" });
            tempList.Add(new Locations() { LocationCode = "RALENCAD" });
            tempList.Add(new Locations() { LocationCode = "RALENCSA" });
            tempList.Add(new Locations() { LocationCode = "RALENCYD" });
            tempList.Add(new Locations() { LocationCode = "RANCOR" });
            tempList.Add(new Locations() { LocationCode = "RAPCSDYD" });
            tempList.Add(new Locations() { LocationCode = "RE1ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE2ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE3ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE4ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE5ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE6ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE7ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE8ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RE9ADMIN" });
            tempList.Add(new Locations() { LocationCode = "RICHWASA" });
            tempList.Add(new Locations() { LocationCode = "RICHWAYD" });
            tempList.Add(new Locations() { LocationCode = "RICHWIYD" });
            tempList.Add(new Locations() { LocationCode = "RIVECAYD" });
            tempList.Add(new Locations() { LocationCode = "ROANNCYD" });
            tempList.Add(new Locations() { LocationCode = "ROANVAYD" });
            tempList.Add(new Locations() { LocationCode = "ROCHMNYD" });
            tempList.Add(new Locations() { LocationCode = "ROCKNJYD" });
            tempList.Add(new Locations() { LocationCode = "ROCKTXYD" });
            tempList.Add(new Locations() { LocationCode = "ROSENYYD" });
            tempList.Add(new Locations() { LocationCode = "ROUNTXMW" });
            tempList.Add(new Locations() { LocationCode = "RSDICAHC" });
            tempList.Add(new Locations() { LocationCode = "RUDYMIYD" });
            tempList.Add(new Locations() { LocationCode = "SABNYD" });
            tempList.Add(new Locations() { LocationCode = "SAGIMIAD" });
            tempList.Add(new Locations() { LocationCode = "SAGIMIMF" });
            tempList.Add(new Locations() { LocationCode = "SAGIMIYD" });
            tempList.Add(new Locations() { LocationCode = "SALICAHC" });
            tempList.Add(new Locations() { LocationCode = "SALIKSYD" });
            tempList.Add(new Locations() { LocationCode = "SANATXMW" });
            tempList.Add(new Locations() { LocationCode = "SANATXSA" });
            tempList.Add(new Locations() { LocationCode = "SANATXYD" });
            tempList.Add(new Locations() { LocationCode = "SANCCADC" });
            tempList.Add(new Locations() { LocationCode = "SANCCASR" });
            tempList.Add(new Locations() { LocationCode = "SANDCAHC" });
            tempList.Add(new Locations() { LocationCode = "SANDIDYD" });
            tempList.Add(new Locations() { LocationCode = "SANFFLAD" });
            tempList.Add(new Locations() { LocationCode = "SANFFLMA" });
            tempList.Add(new Locations() { LocationCode = "SANFFLMF" });
            tempList.Add(new Locations() { LocationCode = "SANFFLMW" });
            tempList.Add(new Locations() { LocationCode = "SANFFLYD" });
            tempList.Add(new Locations() { LocationCode = "SANSYD" });
            tempList.Add(new Locations() { LocationCode = "SANTNMYD" });
            tempList.Add(new Locations() { LocationCode = "SASNYD" });
            tempList.Add(new Locations() { LocationCode = "SAUAIN" });
            tempList.Add(new Locations() { LocationCode = "SAUAYD" });
            tempList.Add(new Locations() { LocationCode = "SAVNIN" });
            tempList.Add(new Locations() { LocationCode = "SAVNYD" });
            tempList.Add(new Locations() { LocationCode = "SBAYCAHC" });
            tempList.Add(new Locations() { LocationCode = "SBFSYD" });
            tempList.Add(new Locations() { LocationCode = "SBLGIN" });
            tempList.Add(new Locations() { LocationCode = "SBLGYD" });
            tempList.Add(new Locations() { LocationCode = "SBRVIN" });
            tempList.Add(new Locations() { LocationCode = "SBRVYD" });
            tempList.Add(new Locations() { LocationCode = "SBVNYD" });
            tempList.Add(new Locations() { LocationCode = "SCBGIN" });
            tempList.Add(new Locations() { LocationCode = "SCBGYD" });
            tempList.Add(new Locations() { LocationCode = "SCCSMF" });
            tempList.Add(new Locations() { LocationCode = "SCHAYD" });
            tempList.Add(new Locations() { LocationCode = "SCHSEN" });
            tempList.Add(new Locations() { LocationCode = "SCHSMW" });
            tempList.Add(new Locations() { LocationCode = "SCHSRL" });
            tempList.Add(new Locations() { LocationCode = "SCHSWP" });
            tempList.Add(new Locations() { LocationCode = "SCHSYD" });
            tempList.Add(new Locations() { LocationCode = "SCNSMW" });
            tempList.Add(new Locations() { LocationCode = "SCNSRL" });
            tempList.Add(new Locations() { LocationCode = "SCNSWD" });
            tempList.Add(new Locations() { LocationCode = "SCNSYD" });
            tempList.Add(new Locations() { LocationCode = "SCOSMW" });
            tempList.Add(new Locations() { LocationCode = "SCOSRL" });
            tempList.Add(new Locations() { LocationCode = "SCOSYD" });
            tempList.Add(new Locations() { LocationCode = "SCPSIN" });
            tempList.Add(new Locations() { LocationCode = "SCPSYD" });
            tempList.Add(new Locations() { LocationCode = "SCRUCAGC" });
            tempList.Add(new Locations() { LocationCode = "SCRUCAHC" });
            tempList.Add(new Locations() { LocationCode = "SCSNYD" });
            tempList.Add(new Locations() { LocationCode = "SCWSIS" });
            tempList.Add(new Locations() { LocationCode = "SCWSYD" });
            tempList.Add(new Locations() { LocationCode = "SDIECACR" });
            tempList.Add(new Locations() { LocationCode = "SDIECAFS" });
            tempList.Add(new Locations() { LocationCode = "SDIECAHC" });
            tempList.Add(new Locations() { LocationCode = "SDIECAHN" });
            tempList.Add(new Locations() { LocationCode = "SDIECAHW" });
            tempList.Add(new Locations() { LocationCode = "SEASORYD" });
            tempList.Add(new Locations() { LocationCode = "SEDOAZHC" });
            tempList.Add(new Locations() { LocationCode = "SEDOAZSA" });
            tempList.Add(new Locations() { LocationCode = "SEGCOR" });
            tempList.Add(new Locations() { LocationCode = "SEGELM" });
            tempList.Add(new Locations() { LocationCode = "SEGUTXYD" });
            tempList.Add(new Locations() { LocationCode = "SEISYD" });
            tempList.Add(new Locations() { LocationCode = "SEQUWAYD" });
            tempList.Add(new Locations() { LocationCode = "SEWAAKYD" });
            tempList.Add(new Locations() { LocationCode = "SFANMF" });
            tempList.Add(new Locations() { LocationCode = "SFANYD" });
            tempList.Add(new Locations() { LocationCode = "SFLSIN" });
            tempList.Add(new Locations() { LocationCode = "SFLSYD" });
            tempList.Add(new Locations() { LocationCode = "SGCSYD" });
            tempList.Add(new Locations() { LocationCode = "SGMSYD" });
            tempList.Add(new Locations() { LocationCode = "SGVGYD" });
            tempList.Add(new Locations() { LocationCode = "SGVSMF" });
            tempList.Add(new Locations() { LocationCode = "SGVSMW" });
            tempList.Add(new Locations() { LocationCode = "SGVSWP" });
            tempList.Add(new Locations() { LocationCode = "SGVSYD" });
            tempList.Add(new Locations() { LocationCode = "SHAFCAMF" });
            tempList.Add(new Locations() { LocationCode = "SHAFCAYD" });
            tempList.Add(new Locations() { LocationCode = "SHEANJRL" });
            tempList.Add(new Locations() { LocationCode = "SHELKYYD" });
            tempList.Add(new Locations() { LocationCode = "SHELWAYD" });
            tempList.Add(new Locations() { LocationCode = "SHHSYD" });
            tempList.Add(new Locations() { LocationCode = "SHOWAZYD" });
            tempList.Add(new Locations() { LocationCode = "SHPNIN" });
            tempList.Add(new Locations() { LocationCode = "SHPNYD" });
            tempList.Add(new Locations() { LocationCode = "SHVNYD" });
            tempList.Add(new Locations() { LocationCode = "SIDNMTYD" });
            tempList.Add(new Locations() { LocationCode = "SILVILYD" });
            tempList.Add(new Locations() { LocationCode = "SIOUIAYD" });
            tempList.Add(new Locations() { LocationCode = "SIOUSDYD" });
            tempList.Add(new Locations() { LocationCode = "SITKAKYD" });
            tempList.Add(new Locations() { LocationCode = "SJCTRL" });
            tempList.Add(new Locations() { LocationCode = "SJCTYD" });
            tempList.Add(new Locations() { LocationCode = "SJISYD" });
            tempList.Add(new Locations() { LocationCode = "SKINYD" });
            tempList.Add(new Locations() { LocationCode = "SKNTYD" });
            tempList.Add(new Locations() { LocationCode = "SKPTYD" });
            tempList.Add(new Locations() { LocationCode = "SLAKUTMF" });
            tempList.Add(new Locations() { LocationCode = "SLAKUTMW" });
            tempList.Add(new Locations() { LocationCode = "SLGGYD" });
            tempList.Add(new Locations() { LocationCode = "SLRSYD" });
            tempList.Add(new Locations() { LocationCode = "SMBSMW" });
            tempList.Add(new Locations() { LocationCode = "SMRTIN" });
            tempList.Add(new Locations() { LocationCode = "SMRTYD" });
            tempList.Add(new Locations() { LocationCode = "SNASIN" });
            tempList.Add(new Locations() { LocationCode = "SNASYD" });
            tempList.Add(new Locations() { LocationCode = "SNBNEN" });
            tempList.Add(new Locations() { LocationCode = "SNOWAZYD" });
            tempList.Add(new Locations() { LocationCode = "SOLACAHC" });
            tempList.Add(new Locations() { LocationCode = "SOLDAKYD" });
            tempList.Add(new Locations() { LocationCode = "SOQUCAHC" });
            tempList.Add(new Locations() { LocationCode = "SOUTCAAD" });
            tempList.Add(new Locations() { LocationCode = "SPANWAAD" });
            tempList.Add(new Locations() { LocationCode = "SPANWASA" });
            tempList.Add(new Locations() { LocationCode = "SPANWAYD" });
            tempList.Add(new Locations() { LocationCode = "SPARSCYD" });
            tempList.Add(new Locations() { LocationCode = "SPEASDYD" });
            tempList.Add(new Locations() { LocationCode = "SPFKUTYD" });
            tempList.Add(new Locations() { LocationCode = "SPFTIN" });
            tempList.Add(new Locations() { LocationCode = "SPFTMF" });
            tempList.Add(new Locations() { LocationCode = "SPFTMW" });
            tempList.Add(new Locations() { LocationCode = "SPOKWAMF" });
            tempList.Add(new Locations() { LocationCode = "SPOKWAYD" });
            tempList.Add(new Locations() { LocationCode = "SPRHTNGP" });
            tempList.Add(new Locations() { LocationCode = "SPWSYD" });
            tempList.Add(new Locations() { LocationCode = "SSESYD" });
            tempList.Add(new Locations() { LocationCode = "SSHAMF" });
            tempList.Add(new Locations() { LocationCode = "SSHASP" });
            tempList.Add(new Locations() { LocationCode = "SSHAWP" });
            tempList.Add(new Locations() { LocationCode = "SSHAYD" });
            tempList.Add(new Locations() { LocationCode = "SSMSFS" });
            tempList.Add(new Locations() { LocationCode = "SSMSMF" });
            tempList.Add(new Locations() { LocationCode = "SSMSWP" });
            tempList.Add(new Locations() { LocationCode = "SSPNYD" });
            tempList.Add(new Locations() { LocationCode = "SSPSRL" });
            tempList.Add(new Locations() { LocationCode = "SSPSYD" });
            tempList.Add(new Locations() { LocationCode = "SSUSYD" });
            tempList.Add(new Locations() { LocationCode = "SSVSYD" });
            tempList.Add(new Locations() { LocationCode = "STCLMNYD" });
            tempList.Add(new Locations() { LocationCode = "STHEMIYD" });
            tempList.Add(new Locations() { LocationCode = "STORIAYD" });
            tempList.Add(new Locations() { LocationCode = "STPAMNRL" });
            tempList.Add(new Locations() { LocationCode = "STSPCOYD" });
            tempList.Add(new Locations() { LocationCode = "SUMMSCYD" });
            tempList.Add(new Locations() { LocationCode = "SWANYD" });
            tempList.Add(new Locations() { LocationCode = "SWININ" });
            tempList.Add(new Locations() { LocationCode = "SWINST" });
            tempList.Add(new Locations() { LocationCode = "SWINYD" });
            tempList.Add(new Locations() { LocationCode = "SWPFYD" });
            tempList.Add(new Locations() { LocationCode = "SWSTCACR" });
            tempList.Add(new Locations() { LocationCode = "SWVNYD" });
            tempList.Add(new Locations() { LocationCode = "TACAWACR" });
            tempList.Add(new Locations() { LocationCode = "TACOWADC" });
            tempList.Add(new Locations() { LocationCode = "TALLFLYD" });
            tempList.Add(new Locations() { LocationCode = "TAMPFLMW" });
            tempList.Add(new Locations() { LocationCode = "TAMPFLWN" });
            tempList.Add(new Locations() { LocationCode = "TANGORYD" });
            tempList.Add(new Locations() { LocationCode = "TAPPVAYD" });
            tempList.Add(new Locations() { LocationCode = "TARLCD" });
            tempList.Add(new Locations() { LocationCode = "TARLDT" });
            tempList.Add(new Locations() { LocationCode = "TARLIN" });
            tempList.Add(new Locations() { LocationCode = "TARLIS" });
            tempList.Add(new Locations() { LocationCode = "TARLWH" });
            tempList.Add(new Locations() { LocationCode = "TARLYD" });
            tempList.Add(new Locations() { LocationCode = "TAUSMW" });
            tempList.Add(new Locations() { LocationCode = "TAUSWN" });
            tempList.Add(new Locations() { LocationCode = "TAUSYD" });
            tempList.Add(new Locations() { LocationCode = "TERRINYD" });
            tempList.Add(new Locations() { LocationCode = "TEXCOR" });
            tempList.Add(new Locations() { LocationCode = "TGRADT" });
            tempList.Add(new Locations() { LocationCode = "THERMF" });
            tempList.Add(new Locations() { LocationCode = "THIEMNYD" });
            tempList.Add(new Locations() { LocationCode = "THUTMW" });
            tempList.Add(new Locations() { LocationCode = "TICONYYD" });
            tempList.Add(new Locations() { LocationCode = "TKELTR" });
            tempList.Add(new Locations() { LocationCode = "TKELYD" });
            tempList.Add(new Locations() { LocationCode = "TLEWYD" });
            tempList.Add(new Locations() { LocationCode = "TOLOILYD" });
            tempList.Add(new Locations() { LocationCode = "TRAVMIYD" });
            tempList.Add(new Locations() { LocationCode = "TROCYD" });
            tempList.Add(new Locations() { LocationCode = "TSAUIN" });
            tempList.Add(new Locations() { LocationCode = "TSAUMW" });
            tempList.Add(new Locations() { LocationCode = "TSAUWN" });
            tempList.Add(new Locations() { LocationCode = "TSAUYD" });
            tempList.Add(new Locations() { LocationCode = "TSFEMF" });
            tempList.Add(new Locations() { LocationCode = "TSGCOR" });
            tempList.Add(new Locations() { LocationCode = "TSHNYD" });
            tempList.Add(new Locations() { LocationCode = "TSHOIN" });
            tempList.Add(new Locations() { LocationCode = "TSHOVN" });
            tempList.Add(new Locations() { LocationCode = "TSHOWN" });
            tempList.Add(new Locations() { LocationCode = "TSHOYD" });
            tempList.Add(new Locations() { LocationCode = "TSHSMW" });
            tempList.Add(new Locations() { LocationCode = "TSHSYD" });
            tempList.Add(new Locations() { LocationCode = "TSHUMF" });
            tempList.Add(new Locations() { LocationCode = "TSMCIN" });
            tempList.Add(new Locations() { LocationCode = "TSMCWN" });
            tempList.Add(new Locations() { LocationCode = "TSSAIN" });
            tempList.Add(new Locations() { LocationCode = "TSSAIS" });
            tempList.Add(new Locations() { LocationCode = "TSSAMF" });
            tempList.Add(new Locations() { LocationCode = "TSSAMW" });
            tempList.Add(new Locations() { LocationCode = "TSSAWN" });
            tempList.Add(new Locations() { LocationCode = "TSSAWP" });
            tempList.Add(new Locations() { LocationCode = "TSSAYD" });
            tempList.Add(new Locations() { LocationCode = "TSSEMF" });
            tempList.Add(new Locations() { LocationCode = "TULSOKHP" });
            tempList.Add(new Locations() { LocationCode = "VAILNYYD" });
            tempList.Add(new Locations() { LocationCode = "VALLKSMF" });
            tempList.Add(new Locations() { LocationCode = "VANCWARL" });
            tempList.Add(new Locations() { LocationCode = "VANCWAYD" });
            tempList.Add(new Locations() { LocationCode = "VEROVAYD" });
            tempList.Add(new Locations() { LocationCode = "VILLGAMF" });
            tempList.Add(new Locations() { LocationCode = "WADEMNMF" });
            tempList.Add(new Locations() { LocationCode = "WAHPNDAD" });
            tempList.Add(new Locations() { LocationCode = "WAHPNDYD" });
            tempList.Add(new Locations() { LocationCode = "WALDMDGP" });
            tempList.Add(new Locations() { LocationCode = "WALDMDYD" });
            tempList.Add(new Locations() { LocationCode = "WALKIAYD" });
            tempList.Add(new Locations() { LocationCode = "WALLWAMF" });
            tempList.Add(new Locations() { LocationCode = "WALLWAYD" });
            tempList.Add(new Locations() { LocationCode = "WAMGAKYD" });
            tempList.Add(new Locations() { LocationCode = "WASEMNYD" });
            tempList.Add(new Locations() { LocationCode = "WASIAKMW" });
            tempList.Add(new Locations() { LocationCode = "WASIAKYD" });
            tempList.Add(new Locations() { LocationCode = "WATRIAYD" });
            tempList.Add(new Locations() { LocationCode = "WATRNYYD" });
            tempList.Add(new Locations() { LocationCode = "WAUKIAYD" });
            tempList.Add(new Locations() { LocationCode = "WAUSWAAD" });
            tempList.Add(new Locations() { LocationCode = "WAUSWIYD" });
            tempList.Add(new Locations() { LocationCode = "WCHRVAMF" });
            tempList.Add(new Locations() { LocationCode = "WCHRVAWP" });
            tempList.Add(new Locations() { LocationCode = "WCHRVAYD" });
            tempList.Add(new Locations() { LocationCode = "WENAWAYD" });
            tempList.Add(new Locations() { LocationCode = "WESTVAMF" });
            tempList.Add(new Locations() { LocationCode = "WHEAMNYD" });
            tempList.Add(new Locations() { LocationCode = "WHITPAYD" });
            tempList.Add(new Locations() { LocationCode = "WICHKSYD" });
            tempList.Add(new Locations() { LocationCode = "WILLNDYD" });
            tempList.Add(new Locations() { LocationCode = "WILLVAYD" });
            tempList.Add(new Locations() { LocationCode = "WILMNCGP" });
            tempList.Add(new Locations() { LocationCode = "WILMNCYD" });
            tempList.Add(new Locations() { LocationCode = "WINOMNAD" });
            tempList.Add(new Locations() { LocationCode = "WINOMNDC" });
            tempList.Add(new Locations() { LocationCode = "WINOMNHG" });
            tempList.Add(new Locations() { LocationCode = "WINOMNMA" });
            tempList.Add(new Locations() { LocationCode = "WINOMNYD" });
            tempList.Add(new Locations() { LocationCode = "WRICWAMF" });
            tempList.Add(new Locations() { LocationCode = "WSMYTNGP" });
            tempList.Add(new Locations() { LocationCode = "WSMYTNMW" });
            tempList.Add(new Locations() { LocationCode = "WSMYTNYD" });
            tempList.Add(new Locations() { LocationCode = "YAKIWAYD" });
            tempList.Add(new Locations() { LocationCode = "ZIMMMNYD" });

            listLocations = tempList;
        }

        public void populateLocationPrefixList()
        {
            List<LocPrefix> tempList = new List<LocPrefix>();
            tempList.Add(new LocPrefix() { prefix = "" });
            tempList.Add(new LocPrefix() { prefix = "HOU" });
            tempList.Add(new LocPrefix() { prefix = "SA" });
            ListPrefixes = tempList;
        }

        public void populateDriversList(string Location)
        {
            List<Drivers> tempList = new List<Drivers>();
            var driverQuery = DB.DelDrivers.Where(y => y.dLocation == Location).Select(x => new { FirstName = x.dFirstName, LastName = x.dLastName, ID = x.dEmpID }).OrderBy(z => z.LastName);
            foreach(var driver in driverQuery)
            {
                Drivers DC = new Drivers();
                DC.firstName = driver.FirstName.Replace(" ", "");
                DC.lastName = driver.LastName.Replace(" ", "");
                DC.empID = driver.ID;
                DC.fullName = driver.FirstName.Replace(" ", "") + " " + driver.LastName.Replace(" ", "");
                tempList.Add(DC);
            }
            ListDrivers = tempList;
        }

        public void populateTruckTrialerList(string Location, string tCode)
        {
            List<TrucksAndTrailers> tempList = new List<TrucksAndTrailers>();
            var ttQuery = DB.DelAssets.Where(y => y.tLocation == Location && y.tCode == tCode).Select(x => new { Asset = x.tAID });
            foreach (var truck in ttQuery)
            {
                TrucksAndTrailers TT = new TrucksAndTrailers();
                TT.tAID = truck.Asset;
                tempList.Add(TT);
            }
            ListTrucksTrailers = tempList;
        }

        public void populateBayID(string Location)
        {
            List<BayID> tempList = new List<BayID>();
            if(Location == "TSHAWN")
            {
                tempList.Add(new BayID() { bayID = "" });
                tempList.Add(new BayID() { bayID = "Black" });
                tempList.Add(new BayID() { bayID = "Green" });
                tempList.Add(new BayID() { bayID = "Orange" });
                tempList.Add(new BayID() { bayID = "Blue" });
                tempList.Add(new BayID() { bayID = "Purple" });
                tempList.Add(new BayID() { bayID = "Pink" });
                tempList.Add(new BayID() { bayID = "Red" });
                tempList.Add(new BayID() { bayID = "Yellow" });
                tempList.Add(new BayID() { bayID = "Brown" });
                tempList.Add(new BayID() { bayID = "Lime Green" });
                tempList.Add(new BayID() { bayID = "Gray" });
                tempList.Add(new BayID() { bayID = "Red/Black" });
                tempList.Add(new BayID() { bayID = "Blue/Orange" });
                tempList.Add(new BayID() { bayID = "Pink/Purple" });
            }
            else
            {
                tempList.Add(new BayID() { bayID = "" });
                tempList.Add(new BayID() { bayID = "1" });
                tempList.Add(new BayID() { bayID = "2" });
                tempList.Add(new BayID() { bayID = "3" });
                tempList.Add(new BayID() { bayID = "4" });
                tempList.Add(new BayID() { bayID = "5" });
                tempList.Add(new BayID() { bayID = "6" });
                tempList.Add(new BayID() { bayID = "7" });
                tempList.Add(new BayID() { bayID = "8" });
                tempList.Add(new BayID() { bayID = "9" });
                tempList.Add(new BayID() { bayID = "10" });
                tempList.Add(new BayID() { bayID = "11" });
                tempList.Add(new BayID() { bayID = "12" });
                tempList.Add(new BayID() { bayID = "13" });
                tempList.Add(new BayID() { bayID = "14" });
                tempList.Add(new BayID() { bayID = "15" });
                tempList.Add(new BayID() { bayID = "16" });
                tempList.Add(new BayID() { bayID = "17" });
                tempList.Add(new BayID() { bayID = "18" });
                tempList.Add(new BayID() { bayID = "19" });
                tempList.Add(new BayID() { bayID = "20" });
            }
            ListBayIDs = tempList;
        }

        public void deleteAsset(int driver, int Adriver, string truck, string trailer)
        {
            if(driver != 0)
            {
                DelDriver driverToDel = DB.DelDrivers.First(x => x.dEmpID == driver);
                driverToDel.dStatus = 0;
                DB.SaveChanges();
            }
            if (Adriver != 0)
            {
                DelDriver AdriverToDel = DB.DelDrivers.First(x => x.dEmpID == Adriver);
                AdriverToDel.dStatus = 0;
                DB.SaveChanges();
            }
            if(truck != "")
            {
                DelAsset truckToDel = DB.DelAssets.First(x => x.tAID == truck);
                truckToDel.tStatus = 0;
                DB.SaveChanges();
            }
            if (trailer != "")
            {
                DelAsset trailerToDel = DB.DelAssets.First(x => x.tAID == trailer);
                trailerToDel.tStatus = 0;
                DB.SaveChanges();
            }
        }

        public void addADriver(string firstName, string lastName, int empID, string driverType, string location)
        {
            var aDriverAdd = DB.Set <DelDriver>();
            aDriverAdd.Add(new DelDriver { dEmpID = empID, dFirstName = firstName, dLastName = lastName, dDCode = driverType, dStatus = 1, dLocation = location });
            DB.SaveChanges();
        }

        public void addDriver(string firstName, string lastName, int empID, string driverType, string location)
        {
            var aDriverAdd = DB.Set<DelDriver>();
            aDriverAdd.Add(new DelDriver { dEmpID = empID, dFirstName = firstName, dLastName = lastName, dDCode = driverType, dStatus = 1, dLocation = location });
            DB.SaveChanges();
        }

        public void addTruck(string ID, int AssetNumber, int Year, string Model, string TransM, string Location, string Other, string Code)
        {
            var truckAdd = DB.Set<DelAsset>();
            truckAdd.Add(new DelAsset { tAID = ID, tANumber = AssetNumber, tYear = Year, tModel = Model, tTransm = TransM, tLocation = Location, tOther = Other, tCode = Code, tStatus = 1 });
            DB.SaveChanges();
        }

        public void addTrailer(string ID, int AssetNumber, int Year, string Model, string TransM, string Location, string Other, string Code)
        {
            var trailerAdd = DB.Set<DelAsset>();
            trailerAdd.Add(new DelAsset { tAID = ID, tANumber = AssetNumber, tYear = Year, tModel = Model, tTransm = TransM, tLocation = Location, tOther = Other, tCode = Code, tStatus = 1 });
            DB.SaveChanges();
        }

    }

    public class RouteDetails
    {
        public string Route { get; set; }
        public int? Stop { get; set; }
        public string StopID { get; set; }
        public int? ItemID { get; set; }
        public string SKU { get; set; }
        public double? QTY { get; set; }
        public string PickTicket { get; set; }
        public string JobID { get; set; }
        public string CustPO { get; set; }
        public string ShipDateS { get; set; }
        public DateTime? ShipDate { get; set; }
    }

    public class Locations
    {
        public string LocationCode { get; set; }
    }

    public class LocPrefix
    {
        public string prefix { get; set; }
    }

    public class Drivers
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string fullName { get; set; }
        public int empID { get; set; }
    }

    public class TrucksAndTrailers
    {
        public string tAID { get; set; }
    }

    public class BayID
    {
        public string LocationCode { get; set; }
        public string bayID { get; set; }
    }

    public class PickTicket
    {
        public string partno { get; set; }
    }

    public class Routes
    {
        public string routeNumber { get; set; }
    }

}
