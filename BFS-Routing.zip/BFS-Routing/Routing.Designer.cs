﻿namespace BFS_Routing
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.tabCurrentRoutes = new System.Windows.Forms.TabPage();
            this.pnlCurrentRoutes = new System.Windows.Forms.Panel();
            this.lblUnitCount = new System.Windows.Forms.Label();
            this.lblNumofStops = new System.Windows.Forms.Label();
            this.lblStopsLabel = new System.Windows.Forms.Label();
            this.lblTrailer = new System.Windows.Forms.Label();
            this.lblTrailerLabel = new System.Windows.Forms.Label();
            this.lblTruck = new System.Windows.Forms.Label();
            this.lblTruckLabel = new System.Windows.Forms.Label();
            this.lblAsstDriver = new System.Windows.Forms.Label();
            this.lblADriverLabel = new System.Windows.Forms.Label();
            this.lblDriver = new System.Windows.Forms.Label();
            this.lblDriverLabel = new System.Windows.Forms.Label();
            this.lblRoute = new System.Windows.Forms.Label();
            this.cbxRoute = new System.Windows.Forms.ComboBox();
            this.dgRouteInfo = new System.Windows.Forms.DataGrid();
            this.tabCreateRoute = new System.Windows.Forms.TabPage();
            this.pnlCreateRoute = new System.Windows.Forms.Panel();
            this.pnlCreateStops = new System.Windows.Forms.Panel();
            this.btnDoneAddingStops = new System.Windows.Forms.Button();
            this.btnAddNewStops = new System.Windows.Forms.Button();
            this.dgvAddStops = new System.Windows.Forms.DataGridView();
            this.cbxBayIDs = new System.Windows.Forms.ComboBox();
            this.lblCreateBayID = new System.Windows.Forms.Label();
            this.lblRouteCodeCreated = new System.Windows.Forms.Label();
            this.btnClearCreateForm = new System.Windows.Forms.Button();
            this.btnCreateRoute = new System.Windows.Forms.Button();
            this.cbxCreateTrailer = new System.Windows.Forms.ComboBox();
            this.lblCreateTrailer = new System.Windows.Forms.Label();
            this.cbxCreateTruck = new System.Windows.Forms.ComboBox();
            this.lblCreateTruck = new System.Windows.Forms.Label();
            this.cbxCreateADriver = new System.Windows.Forms.ComboBox();
            this.lblCreateADriver = new System.Windows.Forms.Label();
            this.cbxCreateDriver = new System.Windows.Forms.ComboBox();
            this.lblCreateDriver = new System.Windows.Forms.Label();
            this.lblCreateDate = new System.Windows.Forms.Label();
            this.lblCreateDateLabel = new System.Windows.Forms.Label();
            this.tabManageRoutes = new System.Windows.Forms.TabPage();
            this.pnlManageRoutesMain = new System.Windows.Forms.Panel();
            this.pnlDetails = new System.Windows.Forms.Panel();
            this.btnSaveChangeDetails = new System.Windows.Forms.Button();
            this.cbxChangeBayID = new System.Windows.Forms.ComboBox();
            this.lblNewBayID = new System.Windows.Forms.Label();
            this.lblCurrentBayID = new System.Windows.Forms.Label();
            this.lblForBayID = new System.Windows.Forms.Label();
            this.cbxChangeTrailerTo = new System.Windows.Forms.ComboBox();
            this.cbxChangeTruckTo = new System.Windows.Forms.ComboBox();
            this.cbxChangeAsstDriverTo = new System.Windows.Forms.ComboBox();
            this.cbxChangeDriverTo = new System.Windows.Forms.ComboBox();
            this.lblChangeTrailerTo = new System.Windows.Forms.Label();
            this.lblChangeTruckTo = new System.Windows.Forms.Label();
            this.lblChangeAsstDriverTo = new System.Windows.Forms.Label();
            this.lblChangeDriverTo = new System.Windows.Forms.Label();
            this.lblCurrentTrailer = new System.Windows.Forms.Label();
            this.lblCurrentTruck = new System.Windows.Forms.Label();
            this.lblCurrentASstDriver = new System.Windows.Forms.Label();
            this.lblCurrentDriver = new System.Windows.Forms.Label();
            this.lblCurrentTrailerLabel = new System.Windows.Forms.Label();
            this.lblCurrentTruckLabel = new System.Windows.Forms.Label();
            this.lblCurrentAsstDriverLabel = new System.Windows.Forms.Label();
            this.lblCurrentDriverLabel = new System.Windows.Forms.Label();
            this.pnlDeleteRoute = new System.Windows.Forms.Panel();
            this.btnDeleteRoute = new System.Windows.Forms.Button();
            this.lblManageRouteROUTE = new System.Windows.Forms.Label();
            this.cbxChangeRoute = new System.Windows.Forms.ComboBox();
            this.pnlChangeStops = new System.Windows.Forms.Panel();
            this.btnAddStopsFromChange = new System.Windows.Forms.Button();
            this.btnDeleteStop = new System.Windows.Forms.Button();
            this.lblChangeStopsTo = new System.Windows.Forms.Label();
            this.dgvChangeAddStops = new System.Windows.Forms.DataGridView();
            this.tabShipStatus = new System.Windows.Forms.TabPage();
            this.pnlStatus = new System.Windows.Forms.Panel();
            this.pnlRouteStatus = new System.Windows.Forms.Panel();
            this.txtJobIDSearch = new System.Windows.Forms.TextBox();
            this.txtPickTicketSearch = new System.Windows.Forms.TextBox();
            this.cbxDeliveryRoutes = new System.Windows.Forms.ComboBox();
            this.lblDeliveryRoute = new System.Windows.Forms.Label();
            this.lblPickTicketSearch = new System.Windows.Forms.Label();
            this.lblJobID = new System.Windows.Forms.Label();
            this.lblGetDeliveryStatus = new System.Windows.Forms.Label();
            this.dgvDeliveryStatusDetails = new System.Windows.Forms.DataGridView();
            this.dgvDeliveryStatusStops = new System.Windows.Forms.DataGridView();
            this.tabAddDelAssets = new System.Windows.Forms.TabPage();
            this.pnlAddDel = new System.Windows.Forms.Panel();
            this.pnlAddAsset = new System.Windows.Forms.Panel();
            this.pnlAddTrailer = new System.Windows.Forms.Panel();
            this.cbxTrailerType = new System.Windows.Forms.ComboBox();
            this.cbxTrailerLocation = new System.Windows.Forms.ComboBox();
            this.txtbxTrailerModel = new System.Windows.Forms.TextBox();
            this.txtbxTrailerAssetNumber = new System.Windows.Forms.TextBox();
            this.cbxTrailerMaintType = new System.Windows.Forms.ComboBox();
            this.cbxTrailerYear = new System.Windows.Forms.ComboBox();
            this.txtbxTrailerAssetID = new System.Windows.Forms.TextBox();
            this.lblTrailerType = new System.Windows.Forms.Label();
            this.lblTrailerMaintType = new System.Windows.Forms.Label();
            this.lblTrailerLocation = new System.Windows.Forms.Label();
            this.btnAddTrailer = new System.Windows.Forms.Button();
            this.lblTrailerModel = new System.Windows.Forms.Label();
            this.lblbTrailerYear = new System.Windows.Forms.Label();
            this.lblTrailerAssetID = new System.Windows.Forms.Label();
            this.lblTrailerAssetNumber = new System.Windows.Forms.Label();
            this.pnlAddTruck = new System.Windows.Forms.Panel();
            this.cbxTruckOther = new System.Windows.Forms.ComboBox();
            this.cbxTruckLocation = new System.Windows.Forms.ComboBox();
            this.txtbxTruckModel = new System.Windows.Forms.TextBox();
            this.txtbxTruckAssetNumber = new System.Windows.Forms.TextBox();
            this.cbxTruckMaintType = new System.Windows.Forms.ComboBox();
            this.cbxTruckYear = new System.Windows.Forms.ComboBox();
            this.txtbxTruckAssetID = new System.Windows.Forms.TextBox();
            this.lblAssetType = new System.Windows.Forms.Label();
            this.lblMaintenanceType = new System.Windows.Forms.Label();
            this.lblAssetLocation = new System.Windows.Forms.Label();
            this.btnAddTruck = new System.Windows.Forms.Button();
            this.lblAssetModel = new System.Windows.Forms.Label();
            this.lblAssetYear = new System.Windows.Forms.Label();
            this.lblAssetID = new System.Windows.Forms.Label();
            this.lblAssetNumber = new System.Windows.Forms.Label();
            this.pnlAddADriver = new System.Windows.Forms.Panel();
            this.btnAddADriver = new System.Windows.Forms.Button();
            this.cbxADriverLocation = new System.Windows.Forms.ComboBox();
            this.txtbxADriverLastName = new System.Windows.Forms.TextBox();
            this.txtbxADriverFirstName = new System.Windows.Forms.TextBox();
            this.txtbxADriverEmpID = new System.Windows.Forms.TextBox();
            this.lblADriverLocation = new System.Windows.Forms.Label();
            this.lblADriverLastName = new System.Windows.Forms.Label();
            this.lblADriverEmpID = new System.Windows.Forms.Label();
            this.lblADriverFirstName = new System.Windows.Forms.Label();
            this.pnlAddDriver = new System.Windows.Forms.Panel();
            this.btnAddDriver = new System.Windows.Forms.Button();
            this.cbxDriverLocation = new System.Windows.Forms.ComboBox();
            this.txtbxDriverLastName = new System.Windows.Forms.TextBox();
            this.txtbxDriverFirstName = new System.Windows.Forms.TextBox();
            this.txtbxEmpID = new System.Windows.Forms.TextBox();
            this.lblDriverLocation = new System.Windows.Forms.Label();
            this.lblDriverLastName = new System.Windows.Forms.Label();
            this.lblEmpID = new System.Windows.Forms.Label();
            this.lblDriverFirstName = new System.Windows.Forms.Label();
            this.lblSelectAssetToAdd = new System.Windows.Forms.Label();
            this.cbxAddAsset = new System.Windows.Forms.ComboBox();
            this.pnlDeleteAsset = new System.Windows.Forms.Panel();
            this.lblDeleteDriver = new System.Windows.Forms.Label();
            this.btnDeleteAsset = new System.Windows.Forms.Button();
            this.lblDeleteADriver = new System.Windows.Forms.Label();
            this.lblDeleteTruck = new System.Windows.Forms.Label();
            this.lblDeleteTrailer = new System.Windows.Forms.Label();
            this.cbxDelTrailer = new System.Windows.Forms.ComboBox();
            this.cbxDelDriver = new System.Windows.Forms.ComboBox();
            this.cbxDelTruck = new System.Windows.Forms.ComboBox();
            this.cbxDelADriver = new System.Windows.Forms.ComboBox();
            this.dtpMain = new System.Windows.Forms.DateTimePicker();
            this.cbxLocation = new System.Windows.Forms.ComboBox();
            this.cbxLocPrefix = new System.Windows.Forms.ComboBox();
            this.tcMain.SuspendLayout();
            this.tabCurrentRoutes.SuspendLayout();
            this.pnlCurrentRoutes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRouteInfo)).BeginInit();
            this.tabCreateRoute.SuspendLayout();
            this.pnlCreateRoute.SuspendLayout();
            this.pnlCreateStops.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddStops)).BeginInit();
            this.tabManageRoutes.SuspendLayout();
            this.pnlManageRoutesMain.SuspendLayout();
            this.pnlDetails.SuspendLayout();
            this.pnlDeleteRoute.SuspendLayout();
            this.pnlChangeStops.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChangeAddStops)).BeginInit();
            this.tabShipStatus.SuspendLayout();
            this.pnlStatus.SuspendLayout();
            this.pnlRouteStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryStatusDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryStatusStops)).BeginInit();
            this.tabAddDelAssets.SuspendLayout();
            this.pnlAddDel.SuspendLayout();
            this.pnlAddAsset.SuspendLayout();
            this.pnlAddTrailer.SuspendLayout();
            this.pnlAddTruck.SuspendLayout();
            this.pnlAddADriver.SuspendLayout();
            this.pnlAddDriver.SuspendLayout();
            this.pnlDeleteAsset.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcMain
            // 
            this.tcMain.Controls.Add(this.tabCurrentRoutes);
            this.tcMain.Controls.Add(this.tabCreateRoute);
            this.tcMain.Controls.Add(this.tabManageRoutes);
            this.tcMain.Controls.Add(this.tabShipStatus);
            this.tcMain.Controls.Add(this.tabAddDelAssets);
            this.tcMain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcMain.Location = new System.Drawing.Point(0, 90);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(1356, 767);
            this.tcMain.TabIndex = 0;
            this.tcMain.SelectedIndexChanged += new System.EventHandler(this.tcMain_SelectedIndexChanged);
            this.tcMain.Selected += new System.Windows.Forms.TabControlEventHandler(this.tcMain_Selected);
            // 
            // tabCurrentRoutes
            // 
            this.tabCurrentRoutes.Controls.Add(this.pnlCurrentRoutes);
            this.tabCurrentRoutes.Location = new System.Drawing.Point(4, 40);
            this.tabCurrentRoutes.Name = "tabCurrentRoutes";
            this.tabCurrentRoutes.Padding = new System.Windows.Forms.Padding(3);
            this.tabCurrentRoutes.Size = new System.Drawing.Size(1172, 723);
            this.tabCurrentRoutes.TabIndex = 2;
            this.tabCurrentRoutes.Text = "Current Routes";
            this.tabCurrentRoutes.UseVisualStyleBackColor = true;
            // 
            // pnlCurrentRoutes
            // 
            this.pnlCurrentRoutes.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlCurrentRoutes.Controls.Add(this.lblUnitCount);
            this.pnlCurrentRoutes.Controls.Add(this.lblNumofStops);
            this.pnlCurrentRoutes.Controls.Add(this.lblStopsLabel);
            this.pnlCurrentRoutes.Controls.Add(this.lblTrailer);
            this.pnlCurrentRoutes.Controls.Add(this.lblTrailerLabel);
            this.pnlCurrentRoutes.Controls.Add(this.lblTruck);
            this.pnlCurrentRoutes.Controls.Add(this.lblTruckLabel);
            this.pnlCurrentRoutes.Controls.Add(this.lblAsstDriver);
            this.pnlCurrentRoutes.Controls.Add(this.lblADriverLabel);
            this.pnlCurrentRoutes.Controls.Add(this.lblDriver);
            this.pnlCurrentRoutes.Controls.Add(this.lblDriverLabel);
            this.pnlCurrentRoutes.Controls.Add(this.lblRoute);
            this.pnlCurrentRoutes.Controls.Add(this.cbxRoute);
            this.pnlCurrentRoutes.Controls.Add(this.dgRouteInfo);
            this.pnlCurrentRoutes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlCurrentRoutes.Location = new System.Drawing.Point(3, 20);
            this.pnlCurrentRoutes.Name = "pnlCurrentRoutes";
            this.pnlCurrentRoutes.Size = new System.Drawing.Size(1166, 700);
            this.pnlCurrentRoutes.TabIndex = 0;
            // 
            // lblUnitCount
            // 
            this.lblUnitCount.AutoSize = true;
            this.lblUnitCount.Location = new System.Drawing.Point(621, 127);
            this.lblUnitCount.Name = "lblUnitCount";
            this.lblUnitCount.Size = new System.Drawing.Size(0, 31);
            this.lblUnitCount.TabIndex = 13;
            // 
            // lblNumofStops
            // 
            this.lblNumofStops.AutoSize = true;
            this.lblNumofStops.Location = new System.Drawing.Point(848, 81);
            this.lblNumofStops.Name = "lblNumofStops";
            this.lblNumofStops.Size = new System.Drawing.Size(0, 31);
            this.lblNumofStops.TabIndex = 12;
            // 
            // lblStopsLabel
            // 
            this.lblStopsLabel.AutoSize = true;
            this.lblStopsLabel.Location = new System.Drawing.Point(629, 81);
            this.lblStopsLabel.Name = "lblStopsLabel";
            this.lblStopsLabel.Size = new System.Drawing.Size(225, 31);
            this.lblStopsLabel.TabIndex = 11;
            this.lblStopsLabel.Text = "Number of Stops:";
            // 
            // lblTrailer
            // 
            this.lblTrailer.AutoSize = true;
            this.lblTrailer.Location = new System.Drawing.Point(110, 220);
            this.lblTrailer.Name = "lblTrailer";
            this.lblTrailer.Size = new System.Drawing.Size(0, 31);
            this.lblTrailer.TabIndex = 10;
            // 
            // lblTrailerLabel
            // 
            this.lblTrailerLabel.AutoSize = true;
            this.lblTrailerLabel.Location = new System.Drawing.Point(14, 220);
            this.lblTrailerLabel.Name = "lblTrailerLabel";
            this.lblTrailerLabel.Size = new System.Drawing.Size(106, 31);
            this.lblTrailerLabel.TabIndex = 9;
            this.lblTrailerLabel.Text = "Trailer: ";
            // 
            // lblTruck
            // 
            this.lblTruck.AutoSize = true;
            this.lblTruck.Location = new System.Drawing.Point(104, 173);
            this.lblTruck.Name = "lblTruck";
            this.lblTruck.Size = new System.Drawing.Size(0, 31);
            this.lblTruck.TabIndex = 8;
            // 
            // lblTruckLabel
            // 
            this.lblTruckLabel.AutoSize = true;
            this.lblTruckLabel.Location = new System.Drawing.Point(13, 174);
            this.lblTruckLabel.Name = "lblTruckLabel";
            this.lblTruckLabel.Size = new System.Drawing.Size(98, 31);
            this.lblTruckLabel.TabIndex = 7;
            this.lblTruckLabel.Text = "Truck: ";
            // 
            // lblAsstDriver
            // 
            this.lblAsstDriver.AutoSize = true;
            this.lblAsstDriver.Location = new System.Drawing.Point(229, 127);
            this.lblAsstDriver.Name = "lblAsstDriver";
            this.lblAsstDriver.Size = new System.Drawing.Size(0, 31);
            this.lblAsstDriver.TabIndex = 6;
            // 
            // lblADriverLabel
            // 
            this.lblADriverLabel.AutoSize = true;
            this.lblADriverLabel.Location = new System.Drawing.Point(14, 127);
            this.lblADriverLabel.Name = "lblADriverLabel";
            this.lblADriverLabel.Size = new System.Drawing.Size(221, 31);
            this.lblADriverLabel.TabIndex = 5;
            this.lblADriverLabel.Text = "Assistant Driver: ";
            // 
            // lblDriver
            // 
            this.lblDriver.AutoSize = true;
            this.lblDriver.Location = new System.Drawing.Point(106, 81);
            this.lblDriver.Name = "lblDriver";
            this.lblDriver.Size = new System.Drawing.Size(0, 31);
            this.lblDriver.TabIndex = 4;
            // 
            // lblDriverLabel
            // 
            this.lblDriverLabel.AutoSize = true;
            this.lblDriverLabel.Location = new System.Drawing.Point(14, 81);
            this.lblDriverLabel.Name = "lblDriverLabel";
            this.lblDriverLabel.Size = new System.Drawing.Size(102, 31);
            this.lblDriverLabel.TabIndex = 3;
            this.lblDriverLabel.Text = "Driver: ";
            // 
            // lblRoute
            // 
            this.lblRoute.AutoSize = true;
            this.lblRoute.Location = new System.Drawing.Point(258, 37);
            this.lblRoute.Name = "lblRoute";
            this.lblRoute.Size = new System.Drawing.Size(125, 31);
            this.lblRoute.TabIndex = 2;
            this.lblRoute.Text = "ROUTE: ";
            // 
            // cbxRoute
            // 
            this.cbxRoute.FormattingEnabled = true;
            this.cbxRoute.Location = new System.Drawing.Point(389, 29);
            this.cbxRoute.Name = "cbxRoute";
            this.cbxRoute.Size = new System.Drawing.Size(325, 39);
            this.cbxRoute.TabIndex = 1;
            this.cbxRoute.SelectedIndexChanged += new System.EventHandler(this.cbxRoute_SelectedIndexChanged);
            // 
            // dgRouteInfo
            // 
            this.dgRouteInfo.AlternatingBackColor = System.Drawing.Color.LightGray;
            this.dgRouteInfo.BackColor = System.Drawing.Color.Gainsboro;
            this.dgRouteInfo.BackgroundColor = System.Drawing.Color.Silver;
            this.dgRouteInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgRouteInfo.CaptionBackColor = System.Drawing.Color.LightSteelBlue;
            this.dgRouteInfo.CaptionForeColor = System.Drawing.Color.Crimson;
            this.dgRouteInfo.DataMember = "";
            this.dgRouteInfo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgRouteInfo.FlatMode = true;
            this.dgRouteInfo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgRouteInfo.ForeColor = System.Drawing.Color.Black;
            this.dgRouteInfo.GridLineColor = System.Drawing.Color.DimGray;
            this.dgRouteInfo.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
            this.dgRouteInfo.HeaderBackColor = System.Drawing.Color.Crimson;
            this.dgRouteInfo.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.dgRouteInfo.HeaderForeColor = System.Drawing.Color.White;
            this.dgRouteInfo.LinkColor = System.Drawing.Color.Crimson;
            this.dgRouteInfo.Location = new System.Drawing.Point(0, 286);
            this.dgRouteInfo.Name = "dgRouteInfo";
            this.dgRouteInfo.ParentRowsBackColor = System.Drawing.Color.DarkGray;
            this.dgRouteInfo.ParentRowsForeColor = System.Drawing.Color.Black;
            this.dgRouteInfo.PreferredColumnWidth = 125;
            this.dgRouteInfo.ReadOnly = true;
            this.dgRouteInfo.SelectionBackColor = System.Drawing.Color.CadetBlue;
            this.dgRouteInfo.SelectionForeColor = System.Drawing.Color.White;
            this.dgRouteInfo.Size = new System.Drawing.Size(1166, 414);
            this.dgRouteInfo.TabIndex = 0;
            this.dgRouteInfo.Navigate += new System.Windows.Forms.NavigateEventHandler(this.dgRouteInfo_Navigate);
            // 
            // tabCreateRoute
            // 
            this.tabCreateRoute.Controls.Add(this.pnlCreateRoute);
            this.tabCreateRoute.Location = new System.Drawing.Point(4, 40);
            this.tabCreateRoute.Name = "tabCreateRoute";
            this.tabCreateRoute.Padding = new System.Windows.Forms.Padding(3);
            this.tabCreateRoute.Size = new System.Drawing.Size(1172, 723);
            this.tabCreateRoute.TabIndex = 0;
            this.tabCreateRoute.Text = "Create A Route";
            this.tabCreateRoute.UseVisualStyleBackColor = true;
            // 
            // pnlCreateRoute
            // 
            this.pnlCreateRoute.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlCreateRoute.Controls.Add(this.pnlCreateStops);
            this.pnlCreateRoute.Controls.Add(this.cbxBayIDs);
            this.pnlCreateRoute.Controls.Add(this.lblCreateBayID);
            this.pnlCreateRoute.Controls.Add(this.lblRouteCodeCreated);
            this.pnlCreateRoute.Controls.Add(this.btnClearCreateForm);
            this.pnlCreateRoute.Controls.Add(this.btnCreateRoute);
            this.pnlCreateRoute.Controls.Add(this.cbxCreateTrailer);
            this.pnlCreateRoute.Controls.Add(this.lblCreateTrailer);
            this.pnlCreateRoute.Controls.Add(this.cbxCreateTruck);
            this.pnlCreateRoute.Controls.Add(this.lblCreateTruck);
            this.pnlCreateRoute.Controls.Add(this.cbxCreateADriver);
            this.pnlCreateRoute.Controls.Add(this.lblCreateADriver);
            this.pnlCreateRoute.Controls.Add(this.cbxCreateDriver);
            this.pnlCreateRoute.Controls.Add(this.lblCreateDriver);
            this.pnlCreateRoute.Controls.Add(this.lblCreateDate);
            this.pnlCreateRoute.Controls.Add(this.lblCreateDateLabel);
            this.pnlCreateRoute.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlCreateRoute.Location = new System.Drawing.Point(3, 20);
            this.pnlCreateRoute.Name = "pnlCreateRoute";
            this.pnlCreateRoute.Size = new System.Drawing.Size(1166, 700);
            this.pnlCreateRoute.TabIndex = 0;
            // 
            // pnlCreateStops
            // 
            this.pnlCreateStops.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlCreateStops.Controls.Add(this.btnDoneAddingStops);
            this.pnlCreateStops.Controls.Add(this.btnAddNewStops);
            this.pnlCreateStops.Controls.Add(this.dgvAddStops);
            this.pnlCreateStops.Location = new System.Drawing.Point(141, 393);
            this.pnlCreateStops.Name = "pnlCreateStops";
            this.pnlCreateStops.Size = new System.Drawing.Size(644, 292);
            this.pnlCreateStops.TabIndex = 16;
            this.pnlCreateStops.Visible = false;
            // 
            // btnDoneAddingStops
            // 
            this.btnDoneAddingStops.BackColor = System.Drawing.Color.DarkRed;
            this.btnDoneAddingStops.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoneAddingStops.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDoneAddingStops.Location = new System.Drawing.Point(11, 212);
            this.btnDoneAddingStops.Name = "btnDoneAddingStops";
            this.btnDoneAddingStops.Size = new System.Drawing.Size(125, 75);
            this.btnDoneAddingStops.TabIndex = 38;
            this.btnDoneAddingStops.Text = "Done";
            this.btnDoneAddingStops.UseVisualStyleBackColor = false;
            this.btnDoneAddingStops.Click += new System.EventHandler(this.btnDoneAddingStops_Click);
            // 
            // btnAddNewStops
            // 
            this.btnAddNewStops.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAddNewStops.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewStops.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddNewStops.Location = new System.Drawing.Point(11, 5);
            this.btnAddNewStops.Name = "btnAddNewStops";
            this.btnAddNewStops.Size = new System.Drawing.Size(125, 75);
            this.btnAddNewStops.TabIndex = 37;
            this.btnAddNewStops.Text = "Add Stops";
            this.btnAddNewStops.UseVisualStyleBackColor = false;
            this.btnAddNewStops.Click += new System.EventHandler(this.btnAddNewStops_Click);
            // 
            // dgvAddStops
            // 
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.Maroon;
            this.dgvAddStops.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvAddStops.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvAddStops.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvAddStops.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAddStops.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.dgvAddStops.GridColor = System.Drawing.Color.Black;
            this.dgvAddStops.Location = new System.Drawing.Point(144, 5);
            this.dgvAddStops.Margin = new System.Windows.Forms.Padding(5);
            this.dgvAddStops.MultiSelect = false;
            this.dgvAddStops.Name = "dgvAddStops";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.Padding = new System.Windows.Forms.Padding(5);
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAddStops.RowHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvAddStops.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvAddStops.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvAddStops.RowTemplate.Height = 24;
            this.dgvAddStops.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAddStops.Size = new System.Drawing.Size(494, 282);
            this.dgvAddStops.TabIndex = 35;
            this.dgvAddStops.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvAddStops_KeyUp);
            // 
            // cbxBayIDs
            // 
            this.cbxBayIDs.FormattingEnabled = true;
            this.cbxBayIDs.Location = new System.Drawing.Point(619, 183);
            this.cbxBayIDs.Name = "cbxBayIDs";
            this.cbxBayIDs.Size = new System.Drawing.Size(189, 39);
            this.cbxBayIDs.TabIndex = 15;
            // 
            // lblCreateBayID
            // 
            this.lblCreateBayID.AutoSize = true;
            this.lblCreateBayID.Location = new System.Drawing.Point(383, 186);
            this.lblCreateBayID.Name = "lblCreateBayID";
            this.lblCreateBayID.Size = new System.Drawing.Size(230, 31);
            this.lblCreateBayID.TabIndex = 14;
            this.lblCreateBayID.Text = "Bay ID (Optional):";
            // 
            // lblRouteCodeCreated
            // 
            this.lblRouteCodeCreated.AutoSize = true;
            this.lblRouteCodeCreated.Location = new System.Drawing.Point(307, 325);
            this.lblRouteCodeCreated.Name = "lblRouteCodeCreated";
            this.lblRouteCodeCreated.Size = new System.Drawing.Size(0, 31);
            this.lblRouteCodeCreated.TabIndex = 13;
            // 
            // btnClearCreateForm
            // 
            this.btnClearCreateForm.BackColor = System.Drawing.Color.Yellow;
            this.btnClearCreateForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearCreateForm.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClearCreateForm.Location = new System.Drawing.Point(891, 614);
            this.btnClearCreateForm.Name = "btnClearCreateForm";
            this.btnClearCreateForm.Size = new System.Drawing.Size(209, 71);
            this.btnClearCreateForm.TabIndex = 11;
            this.btnClearCreateForm.Text = "Clear Form";
            this.btnClearCreateForm.UseVisualStyleBackColor = false;
            this.btnClearCreateForm.Click += new System.EventHandler(this.btnClearCreateForm_Click);
            // 
            // btnCreateRoute
            // 
            this.btnCreateRoute.BackColor = System.Drawing.Color.SeaGreen;
            this.btnCreateRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateRoute.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCreateRoute.Location = new System.Drawing.Point(455, 237);
            this.btnCreateRoute.Name = "btnCreateRoute";
            this.btnCreateRoute.Size = new System.Drawing.Size(209, 71);
            this.btnCreateRoute.TabIndex = 10;
            this.btnCreateRoute.Text = "Create Route";
            this.btnCreateRoute.UseVisualStyleBackColor = false;
            this.btnCreateRoute.Click += new System.EventHandler(this.btnCreateRoute_Click);
            // 
            // cbxCreateTrailer
            // 
            this.cbxCreateTrailer.FormattingEnabled = true;
            this.cbxCreateTrailer.Location = new System.Drawing.Point(806, 120);
            this.cbxCreateTrailer.Name = "cbxCreateTrailer";
            this.cbxCreateTrailer.Size = new System.Drawing.Size(187, 39);
            this.cbxCreateTrailer.TabIndex = 9;
            // 
            // lblCreateTrailer
            // 
            this.lblCreateTrailer.AutoSize = true;
            this.lblCreateTrailer.Location = new System.Drawing.Point(701, 123);
            this.lblCreateTrailer.Name = "lblCreateTrailer";
            this.lblCreateTrailer.Size = new System.Drawing.Size(99, 31);
            this.lblCreateTrailer.TabIndex = 8;
            this.lblCreateTrailer.Text = "Trailer:";
            // 
            // cbxCreateTruck
            // 
            this.cbxCreateTruck.FormattingEnabled = true;
            this.cbxCreateTruck.Location = new System.Drawing.Point(806, 58);
            this.cbxCreateTruck.Name = "cbxCreateTruck";
            this.cbxCreateTruck.Size = new System.Drawing.Size(187, 39);
            this.cbxCreateTruck.TabIndex = 7;
            // 
            // lblCreateTruck
            // 
            this.lblCreateTruck.AutoSize = true;
            this.lblCreateTruck.Location = new System.Drawing.Point(709, 61);
            this.lblCreateTruck.Name = "lblCreateTruck";
            this.lblCreateTruck.Size = new System.Drawing.Size(91, 31);
            this.lblCreateTruck.TabIndex = 6;
            this.lblCreateTruck.Text = "Truck:";
            // 
            // cbxCreateADriver
            // 
            this.cbxCreateADriver.FormattingEnabled = true;
            this.cbxCreateADriver.Location = new System.Drawing.Point(238, 119);
            this.cbxCreateADriver.Name = "cbxCreateADriver";
            this.cbxCreateADriver.Size = new System.Drawing.Size(375, 39);
            this.cbxCreateADriver.TabIndex = 5;
            // 
            // lblCreateADriver
            // 
            this.lblCreateADriver.AutoSize = true;
            this.lblCreateADriver.Location = new System.Drawing.Point(16, 123);
            this.lblCreateADriver.Name = "lblCreateADriver";
            this.lblCreateADriver.Size = new System.Drawing.Size(214, 31);
            this.lblCreateADriver.TabIndex = 4;
            this.lblCreateADriver.Text = "Assistant Driver:";
            // 
            // cbxCreateDriver
            // 
            this.cbxCreateDriver.FormattingEnabled = true;
            this.cbxCreateDriver.Location = new System.Drawing.Point(238, 54);
            this.cbxCreateDriver.Name = "cbxCreateDriver";
            this.cbxCreateDriver.Size = new System.Drawing.Size(375, 39);
            this.cbxCreateDriver.TabIndex = 3;
            // 
            // lblCreateDriver
            // 
            this.lblCreateDriver.AutoSize = true;
            this.lblCreateDriver.Location = new System.Drawing.Point(135, 61);
            this.lblCreateDriver.Name = "lblCreateDriver";
            this.lblCreateDriver.Size = new System.Drawing.Size(95, 31);
            this.lblCreateDriver.TabIndex = 2;
            this.lblCreateDriver.Text = "Driver:";
            // 
            // lblCreateDate
            // 
            this.lblCreateDate.AutoSize = true;
            this.lblCreateDate.Location = new System.Drawing.Point(449, 7);
            this.lblCreateDate.Name = "lblCreateDate";
            this.lblCreateDate.Size = new System.Drawing.Size(0, 31);
            this.lblCreateDate.TabIndex = 1;
            // 
            // lblCreateDateLabel
            // 
            this.lblCreateDateLabel.AutoSize = true;
            this.lblCreateDateLabel.Location = new System.Drawing.Point(367, 7);
            this.lblCreateDateLabel.Name = "lblCreateDateLabel";
            this.lblCreateDateLabel.Size = new System.Drawing.Size(80, 31);
            this.lblCreateDateLabel.TabIndex = 0;
            this.lblCreateDateLabel.Text = "Date:";
            // 
            // tabManageRoutes
            // 
            this.tabManageRoutes.Controls.Add(this.pnlManageRoutesMain);
            this.tabManageRoutes.Location = new System.Drawing.Point(4, 40);
            this.tabManageRoutes.Name = "tabManageRoutes";
            this.tabManageRoutes.Padding = new System.Windows.Forms.Padding(3);
            this.tabManageRoutes.Size = new System.Drawing.Size(1172, 723);
            this.tabManageRoutes.TabIndex = 1;
            this.tabManageRoutes.Text = "Manage Routes";
            this.tabManageRoutes.UseVisualStyleBackColor = true;
            // 
            // pnlManageRoutesMain
            // 
            this.pnlManageRoutesMain.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlManageRoutesMain.Controls.Add(this.pnlDetails);
            this.pnlManageRoutesMain.Controls.Add(this.pnlDeleteRoute);
            this.pnlManageRoutesMain.Controls.Add(this.pnlChangeStops);
            this.pnlManageRoutesMain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlManageRoutesMain.Location = new System.Drawing.Point(3, 6);
            this.pnlManageRoutesMain.Name = "pnlManageRoutesMain";
            this.pnlManageRoutesMain.Size = new System.Drawing.Size(1166, 714);
            this.pnlManageRoutesMain.TabIndex = 0;
            // 
            // pnlDetails
            // 
            this.pnlDetails.BackColor = System.Drawing.Color.Khaki;
            this.pnlDetails.Controls.Add(this.btnSaveChangeDetails);
            this.pnlDetails.Controls.Add(this.cbxChangeBayID);
            this.pnlDetails.Controls.Add(this.lblNewBayID);
            this.pnlDetails.Controls.Add(this.lblCurrentBayID);
            this.pnlDetails.Controls.Add(this.lblForBayID);
            this.pnlDetails.Controls.Add(this.cbxChangeTrailerTo);
            this.pnlDetails.Controls.Add(this.cbxChangeTruckTo);
            this.pnlDetails.Controls.Add(this.cbxChangeAsstDriverTo);
            this.pnlDetails.Controls.Add(this.cbxChangeDriverTo);
            this.pnlDetails.Controls.Add(this.lblChangeTrailerTo);
            this.pnlDetails.Controls.Add(this.lblChangeTruckTo);
            this.pnlDetails.Controls.Add(this.lblChangeAsstDriverTo);
            this.pnlDetails.Controls.Add(this.lblChangeDriverTo);
            this.pnlDetails.Controls.Add(this.lblCurrentTrailer);
            this.pnlDetails.Controls.Add(this.lblCurrentTruck);
            this.pnlDetails.Controls.Add(this.lblCurrentASstDriver);
            this.pnlDetails.Controls.Add(this.lblCurrentDriver);
            this.pnlDetails.Controls.Add(this.lblCurrentTrailerLabel);
            this.pnlDetails.Controls.Add(this.lblCurrentTruckLabel);
            this.pnlDetails.Controls.Add(this.lblCurrentAsstDriverLabel);
            this.pnlDetails.Controls.Add(this.lblCurrentDriverLabel);
            this.pnlDetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDetails.Location = new System.Drawing.Point(0, 96);
            this.pnlDetails.Name = "pnlDetails";
            this.pnlDetails.Size = new System.Drawing.Size(1166, 241);
            this.pnlDetails.TabIndex = 36;
            // 
            // btnSaveChangeDetails
            // 
            this.btnSaveChangeDetails.BackColor = System.Drawing.Color.Goldenrod;
            this.btnSaveChangeDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveChangeDetails.Location = new System.Drawing.Point(978, 107);
            this.btnSaveChangeDetails.Name = "btnSaveChangeDetails";
            this.btnSaveChangeDetails.Size = new System.Drawing.Size(116, 118);
            this.btnSaveChangeDetails.TabIndex = 36;
            this.btnSaveChangeDetails.Text = "Change Details";
            this.btnSaveChangeDetails.UseVisualStyleBackColor = false;
            this.btnSaveChangeDetails.Click += new System.EventHandler(this.btnSaveChangeDetails_Click);
            // 
            // cbxChangeBayID
            // 
            this.cbxChangeBayID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxChangeBayID.FormattingEnabled = true;
            this.cbxChangeBayID.Location = new System.Drawing.Point(781, 193);
            this.cbxChangeBayID.Name = "cbxChangeBayID";
            this.cbxChangeBayID.Size = new System.Drawing.Size(174, 33);
            this.cbxChangeBayID.TabIndex = 35;
            // 
            // lblNewBayID
            // 
            this.lblNewBayID.AutoSize = true;
            this.lblNewBayID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewBayID.Location = new System.Drawing.Point(512, 196);
            this.lblNewBayID.Name = "lblNewBayID";
            this.lblNewBayID.Size = new System.Drawing.Size(180, 25);
            this.lblNewBayID.TabIndex = 34;
            this.lblNewBayID.Text = "Change Bay ID To:";
            // 
            // lblCurrentBayID
            // 
            this.lblCurrentBayID.AutoSize = true;
            this.lblCurrentBayID.Location = new System.Drawing.Point(231, 190);
            this.lblCurrentBayID.Name = "lblCurrentBayID";
            this.lblCurrentBayID.Size = new System.Drawing.Size(0, 31);
            this.lblCurrentBayID.TabIndex = 33;
            // 
            // lblForBayID
            // 
            this.lblForBayID.AutoSize = true;
            this.lblForBayID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForBayID.Location = new System.Drawing.Point(11, 196);
            this.lblForBayID.Name = "lblForBayID";
            this.lblForBayID.Size = new System.Drawing.Size(76, 25);
            this.lblForBayID.TabIndex = 32;
            this.lblForBayID.Text = "Bay ID:";
            // 
            // cbxChangeTrailerTo
            // 
            this.cbxChangeTrailerTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxChangeTrailerTo.FormattingEnabled = true;
            this.cbxChangeTrailerTo.Location = new System.Drawing.Point(781, 149);
            this.cbxChangeTrailerTo.Name = "cbxChangeTrailerTo";
            this.cbxChangeTrailerTo.Size = new System.Drawing.Size(174, 33);
            this.cbxChangeTrailerTo.TabIndex = 31;
            // 
            // cbxChangeTruckTo
            // 
            this.cbxChangeTruckTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxChangeTruckTo.FormattingEnabled = true;
            this.cbxChangeTruckTo.Location = new System.Drawing.Point(781, 105);
            this.cbxChangeTruckTo.Name = "cbxChangeTruckTo";
            this.cbxChangeTruckTo.Size = new System.Drawing.Size(174, 33);
            this.cbxChangeTruckTo.TabIndex = 30;
            // 
            // cbxChangeAsstDriverTo
            // 
            this.cbxChangeAsstDriverTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxChangeAsstDriverTo.FormattingEnabled = true;
            this.cbxChangeAsstDriverTo.Location = new System.Drawing.Point(781, 58);
            this.cbxChangeAsstDriverTo.Name = "cbxChangeAsstDriverTo";
            this.cbxChangeAsstDriverTo.Size = new System.Drawing.Size(314, 33);
            this.cbxChangeAsstDriverTo.TabIndex = 29;
            // 
            // cbxChangeDriverTo
            // 
            this.cbxChangeDriverTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxChangeDriverTo.FormattingEnabled = true;
            this.cbxChangeDriverTo.Location = new System.Drawing.Point(781, 14);
            this.cbxChangeDriverTo.Name = "cbxChangeDriverTo";
            this.cbxChangeDriverTo.Size = new System.Drawing.Size(314, 33);
            this.cbxChangeDriverTo.TabIndex = 28;
            // 
            // lblChangeTrailerTo
            // 
            this.lblChangeTrailerTo.AutoSize = true;
            this.lblChangeTrailerTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeTrailerTo.Location = new System.Drawing.Point(512, 152);
            this.lblChangeTrailerTo.Name = "lblChangeTrailerTo";
            this.lblChangeTrailerTo.Size = new System.Drawing.Size(177, 25);
            this.lblChangeTrailerTo.TabIndex = 27;
            this.lblChangeTrailerTo.Text = "Change Trailer To:";
            // 
            // lblChangeTruckTo
            // 
            this.lblChangeTruckTo.AutoSize = true;
            this.lblChangeTruckTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeTruckTo.Location = new System.Drawing.Point(512, 108);
            this.lblChangeTruckTo.Name = "lblChangeTruckTo";
            this.lblChangeTruckTo.Size = new System.Drawing.Size(172, 25);
            this.lblChangeTruckTo.TabIndex = 26;
            this.lblChangeTruckTo.Text = "Change Truck To:";
            // 
            // lblChangeAsstDriverTo
            // 
            this.lblChangeAsstDriverTo.AutoSize = true;
            this.lblChangeAsstDriverTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeAsstDriverTo.Location = new System.Drawing.Point(512, 61);
            this.lblChangeAsstDriverTo.Name = "lblChangeAsstDriverTo";
            this.lblChangeAsstDriverTo.Size = new System.Drawing.Size(258, 25);
            this.lblChangeAsstDriverTo.TabIndex = 25;
            this.lblChangeAsstDriverTo.Text = "Change Assistant Driver To:";
            // 
            // lblChangeDriverTo
            // 
            this.lblChangeDriverTo.AutoSize = true;
            this.lblChangeDriverTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeDriverTo.Location = new System.Drawing.Point(512, 17);
            this.lblChangeDriverTo.Name = "lblChangeDriverTo";
            this.lblChangeDriverTo.Size = new System.Drawing.Size(173, 25);
            this.lblChangeDriverTo.TabIndex = 24;
            this.lblChangeDriverTo.Text = "Change Driver To:";
            // 
            // lblCurrentTrailer
            // 
            this.lblCurrentTrailer.AutoSize = true;
            this.lblCurrentTrailer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTrailer.Location = new System.Drawing.Point(232, 152);
            this.lblCurrentTrailer.Name = "lblCurrentTrailer";
            this.lblCurrentTrailer.Size = new System.Drawing.Size(0, 25);
            this.lblCurrentTrailer.TabIndex = 23;
            // 
            // lblCurrentTruck
            // 
            this.lblCurrentTruck.AutoSize = true;
            this.lblCurrentTruck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTruck.Location = new System.Drawing.Point(232, 108);
            this.lblCurrentTruck.Name = "lblCurrentTruck";
            this.lblCurrentTruck.Size = new System.Drawing.Size(0, 25);
            this.lblCurrentTruck.TabIndex = 22;
            // 
            // lblCurrentASstDriver
            // 
            this.lblCurrentASstDriver.AutoSize = true;
            this.lblCurrentASstDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentASstDriver.Location = new System.Drawing.Point(232, 61);
            this.lblCurrentASstDriver.Name = "lblCurrentASstDriver";
            this.lblCurrentASstDriver.Size = new System.Drawing.Size(0, 25);
            this.lblCurrentASstDriver.TabIndex = 21;
            // 
            // lblCurrentDriver
            // 
            this.lblCurrentDriver.AutoSize = true;
            this.lblCurrentDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDriver.Location = new System.Drawing.Point(232, 17);
            this.lblCurrentDriver.Name = "lblCurrentDriver";
            this.lblCurrentDriver.Size = new System.Drawing.Size(0, 25);
            this.lblCurrentDriver.TabIndex = 20;
            // 
            // lblCurrentTrailerLabel
            // 
            this.lblCurrentTrailerLabel.AutoSize = true;
            this.lblCurrentTrailerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTrailerLabel.Location = new System.Drawing.Point(11, 152);
            this.lblCurrentTrailerLabel.Name = "lblCurrentTrailerLabel";
            this.lblCurrentTrailerLabel.Size = new System.Drawing.Size(143, 25);
            this.lblCurrentTrailerLabel.TabIndex = 19;
            this.lblCurrentTrailerLabel.Text = "Current Trailer:";
            // 
            // lblCurrentTruckLabel
            // 
            this.lblCurrentTruckLabel.AutoSize = true;
            this.lblCurrentTruckLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTruckLabel.Location = new System.Drawing.Point(11, 108);
            this.lblCurrentTruckLabel.Name = "lblCurrentTruckLabel";
            this.lblCurrentTruckLabel.Size = new System.Drawing.Size(138, 25);
            this.lblCurrentTruckLabel.TabIndex = 18;
            this.lblCurrentTruckLabel.Text = "Current Truck:";
            // 
            // lblCurrentAsstDriverLabel
            // 
            this.lblCurrentAsstDriverLabel.AutoSize = true;
            this.lblCurrentAsstDriverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentAsstDriverLabel.Location = new System.Drawing.Point(11, 61);
            this.lblCurrentAsstDriverLabel.Name = "lblCurrentAsstDriverLabel";
            this.lblCurrentAsstDriverLabel.Size = new System.Drawing.Size(224, 25);
            this.lblCurrentAsstDriverLabel.TabIndex = 17;
            this.lblCurrentAsstDriverLabel.Text = "Current Assistant Driver:";
            // 
            // lblCurrentDriverLabel
            // 
            this.lblCurrentDriverLabel.AutoSize = true;
            this.lblCurrentDriverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDriverLabel.Location = new System.Drawing.Point(11, 17);
            this.lblCurrentDriverLabel.Name = "lblCurrentDriverLabel";
            this.lblCurrentDriverLabel.Size = new System.Drawing.Size(139, 25);
            this.lblCurrentDriverLabel.TabIndex = 16;
            this.lblCurrentDriverLabel.Text = "Current Driver:";
            // 
            // pnlDeleteRoute
            // 
            this.pnlDeleteRoute.BackColor = System.Drawing.Color.PaleVioletRed;
            this.pnlDeleteRoute.Controls.Add(this.btnDeleteRoute);
            this.pnlDeleteRoute.Controls.Add(this.lblManageRouteROUTE);
            this.pnlDeleteRoute.Controls.Add(this.cbxChangeRoute);
            this.pnlDeleteRoute.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDeleteRoute.Location = new System.Drawing.Point(0, 0);
            this.pnlDeleteRoute.Name = "pnlDeleteRoute";
            this.pnlDeleteRoute.Size = new System.Drawing.Size(1166, 96);
            this.pnlDeleteRoute.TabIndex = 35;
            // 
            // btnDeleteRoute
            // 
            this.btnDeleteRoute.BackColor = System.Drawing.Color.DarkRed;
            this.btnDeleteRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteRoute.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDeleteRoute.Location = new System.Drawing.Point(17, 9);
            this.btnDeleteRoute.Name = "btnDeleteRoute";
            this.btnDeleteRoute.Size = new System.Drawing.Size(182, 78);
            this.btnDeleteRoute.TabIndex = 14;
            this.btnDeleteRoute.Text = "DELETE ROUTE";
            this.btnDeleteRoute.UseVisualStyleBackColor = false;
            this.btnDeleteRoute.Click += new System.EventHandler(this.btnDeleteRoute_Click);
            // 
            // lblManageRouteROUTE
            // 
            this.lblManageRouteROUTE.AutoSize = true;
            this.lblManageRouteROUTE.Location = new System.Drawing.Point(301, 32);
            this.lblManageRouteROUTE.Name = "lblManageRouteROUTE";
            this.lblManageRouteROUTE.Size = new System.Drawing.Size(125, 31);
            this.lblManageRouteROUTE.TabIndex = 13;
            this.lblManageRouteROUTE.Text = "ROUTE: ";
            // 
            // cbxChangeRoute
            // 
            this.cbxChangeRoute.FormattingEnabled = true;
            this.cbxChangeRoute.Location = new System.Drawing.Point(432, 24);
            this.cbxChangeRoute.Name = "cbxChangeRoute";
            this.cbxChangeRoute.Size = new System.Drawing.Size(325, 39);
            this.cbxChangeRoute.TabIndex = 12;
            this.cbxChangeRoute.SelectedIndexChanged += new System.EventHandler(this.cbxChangeRoute_SelectedIndexChanged);
            // 
            // pnlChangeStops
            // 
            this.pnlChangeStops.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlChangeStops.Controls.Add(this.btnAddStopsFromChange);
            this.pnlChangeStops.Controls.Add(this.btnDeleteStop);
            this.pnlChangeStops.Controls.Add(this.lblChangeStopsTo);
            this.pnlChangeStops.Controls.Add(this.dgvChangeAddStops);
            this.pnlChangeStops.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlChangeStops.Location = new System.Drawing.Point(0, 343);
            this.pnlChangeStops.Name = "pnlChangeStops";
            this.pnlChangeStops.Size = new System.Drawing.Size(1166, 371);
            this.pnlChangeStops.TabIndex = 37;
            // 
            // btnAddStopsFromChange
            // 
            this.btnAddStopsFromChange.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAddStopsFromChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStopsFromChange.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddStopsFromChange.Location = new System.Drawing.Point(3, 291);
            this.btnAddStopsFromChange.Name = "btnAddStopsFromChange";
            this.btnAddStopsFromChange.Size = new System.Drawing.Size(125, 75);
            this.btnAddStopsFromChange.TabIndex = 36;
            this.btnAddStopsFromChange.Text = "Add Stops";
            this.btnAddStopsFromChange.UseVisualStyleBackColor = false;
            this.btnAddStopsFromChange.Click += new System.EventHandler(this.btnAddStopsFromChange_Click);
            // 
            // btnDeleteStop
            // 
            this.btnDeleteStop.BackColor = System.Drawing.Color.DarkRed;
            this.btnDeleteStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteStop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDeleteStop.Location = new System.Drawing.Point(3, 46);
            this.btnDeleteStop.Name = "btnDeleteStop";
            this.btnDeleteStop.Size = new System.Drawing.Size(125, 75);
            this.btnDeleteStop.TabIndex = 35;
            this.btnDeleteStop.Text = "Delete Stop";
            this.btnDeleteStop.UseVisualStyleBackColor = false;
            this.btnDeleteStop.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblChangeStopsTo
            // 
            this.lblChangeStopsTo.AutoSize = true;
            this.lblChangeStopsTo.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblChangeStopsTo.Location = new System.Drawing.Point(310, 10);
            this.lblChangeStopsTo.Name = "lblChangeStopsTo";
            this.lblChangeStopsTo.Size = new System.Drawing.Size(186, 31);
            this.lblChangeStopsTo.TabIndex = 33;
            this.lblChangeStopsTo.Text = "Change Stops";
            // 
            // dgvChangeAddStops
            // 
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.Maroon;
            this.dgvChangeAddStops.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvChangeAddStops.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvChangeAddStops.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvChangeAddStops.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChangeAddStops.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.dgvChangeAddStops.GridColor = System.Drawing.Color.Black;
            this.dgvChangeAddStops.Location = new System.Drawing.Point(136, 46);
            this.dgvChangeAddStops.Margin = new System.Windows.Forms.Padding(5);
            this.dgvChangeAddStops.MultiSelect = false;
            this.dgvChangeAddStops.Name = "dgvChangeAddStops";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.Padding = new System.Windows.Forms.Padding(5);
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvChangeAddStops.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvChangeAddStops.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvChangeAddStops.RowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvChangeAddStops.RowTemplate.Height = 24;
            this.dgvChangeAddStops.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChangeAddStops.Size = new System.Drawing.Size(993, 318);
            this.dgvChangeAddStops.TabIndex = 34;
            this.dgvChangeAddStops.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgvChangeAddStops_UserDeletingRow);
            this.dgvChangeAddStops.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvChangeAddStops_KeyUp);
            // 
            // tabShipStatus
            // 
            this.tabShipStatus.Controls.Add(this.pnlStatus);
            this.tabShipStatus.Location = new System.Drawing.Point(4, 40);
            this.tabShipStatus.Name = "tabShipStatus";
            this.tabShipStatus.Padding = new System.Windows.Forms.Padding(3);
            this.tabShipStatus.Size = new System.Drawing.Size(1348, 723);
            this.tabShipStatus.TabIndex = 3;
            this.tabShipStatus.Text = "Status";
            this.tabShipStatus.UseVisualStyleBackColor = true;
            // 
            // pnlStatus
            // 
            this.pnlStatus.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlStatus.Controls.Add(this.pnlRouteStatus);
            this.pnlStatus.Controls.Add(this.lblGetDeliveryStatus);
            this.pnlStatus.Controls.Add(this.dgvDeliveryStatusDetails);
            this.pnlStatus.Controls.Add(this.dgvDeliveryStatusStops);
            this.pnlStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatus.Location = new System.Drawing.Point(3, 6);
            this.pnlStatus.Name = "pnlStatus";
            this.pnlStatus.Size = new System.Drawing.Size(1342, 714);
            this.pnlStatus.TabIndex = 0;
            // 
            // pnlRouteStatus
            // 
            this.pnlRouteStatus.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.pnlRouteStatus.Controls.Add(this.txtJobIDSearch);
            this.pnlRouteStatus.Controls.Add(this.txtPickTicketSearch);
            this.pnlRouteStatus.Controls.Add(this.cbxDeliveryRoutes);
            this.pnlRouteStatus.Controls.Add(this.lblDeliveryRoute);
            this.pnlRouteStatus.Controls.Add(this.lblPickTicketSearch);
            this.pnlRouteStatus.Controls.Add(this.lblJobID);
            this.pnlRouteStatus.Location = new System.Drawing.Point(5, 60);
            this.pnlRouteStatus.Name = "pnlRouteStatus";
            this.pnlRouteStatus.Size = new System.Drawing.Size(526, 159);
            this.pnlRouteStatus.TabIndex = 10;
            // 
            // txtJobIDSearch
            // 
            this.txtJobIDSearch.Location = new System.Drawing.Point(163, 112);
            this.txtJobIDSearch.Name = "txtJobIDSearch";
            this.txtJobIDSearch.Size = new System.Drawing.Size(181, 38);
            this.txtJobIDSearch.TabIndex = 10;
            this.txtJobIDSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtJobIDSearch_KeyUp);
            // 
            // txtPickTicketSearch
            // 
            this.txtPickTicketSearch.Location = new System.Drawing.Point(163, 63);
            this.txtPickTicketSearch.Name = "txtPickTicketSearch";
            this.txtPickTicketSearch.Size = new System.Drawing.Size(181, 38);
            this.txtPickTicketSearch.TabIndex = 9;
            this.txtPickTicketSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPickTicketSearch_KeyUp);
            // 
            // cbxDeliveryRoutes
            // 
            this.cbxDeliveryRoutes.FormattingEnabled = true;
            this.cbxDeliveryRoutes.Location = new System.Drawing.Point(163, 12);
            this.cbxDeliveryRoutes.Name = "cbxDeliveryRoutes";
            this.cbxDeliveryRoutes.Size = new System.Drawing.Size(347, 39);
            this.cbxDeliveryRoutes.TabIndex = 2;
            this.cbxDeliveryRoutes.SelectedIndexChanged += new System.EventHandler(this.cbxDeliveryRoutes_SelectedIndexChanged);
            // 
            // lblDeliveryRoute
            // 
            this.lblDeliveryRoute.AutoSize = true;
            this.lblDeliveryRoute.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDeliveryRoute.Location = new System.Drawing.Point(68, 15);
            this.lblDeliveryRoute.Name = "lblDeliveryRoute";
            this.lblDeliveryRoute.Size = new System.Drawing.Size(95, 31);
            this.lblDeliveryRoute.TabIndex = 1;
            this.lblDeliveryRoute.Text = "Route:";
            // 
            // lblPickTicketSearch
            // 
            this.lblPickTicketSearch.AutoSize = true;
            this.lblPickTicketSearch.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblPickTicketSearch.Location = new System.Drawing.Point(9, 66);
            this.lblPickTicketSearch.Name = "lblPickTicketSearch";
            this.lblPickTicketSearch.Size = new System.Drawing.Size(155, 31);
            this.lblPickTicketSearch.TabIndex = 5;
            this.lblPickTicketSearch.Text = "Pick Ticket:";
            // 
            // lblJobID
            // 
            this.lblJobID.AutoSize = true;
            this.lblJobID.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblJobID.Location = new System.Drawing.Point(63, 115);
            this.lblJobID.Name = "lblJobID";
            this.lblJobID.Size = new System.Drawing.Size(101, 31);
            this.lblJobID.TabIndex = 7;
            this.lblJobID.Text = "Job ID:";
            // 
            // lblGetDeliveryStatus
            // 
            this.lblGetDeliveryStatus.AutoSize = true;
            this.lblGetDeliveryStatus.Location = new System.Drawing.Point(203, 17);
            this.lblGetDeliveryStatus.Name = "lblGetDeliveryStatus";
            this.lblGetDeliveryStatus.Size = new System.Drawing.Size(720, 31);
            this.lblGetDeliveryStatus.TabIndex = 9;
            this.lblGetDeliveryStatus.Text = "Get unit delivery status by selecting a search option below.";
            // 
            // dgvDeliveryStatusDetails
            // 
            this.dgvDeliveryStatusDetails.AllowUserToAddRows = false;
            this.dgvDeliveryStatusDetails.AllowUserToDeleteRows = false;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvDeliveryStatusDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvDeliveryStatusDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDeliveryStatusDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDeliveryStatusDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvDeliveryStatusDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDeliveryStatusDetails.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgvDeliveryStatusDetails.Location = new System.Drawing.Point(433, 225);
            this.dgvDeliveryStatusDetails.Name = "dgvDeliveryStatusDetails";
            this.dgvDeliveryStatusDetails.ReadOnly = true;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDeliveryStatusDetails.RowHeadersDefaultCellStyle = dataGridViewCellStyle25;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvDeliveryStatusDetails.RowsDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvDeliveryStatusDetails.RowTemplate.Height = 24;
            this.dgvDeliveryStatusDetails.Size = new System.Drawing.Size(906, 489);
            this.dgvDeliveryStatusDetails.TabIndex = 4;
            // 
            // dgvDeliveryStatusStops
            // 
            this.dgvDeliveryStatusStops.AllowUserToAddRows = false;
            this.dgvDeliveryStatusStops.AllowUserToDeleteRows = false;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvDeliveryStatusStops.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvDeliveryStatusStops.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDeliveryStatusStops.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvDeliveryStatusStops.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeliveryStatusStops.Location = new System.Drawing.Point(5, 225);
            this.dgvDeliveryStatusStops.Name = "dgvDeliveryStatusStops";
            this.dgvDeliveryStatusStops.ReadOnly = true;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDeliveryStatusStops.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvDeliveryStatusStops.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvDeliveryStatusStops.RowTemplate.Height = 24;
            this.dgvDeliveryStatusStops.Size = new System.Drawing.Size(372, 489);
            this.dgvDeliveryStatusStops.TabIndex = 3;
            this.dgvDeliveryStatusStops.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDeliveryStatusStops_CellClick);
            // 
            // tabAddDelAssets
            // 
            this.tabAddDelAssets.Controls.Add(this.pnlAddDel);
            this.tabAddDelAssets.Location = new System.Drawing.Point(4, 40);
            this.tabAddDelAssets.Name = "tabAddDelAssets";
            this.tabAddDelAssets.Padding = new System.Windows.Forms.Padding(3);
            this.tabAddDelAssets.Size = new System.Drawing.Size(1348, 723);
            this.tabAddDelAssets.TabIndex = 4;
            this.tabAddDelAssets.Text = "Add/Delete Assets";
            this.tabAddDelAssets.UseVisualStyleBackColor = true;
            // 
            // pnlAddDel
            // 
            this.pnlAddDel.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlAddDel.Controls.Add(this.pnlAddAsset);
            this.pnlAddDel.Controls.Add(this.pnlDeleteAsset);
            this.pnlAddDel.Location = new System.Drawing.Point(5, 5);
            this.pnlAddDel.Name = "pnlAddDel";
            this.pnlAddDel.Size = new System.Drawing.Size(1335, 714);
            this.pnlAddDel.TabIndex = 0;
            // 
            // pnlAddAsset
            // 
            this.pnlAddAsset.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlAddAsset.Controls.Add(this.pnlAddTrailer);
            this.pnlAddAsset.Controls.Add(this.pnlAddTruck);
            this.pnlAddAsset.Controls.Add(this.pnlAddADriver);
            this.pnlAddAsset.Controls.Add(this.pnlAddDriver);
            this.pnlAddAsset.Controls.Add(this.lblSelectAssetToAdd);
            this.pnlAddAsset.Controls.Add(this.cbxAddAsset);
            this.pnlAddAsset.Location = new System.Drawing.Point(9, 257);
            this.pnlAddAsset.Name = "pnlAddAsset";
            this.pnlAddAsset.Size = new System.Drawing.Size(1323, 453);
            this.pnlAddAsset.TabIndex = 49;
            // 
            // pnlAddTrailer
            // 
            this.pnlAddTrailer.Controls.Add(this.cbxTrailerType);
            this.pnlAddTrailer.Controls.Add(this.cbxTrailerLocation);
            this.pnlAddTrailer.Controls.Add(this.txtbxTrailerModel);
            this.pnlAddTrailer.Controls.Add(this.txtbxTrailerAssetNumber);
            this.pnlAddTrailer.Controls.Add(this.cbxTrailerMaintType);
            this.pnlAddTrailer.Controls.Add(this.cbxTrailerYear);
            this.pnlAddTrailer.Controls.Add(this.txtbxTrailerAssetID);
            this.pnlAddTrailer.Controls.Add(this.lblTrailerType);
            this.pnlAddTrailer.Controls.Add(this.lblTrailerMaintType);
            this.pnlAddTrailer.Controls.Add(this.lblTrailerLocation);
            this.pnlAddTrailer.Controls.Add(this.btnAddTrailer);
            this.pnlAddTrailer.Controls.Add(this.lblTrailerModel);
            this.pnlAddTrailer.Controls.Add(this.lblbTrailerYear);
            this.pnlAddTrailer.Controls.Add(this.lblTrailerAssetID);
            this.pnlAddTrailer.Controls.Add(this.lblTrailerAssetNumber);
            this.pnlAddTrailer.Location = new System.Drawing.Point(99, 123);
            this.pnlAddTrailer.Name = "pnlAddTrailer";
            this.pnlAddTrailer.Size = new System.Drawing.Size(1040, 294);
            this.pnlAddTrailer.TabIndex = 20;
            this.pnlAddTrailer.Visible = false;
            // 
            // cbxTrailerType
            // 
            this.cbxTrailerType.FormattingEnabled = true;
            this.cbxTrailerType.Items.AddRange(new object[] {
            "",
            "R-A1F",
            "R-A1U",
            "R-A2B",
            "R-T1B",
            "R-T1C",
            "R-T9",
            "R-T9S"});
            this.cbxTrailerType.Location = new System.Drawing.Point(307, 207);
            this.cbxTrailerType.Name = "cbxTrailerType";
            this.cbxTrailerType.Size = new System.Drawing.Size(134, 39);
            this.cbxTrailerType.TabIndex = 19;
            // 
            // cbxTrailerLocation
            // 
            this.cbxTrailerLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTrailerLocation.FormattingEnabled = true;
            this.cbxTrailerLocation.Location = new System.Drawing.Point(696, 150);
            this.cbxTrailerLocation.Name = "cbxTrailerLocation";
            this.cbxTrailerLocation.Size = new System.Drawing.Size(216, 39);
            this.cbxTrailerLocation.TabIndex = 18;
            // 
            // txtbxTrailerModel
            // 
            this.txtbxTrailerModel.Location = new System.Drawing.Point(666, 89);
            this.txtbxTrailerModel.Name = "txtbxTrailerModel";
            this.txtbxTrailerModel.Size = new System.Drawing.Size(326, 38);
            this.txtbxTrailerModel.TabIndex = 17;
            // 
            // txtbxTrailerAssetNumber
            // 
            this.txtbxTrailerAssetNumber.Location = new System.Drawing.Point(768, 36);
            this.txtbxTrailerAssetNumber.Name = "txtbxTrailerAssetNumber";
            this.txtbxTrailerAssetNumber.Size = new System.Drawing.Size(224, 38);
            this.txtbxTrailerAssetNumber.TabIndex = 16;
            this.txtbxTrailerAssetNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxTrailerAssetNumber_KeyPress);
            // 
            // cbxTrailerMaintType
            // 
            this.cbxTrailerMaintType.FormattingEnabled = true;
            this.cbxTrailerMaintType.Items.AddRange(new object[] {
            "",
            "AUTO",
            "OLAUTO"});
            this.cbxTrailerMaintType.Location = new System.Drawing.Point(307, 150);
            this.cbxTrailerMaintType.Name = "cbxTrailerMaintType";
            this.cbxTrailerMaintType.Size = new System.Drawing.Size(134, 39);
            this.cbxTrailerMaintType.TabIndex = 15;
            // 
            // cbxTrailerYear
            // 
            this.cbxTrailerYear.FormattingEnabled = true;
            this.cbxTrailerYear.Items.AddRange(new object[] {
            "",
            "1996",
            "1997",
            "1998",
            "1999",
            "2000",
            "2001",
            "2002",
            "2003",
            "2004",
            "2005",
            "2006",
            "2007",
            "2008",
            "2009",
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022"});
            this.cbxTrailerYear.Location = new System.Drawing.Point(307, 93);
            this.cbxTrailerYear.Name = "cbxTrailerYear";
            this.cbxTrailerYear.Size = new System.Drawing.Size(134, 39);
            this.cbxTrailerYear.TabIndex = 14;
            // 
            // txtbxTrailerAssetID
            // 
            this.txtbxTrailerAssetID.Location = new System.Drawing.Point(307, 36);
            this.txtbxTrailerAssetID.Name = "txtbxTrailerAssetID";
            this.txtbxTrailerAssetID.Size = new System.Drawing.Size(224, 38);
            this.txtbxTrailerAssetID.TabIndex = 13;
            // 
            // lblTrailerType
            // 
            this.lblTrailerType.AutoSize = true;
            this.lblTrailerType.Location = new System.Drawing.Point(52, 210);
            this.lblTrailerType.Name = "lblTrailerType";
            this.lblTrailerType.Size = new System.Drawing.Size(75, 31);
            this.lblTrailerType.TabIndex = 12;
            this.lblTrailerType.Text = "Type";
            // 
            // lblTrailerMaintType
            // 
            this.lblTrailerMaintType.AutoSize = true;
            this.lblTrailerMaintType.Location = new System.Drawing.Point(52, 153);
            this.lblTrailerMaintType.Name = "lblTrailerMaintType";
            this.lblTrailerMaintType.Size = new System.Drawing.Size(237, 31);
            this.lblTrailerMaintType.TabIndex = 11;
            this.lblTrailerMaintType.Text = "Maintenance Type";
            // 
            // lblTrailerLocation
            // 
            this.lblTrailerLocation.AutoSize = true;
            this.lblTrailerLocation.Location = new System.Drawing.Point(573, 153);
            this.lblTrailerLocation.Name = "lblTrailerLocation";
            this.lblTrailerLocation.Size = new System.Drawing.Size(117, 31);
            this.lblTrailerLocation.TabIndex = 3;
            this.lblTrailerLocation.Text = "Location";
            // 
            // btnAddTrailer
            // 
            this.btnAddTrailer.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAddTrailer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddTrailer.Location = new System.Drawing.Point(913, 198);
            this.btnAddTrailer.Name = "btnAddTrailer";
            this.btnAddTrailer.Size = new System.Drawing.Size(115, 86);
            this.btnAddTrailer.TabIndex = 10;
            this.btnAddTrailer.Text = "Add Trailer";
            this.btnAddTrailer.UseVisualStyleBackColor = false;
            this.btnAddTrailer.Click += new System.EventHandler(this.btnAddTrailer_Click);
            // 
            // lblTrailerModel
            // 
            this.lblTrailerModel.AutoSize = true;
            this.lblTrailerModel.Location = new System.Drawing.Point(573, 96);
            this.lblTrailerModel.Name = "lblTrailerModel";
            this.lblTrailerModel.Size = new System.Drawing.Size(87, 31);
            this.lblTrailerModel.TabIndex = 4;
            this.lblTrailerModel.Text = "Model";
            // 
            // lblbTrailerYear
            // 
            this.lblbTrailerYear.AutoSize = true;
            this.lblbTrailerYear.Location = new System.Drawing.Point(52, 96);
            this.lblbTrailerYear.Name = "lblbTrailerYear";
            this.lblbTrailerYear.Size = new System.Drawing.Size(71, 31);
            this.lblbTrailerYear.TabIndex = 2;
            this.lblbTrailerYear.Text = "Year";
            // 
            // lblTrailerAssetID
            // 
            this.lblTrailerAssetID.AutoSize = true;
            this.lblTrailerAssetID.Location = new System.Drawing.Point(52, 39);
            this.lblTrailerAssetID.Name = "lblTrailerAssetID";
            this.lblTrailerAssetID.Size = new System.Drawing.Size(118, 31);
            this.lblTrailerAssetID.TabIndex = 1;
            this.lblTrailerAssetID.Text = "Asset ID";
            // 
            // lblTrailerAssetNumber
            // 
            this.lblTrailerAssetNumber.AutoSize = true;
            this.lblTrailerAssetNumber.Location = new System.Drawing.Point(573, 39);
            this.lblTrailerAssetNumber.Name = "lblTrailerAssetNumber";
            this.lblTrailerAssetNumber.Size = new System.Drawing.Size(186, 31);
            this.lblTrailerAssetNumber.TabIndex = 0;
            this.lblTrailerAssetNumber.Text = "Asset Number";
            // 
            // pnlAddTruck
            // 
            this.pnlAddTruck.Controls.Add(this.cbxTruckOther);
            this.pnlAddTruck.Controls.Add(this.cbxTruckLocation);
            this.pnlAddTruck.Controls.Add(this.txtbxTruckModel);
            this.pnlAddTruck.Controls.Add(this.txtbxTruckAssetNumber);
            this.pnlAddTruck.Controls.Add(this.cbxTruckMaintType);
            this.pnlAddTruck.Controls.Add(this.cbxTruckYear);
            this.pnlAddTruck.Controls.Add(this.txtbxTruckAssetID);
            this.pnlAddTruck.Controls.Add(this.lblAssetType);
            this.pnlAddTruck.Controls.Add(this.lblMaintenanceType);
            this.pnlAddTruck.Controls.Add(this.lblAssetLocation);
            this.pnlAddTruck.Controls.Add(this.btnAddTruck);
            this.pnlAddTruck.Controls.Add(this.lblAssetModel);
            this.pnlAddTruck.Controls.Add(this.lblAssetYear);
            this.pnlAddTruck.Controls.Add(this.lblAssetID);
            this.pnlAddTruck.Controls.Add(this.lblAssetNumber);
            this.pnlAddTruck.Location = new System.Drawing.Point(99, 126);
            this.pnlAddTruck.Name = "pnlAddTruck";
            this.pnlAddTruck.Size = new System.Drawing.Size(1040, 294);
            this.pnlAddTruck.TabIndex = 12;
            this.pnlAddTruck.Visible = false;
            // 
            // cbxTruckOther
            // 
            this.cbxTruckOther.FormattingEnabled = true;
            this.cbxTruckOther.Items.AddRange(new object[] {
            "",
            "R-A1F",
            "R-A1U",
            "R-A2B",
            "R-T1B",
            "R-T1C",
            "R-T9",
            "R-T9S"});
            this.cbxTruckOther.Location = new System.Drawing.Point(307, 207);
            this.cbxTruckOther.Name = "cbxTruckOther";
            this.cbxTruckOther.Size = new System.Drawing.Size(134, 39);
            this.cbxTruckOther.TabIndex = 19;
            // 
            // cbxTruckLocation
            // 
            this.cbxTruckLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTruckLocation.FormattingEnabled = true;
            this.cbxTruckLocation.Location = new System.Drawing.Point(696, 150);
            this.cbxTruckLocation.Name = "cbxTruckLocation";
            this.cbxTruckLocation.Size = new System.Drawing.Size(216, 39);
            this.cbxTruckLocation.TabIndex = 18;
            // 
            // txtbxTruckModel
            // 
            this.txtbxTruckModel.Location = new System.Drawing.Point(666, 89);
            this.txtbxTruckModel.Name = "txtbxTruckModel";
            this.txtbxTruckModel.Size = new System.Drawing.Size(326, 38);
            this.txtbxTruckModel.TabIndex = 17;
            // 
            // txtbxTruckAssetNumber
            // 
            this.txtbxTruckAssetNumber.Location = new System.Drawing.Point(768, 36);
            this.txtbxTruckAssetNumber.Name = "txtbxTruckAssetNumber";
            this.txtbxTruckAssetNumber.Size = new System.Drawing.Size(224, 38);
            this.txtbxTruckAssetNumber.TabIndex = 16;
            this.txtbxTruckAssetNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxTruckAssetNumber_KeyPress);
            // 
            // cbxTruckMaintType
            // 
            this.cbxTruckMaintType.FormattingEnabled = true;
            this.cbxTruckMaintType.Items.AddRange(new object[] {
            "",
            "AUTO",
            "OLAUTO"});
            this.cbxTruckMaintType.Location = new System.Drawing.Point(307, 150);
            this.cbxTruckMaintType.Name = "cbxTruckMaintType";
            this.cbxTruckMaintType.Size = new System.Drawing.Size(134, 39);
            this.cbxTruckMaintType.TabIndex = 15;
            // 
            // cbxTruckYear
            // 
            this.cbxTruckYear.FormattingEnabled = true;
            this.cbxTruckYear.Items.AddRange(new object[] {
            "",
            "1996",
            "1997",
            "1998",
            "1999",
            "2000",
            "2001",
            "2002",
            "2003",
            "2004",
            "2005",
            "2006",
            "2007",
            "2008",
            "2009",
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022"});
            this.cbxTruckYear.Location = new System.Drawing.Point(307, 93);
            this.cbxTruckYear.Name = "cbxTruckYear";
            this.cbxTruckYear.Size = new System.Drawing.Size(134, 39);
            this.cbxTruckYear.TabIndex = 14;
            // 
            // txtbxTruckAssetID
            // 
            this.txtbxTruckAssetID.Location = new System.Drawing.Point(307, 36);
            this.txtbxTruckAssetID.Name = "txtbxTruckAssetID";
            this.txtbxTruckAssetID.Size = new System.Drawing.Size(224, 38);
            this.txtbxTruckAssetID.TabIndex = 13;
            // 
            // lblAssetType
            // 
            this.lblAssetType.AutoSize = true;
            this.lblAssetType.Location = new System.Drawing.Point(52, 210);
            this.lblAssetType.Name = "lblAssetType";
            this.lblAssetType.Size = new System.Drawing.Size(75, 31);
            this.lblAssetType.TabIndex = 12;
            this.lblAssetType.Text = "Type";
            // 
            // lblMaintenanceType
            // 
            this.lblMaintenanceType.AutoSize = true;
            this.lblMaintenanceType.Location = new System.Drawing.Point(52, 153);
            this.lblMaintenanceType.Name = "lblMaintenanceType";
            this.lblMaintenanceType.Size = new System.Drawing.Size(237, 31);
            this.lblMaintenanceType.TabIndex = 11;
            this.lblMaintenanceType.Text = "Maintenance Type";
            // 
            // lblAssetLocation
            // 
            this.lblAssetLocation.AutoSize = true;
            this.lblAssetLocation.Location = new System.Drawing.Point(573, 153);
            this.lblAssetLocation.Name = "lblAssetLocation";
            this.lblAssetLocation.Size = new System.Drawing.Size(117, 31);
            this.lblAssetLocation.TabIndex = 3;
            this.lblAssetLocation.Text = "Location";
            // 
            // btnAddTruck
            // 
            this.btnAddTruck.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAddTruck.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddTruck.Location = new System.Drawing.Point(913, 198);
            this.btnAddTruck.Name = "btnAddTruck";
            this.btnAddTruck.Size = new System.Drawing.Size(115, 86);
            this.btnAddTruck.TabIndex = 10;
            this.btnAddTruck.Text = "Add Truck";
            this.btnAddTruck.UseVisualStyleBackColor = false;
            this.btnAddTruck.Click += new System.EventHandler(this.btnAddTruck_Click);
            // 
            // lblAssetModel
            // 
            this.lblAssetModel.AutoSize = true;
            this.lblAssetModel.Location = new System.Drawing.Point(573, 96);
            this.lblAssetModel.Name = "lblAssetModel";
            this.lblAssetModel.Size = new System.Drawing.Size(87, 31);
            this.lblAssetModel.TabIndex = 4;
            this.lblAssetModel.Text = "Model";
            // 
            // lblAssetYear
            // 
            this.lblAssetYear.AutoSize = true;
            this.lblAssetYear.Location = new System.Drawing.Point(52, 96);
            this.lblAssetYear.Name = "lblAssetYear";
            this.lblAssetYear.Size = new System.Drawing.Size(71, 31);
            this.lblAssetYear.TabIndex = 2;
            this.lblAssetYear.Text = "Year";
            // 
            // lblAssetID
            // 
            this.lblAssetID.AutoSize = true;
            this.lblAssetID.Location = new System.Drawing.Point(52, 39);
            this.lblAssetID.Name = "lblAssetID";
            this.lblAssetID.Size = new System.Drawing.Size(118, 31);
            this.lblAssetID.TabIndex = 1;
            this.lblAssetID.Text = "Asset ID";
            // 
            // lblAssetNumber
            // 
            this.lblAssetNumber.AutoSize = true;
            this.lblAssetNumber.Location = new System.Drawing.Point(573, 39);
            this.lblAssetNumber.Name = "lblAssetNumber";
            this.lblAssetNumber.Size = new System.Drawing.Size(186, 31);
            this.lblAssetNumber.TabIndex = 0;
            this.lblAssetNumber.Text = "Asset Number";
            // 
            // pnlAddADriver
            // 
            this.pnlAddADriver.Controls.Add(this.btnAddADriver);
            this.pnlAddADriver.Controls.Add(this.cbxADriverLocation);
            this.pnlAddADriver.Controls.Add(this.txtbxADriverLastName);
            this.pnlAddADriver.Controls.Add(this.txtbxADriverFirstName);
            this.pnlAddADriver.Controls.Add(this.txtbxADriverEmpID);
            this.pnlAddADriver.Controls.Add(this.lblADriverLocation);
            this.pnlAddADriver.Controls.Add(this.lblADriverLastName);
            this.pnlAddADriver.Controls.Add(this.lblADriverEmpID);
            this.pnlAddADriver.Controls.Add(this.lblADriverFirstName);
            this.pnlAddADriver.Location = new System.Drawing.Point(320, 104);
            this.pnlAddADriver.Name = "pnlAddADriver";
            this.pnlAddADriver.Size = new System.Drawing.Size(651, 230);
            this.pnlAddADriver.TabIndex = 11;
            this.pnlAddADriver.Visible = false;
            // 
            // btnAddADriver
            // 
            this.btnAddADriver.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAddADriver.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddADriver.Location = new System.Drawing.Point(533, 131);
            this.btnAddADriver.Name = "btnAddADriver";
            this.btnAddADriver.Size = new System.Drawing.Size(115, 86);
            this.btnAddADriver.TabIndex = 10;
            this.btnAddADriver.Text = "Add Driver";
            this.btnAddADriver.UseVisualStyleBackColor = false;
            this.btnAddADriver.Click += new System.EventHandler(this.btnAddADriver_Click);
            // 
            // cbxADriverLocation
            // 
            this.cbxADriverLocation.FormattingEnabled = true;
            this.cbxADriverLocation.Location = new System.Drawing.Point(240, 178);
            this.cbxADriverLocation.Name = "cbxADriverLocation";
            this.cbxADriverLocation.Size = new System.Drawing.Size(203, 39);
            this.cbxADriverLocation.TabIndex = 9;
            // 
            // txtbxADriverLastName
            // 
            this.txtbxADriverLastName.Location = new System.Drawing.Point(240, 121);
            this.txtbxADriverLastName.Name = "txtbxADriverLastName";
            this.txtbxADriverLastName.Size = new System.Drawing.Size(261, 38);
            this.txtbxADriverLastName.TabIndex = 7;
            // 
            // txtbxADriverFirstName
            // 
            this.txtbxADriverFirstName.Location = new System.Drawing.Point(240, 64);
            this.txtbxADriverFirstName.Name = "txtbxADriverFirstName";
            this.txtbxADriverFirstName.Size = new System.Drawing.Size(261, 38);
            this.txtbxADriverFirstName.TabIndex = 6;
            // 
            // txtbxADriverEmpID
            // 
            this.txtbxADriverEmpID.Location = new System.Drawing.Point(240, 7);
            this.txtbxADriverEmpID.Name = "txtbxADriverEmpID";
            this.txtbxADriverEmpID.Size = new System.Drawing.Size(261, 38);
            this.txtbxADriverEmpID.TabIndex = 5;
            this.txtbxADriverEmpID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxADriverEmpID_KeyPress);
            // 
            // lblADriverLocation
            // 
            this.lblADriverLocation.AutoSize = true;
            this.lblADriverLocation.Location = new System.Drawing.Point(5, 181);
            this.lblADriverLocation.Name = "lblADriverLocation";
            this.lblADriverLocation.Size = new System.Drawing.Size(197, 31);
            this.lblADriverLocation.TabIndex = 4;
            this.lblADriverLocation.Text = "Driver Location";
            // 
            // lblADriverLastName
            // 
            this.lblADriverLastName.AutoSize = true;
            this.lblADriverLastName.Location = new System.Drawing.Point(5, 124);
            this.lblADriverLastName.Name = "lblADriverLastName";
            this.lblADriverLastName.Size = new System.Drawing.Size(145, 31);
            this.lblADriverLastName.TabIndex = 2;
            this.lblADriverLastName.Text = "Last Name";
            // 
            // lblADriverEmpID
            // 
            this.lblADriverEmpID.AutoSize = true;
            this.lblADriverEmpID.Location = new System.Drawing.Point(5, 10);
            this.lblADriverEmpID.Name = "lblADriverEmpID";
            this.lblADriverEmpID.Size = new System.Drawing.Size(169, 31);
            this.lblADriverEmpID.TabIndex = 1;
            this.lblADriverEmpID.Text = "Employee ID";
            // 
            // lblADriverFirstName
            // 
            this.lblADriverFirstName.AutoSize = true;
            this.lblADriverFirstName.Location = new System.Drawing.Point(5, 67);
            this.lblADriverFirstName.Name = "lblADriverFirstName";
            this.lblADriverFirstName.Size = new System.Drawing.Size(147, 31);
            this.lblADriverFirstName.TabIndex = 0;
            this.lblADriverFirstName.Text = "First Name";
            // 
            // pnlAddDriver
            // 
            this.pnlAddDriver.Controls.Add(this.btnAddDriver);
            this.pnlAddDriver.Controls.Add(this.cbxDriverLocation);
            this.pnlAddDriver.Controls.Add(this.txtbxDriverLastName);
            this.pnlAddDriver.Controls.Add(this.txtbxDriverFirstName);
            this.pnlAddDriver.Controls.Add(this.txtbxEmpID);
            this.pnlAddDriver.Controls.Add(this.lblDriverLocation);
            this.pnlAddDriver.Controls.Add(this.lblDriverLastName);
            this.pnlAddDriver.Controls.Add(this.lblEmpID);
            this.pnlAddDriver.Controls.Add(this.lblDriverFirstName);
            this.pnlAddDriver.Location = new System.Drawing.Point(320, 109);
            this.pnlAddDriver.Name = "pnlAddDriver";
            this.pnlAddDriver.Size = new System.Drawing.Size(651, 228);
            this.pnlAddDriver.TabIndex = 2;
            this.pnlAddDriver.Visible = false;
            // 
            // btnAddDriver
            // 
            this.btnAddDriver.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAddDriver.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddDriver.Location = new System.Drawing.Point(530, 132);
            this.btnAddDriver.Name = "btnAddDriver";
            this.btnAddDriver.Size = new System.Drawing.Size(115, 86);
            this.btnAddDriver.TabIndex = 10;
            this.btnAddDriver.Text = "Add Driver";
            this.btnAddDriver.UseVisualStyleBackColor = false;
            this.btnAddDriver.Click += new System.EventHandler(this.btnAddDriver_Click);
            // 
            // cbxDriverLocation
            // 
            this.cbxDriverLocation.FormattingEnabled = true;
            this.cbxDriverLocation.Location = new System.Drawing.Point(237, 179);
            this.cbxDriverLocation.Name = "cbxDriverLocation";
            this.cbxDriverLocation.Size = new System.Drawing.Size(203, 39);
            this.cbxDriverLocation.TabIndex = 9;
            // 
            // txtbxDriverLastName
            // 
            this.txtbxDriverLastName.Location = new System.Drawing.Point(237, 122);
            this.txtbxDriverLastName.Name = "txtbxDriverLastName";
            this.txtbxDriverLastName.Size = new System.Drawing.Size(261, 38);
            this.txtbxDriverLastName.TabIndex = 7;
            // 
            // txtbxDriverFirstName
            // 
            this.txtbxDriverFirstName.Location = new System.Drawing.Point(237, 65);
            this.txtbxDriverFirstName.Name = "txtbxDriverFirstName";
            this.txtbxDriverFirstName.Size = new System.Drawing.Size(261, 38);
            this.txtbxDriverFirstName.TabIndex = 6;
            // 
            // txtbxEmpID
            // 
            this.txtbxEmpID.Location = new System.Drawing.Point(237, 8);
            this.txtbxEmpID.Name = "txtbxEmpID";
            this.txtbxEmpID.Size = new System.Drawing.Size(261, 38);
            this.txtbxEmpID.TabIndex = 5;
            this.txtbxEmpID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxEmpID_KeyPress);
            // 
            // lblDriverLocation
            // 
            this.lblDriverLocation.AutoSize = true;
            this.lblDriverLocation.Location = new System.Drawing.Point(2, 182);
            this.lblDriverLocation.Name = "lblDriverLocation";
            this.lblDriverLocation.Size = new System.Drawing.Size(197, 31);
            this.lblDriverLocation.TabIndex = 4;
            this.lblDriverLocation.Text = "Driver Location";
            // 
            // lblDriverLastName
            // 
            this.lblDriverLastName.AutoSize = true;
            this.lblDriverLastName.Location = new System.Drawing.Point(2, 125);
            this.lblDriverLastName.Name = "lblDriverLastName";
            this.lblDriverLastName.Size = new System.Drawing.Size(145, 31);
            this.lblDriverLastName.TabIndex = 2;
            this.lblDriverLastName.Text = "Last Name";
            // 
            // lblEmpID
            // 
            this.lblEmpID.AutoSize = true;
            this.lblEmpID.Location = new System.Drawing.Point(2, 11);
            this.lblEmpID.Name = "lblEmpID";
            this.lblEmpID.Size = new System.Drawing.Size(169, 31);
            this.lblEmpID.TabIndex = 1;
            this.lblEmpID.Text = "Employee ID";
            // 
            // lblDriverFirstName
            // 
            this.lblDriverFirstName.AutoSize = true;
            this.lblDriverFirstName.Location = new System.Drawing.Point(2, 68);
            this.lblDriverFirstName.Name = "lblDriverFirstName";
            this.lblDriverFirstName.Size = new System.Drawing.Size(147, 31);
            this.lblDriverFirstName.TabIndex = 0;
            this.lblDriverFirstName.Text = "First Name";
            // 
            // lblSelectAssetToAdd
            // 
            this.lblSelectAssetToAdd.AutoSize = true;
            this.lblSelectAssetToAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectAssetToAdd.Location = new System.Drawing.Point(556, 14);
            this.lblSelectAssetToAdd.Name = "lblSelectAssetToAdd";
            this.lblSelectAssetToAdd.Size = new System.Drawing.Size(211, 25);
            this.lblSelectAssetToAdd.TabIndex = 1;
            this.lblSelectAssetToAdd.Text = "Select an Asset to Add";
            // 
            // cbxAddAsset
            // 
            this.cbxAddAsset.FormattingEnabled = true;
            this.cbxAddAsset.Items.AddRange(new object[] {
            "",
            "Driver",
            "Assistant Driver",
            "Truck",
            "Trailer"});
            this.cbxAddAsset.Location = new System.Drawing.Point(533, 42);
            this.cbxAddAsset.Name = "cbxAddAsset";
            this.cbxAddAsset.Size = new System.Drawing.Size(257, 39);
            this.cbxAddAsset.TabIndex = 0;
            this.cbxAddAsset.SelectedIndexChanged += new System.EventHandler(this.cbxAddAsset_SelectedIndexChanged);
            // 
            // pnlDeleteAsset
            // 
            this.pnlDeleteAsset.BackColor = System.Drawing.Color.PaleVioletRed;
            this.pnlDeleteAsset.Controls.Add(this.lblDeleteDriver);
            this.pnlDeleteAsset.Controls.Add(this.btnDeleteAsset);
            this.pnlDeleteAsset.Controls.Add(this.lblDeleteADriver);
            this.pnlDeleteAsset.Controls.Add(this.lblDeleteTruck);
            this.pnlDeleteAsset.Controls.Add(this.lblDeleteTrailer);
            this.pnlDeleteAsset.Controls.Add(this.cbxDelTrailer);
            this.pnlDeleteAsset.Controls.Add(this.cbxDelDriver);
            this.pnlDeleteAsset.Controls.Add(this.cbxDelTruck);
            this.pnlDeleteAsset.Controls.Add(this.cbxDelADriver);
            this.pnlDeleteAsset.Location = new System.Drawing.Point(9, 14);
            this.pnlDeleteAsset.Name = "pnlDeleteAsset";
            this.pnlDeleteAsset.Size = new System.Drawing.Size(1323, 237);
            this.pnlDeleteAsset.TabIndex = 48;
            // 
            // lblDeleteDriver
            // 
            this.lblDeleteDriver.AutoSize = true;
            this.lblDeleteDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteDriver.Location = new System.Drawing.Point(287, 19);
            this.lblDeleteDriver.Name = "lblDeleteDriver";
            this.lblDeleteDriver.Size = new System.Drawing.Size(130, 25);
            this.lblDeleteDriver.TabIndex = 37;
            this.lblDeleteDriver.Text = "Delete Driver:";
            // 
            // btnDeleteAsset
            // 
            this.btnDeleteAsset.BackColor = System.Drawing.Color.Crimson;
            this.btnDeleteAsset.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteAsset.Location = new System.Drawing.Point(753, 109);
            this.btnDeleteAsset.Name = "btnDeleteAsset";
            this.btnDeleteAsset.Size = new System.Drawing.Size(116, 118);
            this.btnDeleteAsset.TabIndex = 47;
            this.btnDeleteAsset.Text = "Delete Asset";
            this.btnDeleteAsset.UseVisualStyleBackColor = false;
            this.btnDeleteAsset.Click += new System.EventHandler(this.btnDeleteAsset_Click);
            // 
            // lblDeleteADriver
            // 
            this.lblDeleteADriver.AutoSize = true;
            this.lblDeleteADriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteADriver.Location = new System.Drawing.Point(287, 63);
            this.lblDeleteADriver.Name = "lblDeleteADriver";
            this.lblDeleteADriver.Size = new System.Drawing.Size(215, 25);
            this.lblDeleteADriver.TabIndex = 38;
            this.lblDeleteADriver.Text = "Delete Assistant Driver:";
            // 
            // lblDeleteTruck
            // 
            this.lblDeleteTruck.AutoSize = true;
            this.lblDeleteTruck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteTruck.Location = new System.Drawing.Point(287, 110);
            this.lblDeleteTruck.Name = "lblDeleteTruck";
            this.lblDeleteTruck.Size = new System.Drawing.Size(129, 25);
            this.lblDeleteTruck.TabIndex = 39;
            this.lblDeleteTruck.Text = "Delete Truck:";
            // 
            // lblDeleteTrailer
            // 
            this.lblDeleteTrailer.AutoSize = true;
            this.lblDeleteTrailer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteTrailer.Location = new System.Drawing.Point(287, 154);
            this.lblDeleteTrailer.Name = "lblDeleteTrailer";
            this.lblDeleteTrailer.Size = new System.Drawing.Size(134, 25);
            this.lblDeleteTrailer.TabIndex = 40;
            this.lblDeleteTrailer.Text = "Delete Trailer:";
            // 
            // cbxDelTrailer
            // 
            this.cbxDelTrailer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDelTrailer.FormattingEnabled = true;
            this.cbxDelTrailer.Location = new System.Drawing.Point(556, 151);
            this.cbxDelTrailer.Name = "cbxDelTrailer";
            this.cbxDelTrailer.Size = new System.Drawing.Size(174, 33);
            this.cbxDelTrailer.TabIndex = 44;
            // 
            // cbxDelDriver
            // 
            this.cbxDelDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDelDriver.FormattingEnabled = true;
            this.cbxDelDriver.Location = new System.Drawing.Point(556, 16);
            this.cbxDelDriver.Name = "cbxDelDriver";
            this.cbxDelDriver.Size = new System.Drawing.Size(314, 33);
            this.cbxDelDriver.TabIndex = 41;
            // 
            // cbxDelTruck
            // 
            this.cbxDelTruck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDelTruck.FormattingEnabled = true;
            this.cbxDelTruck.Location = new System.Drawing.Point(556, 107);
            this.cbxDelTruck.Name = "cbxDelTruck";
            this.cbxDelTruck.Size = new System.Drawing.Size(174, 33);
            this.cbxDelTruck.TabIndex = 43;
            // 
            // cbxDelADriver
            // 
            this.cbxDelADriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDelADriver.FormattingEnabled = true;
            this.cbxDelADriver.Location = new System.Drawing.Point(556, 60);
            this.cbxDelADriver.Name = "cbxDelADriver";
            this.cbxDelADriver.Size = new System.Drawing.Size(314, 33);
            this.cbxDelADriver.TabIndex = 42;
            // 
            // dtpMain
            // 
            this.dtpMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpMain.Location = new System.Drawing.Point(310, 19);
            this.dtpMain.Name = "dtpMain";
            this.dtpMain.Size = new System.Drawing.Size(482, 38);
            this.dtpMain.TabIndex = 1;
            this.dtpMain.ValueChanged += new System.EventHandler(this.dtpMain_ValueChanged);
            // 
            // cbxLocation
            // 
            this.cbxLocation.FormattingEnabled = true;
            this.cbxLocation.Location = new System.Drawing.Point(1015, 15);
            this.cbxLocation.Name = "cbxLocation";
            this.cbxLocation.Size = new System.Drawing.Size(121, 24);
            this.cbxLocation.TabIndex = 2;
            this.cbxLocation.SelectedIndexChanged += new System.EventHandler(this.cbxLocation_SelectedIndexChanged);
            // 
            // cbxLocPrefix
            // 
            this.cbxLocPrefix.FormattingEnabled = true;
            this.cbxLocPrefix.Location = new System.Drawing.Point(1015, 55);
            this.cbxLocPrefix.Name = "cbxLocPrefix";
            this.cbxLocPrefix.Size = new System.Drawing.Size(121, 24);
            this.cbxLocPrefix.TabIndex = 3;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Crimson;
            this.ClientSize = new System.Drawing.Size(1356, 857);
            this.Controls.Add(this.cbxLocPrefix);
            this.Controls.Add(this.cbxLocation);
            this.Controls.Add(this.dtpMain);
            this.Controls.Add(this.tcMain);
            this.Name = "frmMain";
            this.Text = "BFS - Routing";
            this.tcMain.ResumeLayout(false);
            this.tabCurrentRoutes.ResumeLayout(false);
            this.pnlCurrentRoutes.ResumeLayout(false);
            this.pnlCurrentRoutes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRouteInfo)).EndInit();
            this.tabCreateRoute.ResumeLayout(false);
            this.pnlCreateRoute.ResumeLayout(false);
            this.pnlCreateRoute.PerformLayout();
            this.pnlCreateStops.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddStops)).EndInit();
            this.tabManageRoutes.ResumeLayout(false);
            this.pnlManageRoutesMain.ResumeLayout(false);
            this.pnlDetails.ResumeLayout(false);
            this.pnlDetails.PerformLayout();
            this.pnlDeleteRoute.ResumeLayout(false);
            this.pnlDeleteRoute.PerformLayout();
            this.pnlChangeStops.ResumeLayout(false);
            this.pnlChangeStops.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChangeAddStops)).EndInit();
            this.tabShipStatus.ResumeLayout(false);
            this.pnlStatus.ResumeLayout(false);
            this.pnlStatus.PerformLayout();
            this.pnlRouteStatus.ResumeLayout(false);
            this.pnlRouteStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryStatusDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryStatusStops)).EndInit();
            this.tabAddDelAssets.ResumeLayout(false);
            this.pnlAddDel.ResumeLayout(false);
            this.pnlAddAsset.ResumeLayout(false);
            this.pnlAddAsset.PerformLayout();
            this.pnlAddTrailer.ResumeLayout(false);
            this.pnlAddTrailer.PerformLayout();
            this.pnlAddTruck.ResumeLayout(false);
            this.pnlAddTruck.PerformLayout();
            this.pnlAddADriver.ResumeLayout(false);
            this.pnlAddADriver.PerformLayout();
            this.pnlAddDriver.ResumeLayout(false);
            this.pnlAddDriver.PerformLayout();
            this.pnlDeleteAsset.ResumeLayout(false);
            this.pnlDeleteAsset.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage tabCreateRoute;
        private System.Windows.Forms.TabPage tabManageRoutes;
        private System.Windows.Forms.TabPage tabCurrentRoutes;
        public System.Windows.Forms.Panel pnlCurrentRoutes;
        public System.Windows.Forms.DateTimePicker dtpMain;
        private System.Windows.Forms.Label lblRoute;
        public System.Windows.Forms.ComboBox cbxRoute;
        private System.Windows.Forms.Label lblDriver;
        private System.Windows.Forms.Label lblDriverLabel;
        private System.Windows.Forms.Label lblAsstDriver;
        private System.Windows.Forms.Label lblADriverLabel;
        private System.Windows.Forms.Label lblTruck;
        private System.Windows.Forms.Label lblTruckLabel;
        private System.Windows.Forms.Label lblTrailer;
        private System.Windows.Forms.Label lblTrailerLabel;
        private System.Windows.Forms.Label lblStopsLabel;
        public System.Windows.Forms.Label lblNumofStops;
        public System.Windows.Forms.DataGrid dgRouteInfo;
        private System.Windows.Forms.Panel pnlCreateRoute;
        private System.Windows.Forms.ComboBox cbxCreateADriver;
        private System.Windows.Forms.Label lblCreateADriver;
        private System.Windows.Forms.ComboBox cbxCreateDriver;
        private System.Windows.Forms.Label lblCreateDriver;
        private System.Windows.Forms.Label lblCreateDate;
        private System.Windows.Forms.Label lblCreateDateLabel;
        private System.Windows.Forms.Label lblCreateTruck;
        private System.Windows.Forms.ComboBox cbxCreateTrailer;
        private System.Windows.Forms.Label lblCreateTrailer;
        private System.Windows.Forms.ComboBox cbxCreateTruck;
        private System.Windows.Forms.Label lblRouteCodeCreated;
        private System.Windows.Forms.Button btnClearCreateForm;
        private System.Windows.Forms.Button btnCreateRoute;
        private System.Windows.Forms.ComboBox cbxLocation;
        private System.Windows.Forms.Label lblUnitCount;
        private System.Windows.Forms.Panel pnlManageRoutesMain;
        private System.Windows.Forms.Label lblManageRouteROUTE;
        public System.Windows.Forms.ComboBox cbxChangeRoute;
        private System.Windows.Forms.Button btnDeleteRoute;
        private System.Windows.Forms.Label lblCurrentTrailer;
        private System.Windows.Forms.Label lblCurrentTruck;
        private System.Windows.Forms.Label lblCurrentASstDriver;
        private System.Windows.Forms.Label lblCurrentDriver;
        private System.Windows.Forms.Label lblCurrentTrailerLabel;
        private System.Windows.Forms.Label lblCurrentTruckLabel;
        private System.Windows.Forms.Label lblCurrentAsstDriverLabel;
        private System.Windows.Forms.Label lblCurrentDriverLabel;
        private System.Windows.Forms.Label lblChangeAsstDriverTo;
        private System.Windows.Forms.Label lblChangeDriverTo;
        private System.Windows.Forms.Label lblChangeTruckTo;
        private System.Windows.Forms.Label lblChangeTrailerTo;
        private System.Windows.Forms.ComboBox cbxChangeAsstDriverTo;
        private System.Windows.Forms.ComboBox cbxChangeDriverTo;
        private System.Windows.Forms.ComboBox cbxChangeTruckTo;
        private System.Windows.Forms.ComboBox cbxChangeTrailerTo;
        private System.Windows.Forms.Label lblChangeStopsTo;
        private System.Windows.Forms.ComboBox cbxLocPrefix;
        private System.Windows.Forms.DataGridView dgvChangeAddStops;
        private System.Windows.Forms.Label lblCreateBayID;
        private System.Windows.Forms.ComboBox cbxBayIDs;
        private System.Windows.Forms.Panel pnlDetails;
        private System.Windows.Forms.Label lblForBayID;
        private System.Windows.Forms.Panel pnlDeleteRoute;
        private System.Windows.Forms.Label lblNewBayID;
        private System.Windows.Forms.Label lblCurrentBayID;
        private System.Windows.Forms.ComboBox cbxChangeBayID;
        private System.Windows.Forms.Button btnSaveChangeDetails;
        private System.Windows.Forms.Panel pnlChangeStops;
        private System.Windows.Forms.Button btnDeleteStop;
        private System.Windows.Forms.Button btnAddStopsFromChange;
        private System.Windows.Forms.Panel pnlCreateStops;
        private System.Windows.Forms.DataGridView dgvAddStops;
        private System.Windows.Forms.Button btnAddNewStops;
        private System.Windows.Forms.Button btnDoneAddingStops;
        private System.Windows.Forms.TabPage tabShipStatus;
        private System.Windows.Forms.Panel pnlStatus;
        private System.Windows.Forms.ComboBox cbxDeliveryRoutes;
        private System.Windows.Forms.Label lblDeliveryRoute;
        private System.Windows.Forms.DataGridView dgvDeliveryStatusDetails;
        private System.Windows.Forms.DataGridView dgvDeliveryStatusStops;
        private System.Windows.Forms.Label lblJobID;
        private System.Windows.Forms.Label lblPickTicketSearch;
        private System.Windows.Forms.Label lblGetDeliveryStatus;
        private System.Windows.Forms.Panel pnlRouteStatus;
        private System.Windows.Forms.TextBox txtPickTicketSearch;
        private System.Windows.Forms.TextBox txtJobIDSearch;
        private System.Windows.Forms.TabPage tabAddDelAssets;
        private System.Windows.Forms.Panel pnlAddDel;
        private System.Windows.Forms.Button btnDeleteAsset;
        private System.Windows.Forms.ComboBox cbxDelTrailer;
        private System.Windows.Forms.ComboBox cbxDelTruck;
        private System.Windows.Forms.ComboBox cbxDelADriver;
        private System.Windows.Forms.ComboBox cbxDelDriver;
        private System.Windows.Forms.Label lblDeleteTrailer;
        private System.Windows.Forms.Label lblDeleteTruck;
        private System.Windows.Forms.Label lblDeleteADriver;
        private System.Windows.Forms.Label lblDeleteDriver;
        private System.Windows.Forms.Panel pnlAddAsset;
        private System.Windows.Forms.Panel pnlDeleteAsset;
        private System.Windows.Forms.Label lblSelectAssetToAdd;
        private System.Windows.Forms.ComboBox cbxAddAsset;
        private System.Windows.Forms.Panel pnlAddDriver;
        private System.Windows.Forms.Label lblDriverLastName;
        private System.Windows.Forms.Label lblEmpID;
        private System.Windows.Forms.Label lblDriverFirstName;
        private System.Windows.Forms.Label lblDriverLocation;
        private System.Windows.Forms.ComboBox cbxDriverLocation;
        private System.Windows.Forms.TextBox txtbxDriverLastName;
        private System.Windows.Forms.TextBox txtbxDriverFirstName;
        private System.Windows.Forms.TextBox txtbxEmpID;
        private System.Windows.Forms.Button btnAddDriver;
        private System.Windows.Forms.Panel pnlAddADriver;
        private System.Windows.Forms.ComboBox cbxADriverLocation;
        private System.Windows.Forms.TextBox txtbxADriverLastName;
        private System.Windows.Forms.TextBox txtbxADriverFirstName;
        private System.Windows.Forms.TextBox txtbxADriverEmpID;
        private System.Windows.Forms.Label lblADriverLocation;
        private System.Windows.Forms.Label lblADriverLastName;
        private System.Windows.Forms.Label lblADriverEmpID;
        private System.Windows.Forms.Label lblADriverFirstName;
        private System.Windows.Forms.Panel pnlAddTruck;
        private System.Windows.Forms.Label lblMaintenanceType;
        private System.Windows.Forms.Button btnAddTruck;
        private System.Windows.Forms.Label lblAssetModel;
        private System.Windows.Forms.Label lblAssetYear;
        private System.Windows.Forms.Label lblAssetID;
        private System.Windows.Forms.Label lblAssetNumber;
        private System.Windows.Forms.Label lblAssetLocation;
        private System.Windows.Forms.Button btnAddADriver;
        private System.Windows.Forms.Label lblAssetType;
        private System.Windows.Forms.ComboBox cbxTruckYear;
        private System.Windows.Forms.TextBox txtbxTruckAssetID;
        private System.Windows.Forms.ComboBox cbxTruckMaintType;
        private System.Windows.Forms.TextBox txtbxTruckModel;
        private System.Windows.Forms.TextBox txtbxTruckAssetNumber;
        private System.Windows.Forms.ComboBox cbxTruckOther;
        private System.Windows.Forms.ComboBox cbxTruckLocation;
        private System.Windows.Forms.Panel pnlAddTrailer;
        private System.Windows.Forms.ComboBox cbxTrailerType;
        private System.Windows.Forms.ComboBox cbxTrailerLocation;
        private System.Windows.Forms.TextBox txtbxTrailerModel;
        private System.Windows.Forms.TextBox txtbxTrailerAssetNumber;
        private System.Windows.Forms.ComboBox cbxTrailerMaintType;
        private System.Windows.Forms.ComboBox cbxTrailerYear;
        private System.Windows.Forms.TextBox txtbxTrailerAssetID;
        private System.Windows.Forms.Label lblTrailerType;
        private System.Windows.Forms.Label lblTrailerMaintType;
        private System.Windows.Forms.Label lblTrailerLocation;
        private System.Windows.Forms.Button btnAddTrailer;
        private System.Windows.Forms.Label lblTrailerModel;
        private System.Windows.Forms.Label lblbTrailerYear;
        private System.Windows.Forms.Label lblTrailerAssetID;
        private System.Windows.Forms.Label lblTrailerAssetNumber;
    }
}

